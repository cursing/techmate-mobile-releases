(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))r(s);new MutationObserver(s=>{for(const i of s)if(i.type==="childList")for(const o of i.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&r(o)}).observe(document,{childList:!0,subtree:!0});function t(s){const i={};return s.integrity&&(i.integrity=s.integrity),s.referrerPolicy&&(i.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?i.credentials="include":s.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(s){if(s.ep)return;s.ep=!0;const i=t(s);fetch(s.href,i)}})();var uu={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ld=function(n){const e=[];let t=0;for(let r=0;r<n.length;r++){let s=n.charCodeAt(r);s<128?e[t++]=s:s<2048?(e[t++]=s>>6|192,e[t++]=s&63|128):(s&64512)===55296&&r+1<n.length&&(n.charCodeAt(r+1)&64512)===56320?(s=65536+((s&1023)<<10)+(n.charCodeAt(++r)&1023),e[t++]=s>>18|240,e[t++]=s>>12&63|128,e[t++]=s>>6&63|128,e[t++]=s&63|128):(e[t++]=s>>12|224,e[t++]=s>>6&63|128,e[t++]=s&63|128)}return e},yg=function(n){const e=[];let t=0,r=0;for(;t<n.length;){const s=n[t++];if(s<128)e[r++]=String.fromCharCode(s);else if(s>191&&s<224){const i=n[t++];e[r++]=String.fromCharCode((s&31)<<6|i&63)}else if(s>239&&s<365){const i=n[t++],o=n[t++],c=n[t++],l=((s&7)<<18|(i&63)<<12|(o&63)<<6|c&63)-65536;e[r++]=String.fromCharCode(55296+(l>>10)),e[r++]=String.fromCharCode(56320+(l&1023))}else{const i=n[t++],o=n[t++];e[r++]=String.fromCharCode((s&15)<<12|(i&63)<<6|o&63)}}return e.join("")},ud={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let s=0;s<n.length;s+=3){const i=n[s],o=s+1<n.length,c=o?n[s+1]:0,l=s+2<n.length,h=l?n[s+2]:0,f=i>>2,m=(i&3)<<4|c>>4;let I=(c&15)<<2|h>>6,S=h&63;l||(S=64,o||(I=64)),r.push(t[f],t[m],t[I],t[S])}return r.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(ld(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):yg(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let s=0;s<n.length;){const i=t[n.charAt(s++)],c=s<n.length?t[n.charAt(s)]:0;++s;const h=s<n.length?t[n.charAt(s)]:64;++s;const m=s<n.length?t[n.charAt(s)]:64;if(++s,i==null||c==null||h==null||m==null)throw new vg;const I=i<<2|c>>4;if(r.push(I),h!==64){const S=c<<4&240|h>>2;if(r.push(S),m!==64){const D=h<<6&192|m;r.push(D)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class vg extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Ig=function(n){const e=ld(n);return ud.encodeByteArray(e,!0)},hd=function(n){return Ig(n).replace(/\./g,"")},dd=function(n){try{return ud.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Eg(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wg=()=>Eg().__FIREBASE_DEFAULTS__,Tg=()=>{if(typeof process>"u"||typeof uu>"u")return;const n=uu.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},bg=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&dd(n[1]);return e&&JSON.parse(e)},co=()=>{try{return wg()||Tg()||bg()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},Ag=n=>{var e,t;return(t=(e=co())===null||e===void 0?void 0:e.emulatorHosts)===null||t===void 0?void 0:t[n]},fd=()=>{var n;return(n=co())===null||n===void 0?void 0:n.config},pd=n=>{var e;return(e=co())===null||e===void 0?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sg{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,r)=>{t?this.reject(t):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,r))}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function be(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Rg(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(be())}function Pg(){var n;const e=(n=co())===null||n===void 0?void 0:n.forceEnvironment;if(e==="node")return!0;if(e==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function Cg(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function kg(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function Dg(){const n=be();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function md(){return!Pg()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function gd(){try{return typeof indexedDB=="object"}catch{return!1}}function Vg(){return new Promise((n,e)=>{try{let t=!0;const r="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(r);s.onsuccess=()=>{s.result.close(),t||self.indexedDB.deleteDatabase(r),n(!0)},s.onupgradeneeded=()=>{t=!1},s.onerror=()=>{var i;e(((i=s.error)===null||i===void 0?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ng="FirebaseError";class kt extends Error{constructor(e,t,r){super(t),this.code=e,this.customData=r,this.name=Ng,Object.setPrototypeOf(this,kt.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Os.prototype.create)}}class Os{constructor(e,t,r){this.service=e,this.serviceName=t,this.errors=r}create(e,...t){const r=t[0]||{},s=`${this.service}/${e}`,i=this.errors[e],o=i?xg(i,r):"Error",c=`${this.serviceName}: ${o} (${s}).`;return new kt(s,c,r)}}function xg(n,e){return n.replace(Og,(t,r)=>{const s=e[r];return s!=null?String(s):`<${r}?>`})}const Og=/\{\$([^}]+)}/g;function Mg(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function vs(n,e){if(n===e)return!0;const t=Object.keys(n),r=Object.keys(e);for(const s of t){if(!r.includes(s))return!1;const i=n[s],o=e[s];if(hu(i)&&hu(o)){if(!vs(i,o))return!1}else if(i!==o)return!1}for(const s of r)if(!t.includes(s))return!1;return!0}function hu(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ms(n){const e=[];for(const[t,r]of Object.entries(n))Array.isArray(r)?r.forEach(s=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(s))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(r));return e.length?"&"+e.join("&"):""}function ss(n){const e={};return n.replace(/^\?/,"").split("&").forEach(r=>{if(r){const[s,i]=r.split("=");e[decodeURIComponent(s)]=decodeURIComponent(i)}}),e}function is(n){const e=n.indexOf("?");if(!e)return"";const t=n.indexOf("#",e);return n.substring(e,t>0?t:void 0)}function Lg(n,e){const t=new Fg(n,e);return t.subscribe.bind(t)}class Fg{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(r=>{this.error(r)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,r){let s;if(e===void 0&&t===void 0&&r===void 0)throw new Error("Missing Observer.");$g(e,["next","error","complete"])?s=e:s={next:e,error:t,complete:r},s.next===void 0&&(s.next=ua),s.error===void 0&&(s.error=ua),s.complete===void 0&&(s.complete=ua);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?s.error(this.finalError):s.complete()}catch{}}),this.observers.push(s),i}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function $g(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function ua(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Re(n){return n&&n._delegate?n._delegate:n}class Pn{constructor(e,t,r){this.name=e,this.instanceFactory=t,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _n="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ug{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const r=new Sg;if(this.instancesDeferred.set(t,r),this.isInitialized(t)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:t});s&&r.resolve(s)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const r=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),s=(t=e==null?void 0:e.optional)!==null&&t!==void 0?t:!1;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(i){if(s)return null;throw i}else{if(s)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(qg(e))try{this.getOrInitializeService({instanceIdentifier:_n})}catch{}for(const[t,r]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:s});r.resolve(i)}catch{}}}}clearInstance(e=_n){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=_n){return this.instances.has(e)}getOptions(e=_n){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:r,options:t});for(const[i,o]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(i);r===c&&o.resolve(s)}return s}onInit(e,t){var r;const s=this.normalizeInstanceIdentifier(t),i=(r=this.onInitCallbacks.get(s))!==null&&r!==void 0?r:new Set;i.add(e),this.onInitCallbacks.set(s,i);const o=this.instances.get(s);return o&&e(o,s),()=>{i.delete(e)}}invokeOnInitCallbacks(e,t){const r=this.onInitCallbacks.get(t);if(r)for(const s of r)try{s(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:Bg(e),options:t}),this.instances.set(e,r),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=_n){return this.component?this.component.multipleInstances?e:_n:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Bg(n){return n===_n?void 0:n}function qg(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jg{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new Ug(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var te;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(te||(te={}));const Gg={debug:te.DEBUG,verbose:te.VERBOSE,info:te.INFO,warn:te.WARN,error:te.ERROR,silent:te.SILENT},zg=te.INFO,Kg={[te.DEBUG]:"log",[te.VERBOSE]:"log",[te.INFO]:"info",[te.WARN]:"warn",[te.ERROR]:"error"},Wg=(n,e,...t)=>{if(e<n.logLevel)return;const r=new Date().toISOString(),s=Kg[e];if(s)console[s](`[${r}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class oc{constructor(e){this.name=e,this._logLevel=zg,this._logHandler=Wg,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in te))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Gg[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,te.DEBUG,...e),this._logHandler(this,te.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,te.VERBOSE,...e),this._logHandler(this,te.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,te.INFO,...e),this._logHandler(this,te.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,te.WARN,...e),this._logHandler(this,te.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,te.ERROR,...e),this._logHandler(this,te.ERROR,...e)}}const Hg=(n,e)=>e.some(t=>n instanceof t);let du,fu;function Qg(){return du||(du=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Jg(){return fu||(fu=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const _d=new WeakMap,Ra=new WeakMap,yd=new WeakMap,ha=new WeakMap,ac=new WeakMap;function Yg(n){const e=new Promise((t,r)=>{const s=()=>{n.removeEventListener("success",i),n.removeEventListener("error",o)},i=()=>{t(Kt(n.result)),s()},o=()=>{r(n.error),s()};n.addEventListener("success",i),n.addEventListener("error",o)});return e.then(t=>{t instanceof IDBCursor&&_d.set(t,n)}).catch(()=>{}),ac.set(e,n),e}function Xg(n){if(Ra.has(n))return;const e=new Promise((t,r)=>{const s=()=>{n.removeEventListener("complete",i),n.removeEventListener("error",o),n.removeEventListener("abort",o)},i=()=>{t(),s()},o=()=>{r(n.error||new DOMException("AbortError","AbortError")),s()};n.addEventListener("complete",i),n.addEventListener("error",o),n.addEventListener("abort",o)});Ra.set(n,e)}let Pa={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return Ra.get(n);if(e==="objectStoreNames")return n.objectStoreNames||yd.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Kt(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function Zg(n){Pa=n(Pa)}function e_(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const r=n.call(da(this),e,...t);return yd.set(r,e.sort?e.sort():[e]),Kt(r)}:Jg().includes(n)?function(...e){return n.apply(da(this),e),Kt(_d.get(this))}:function(...e){return Kt(n.apply(da(this),e))}}function t_(n){return typeof n=="function"?e_(n):(n instanceof IDBTransaction&&Xg(n),Hg(n,Qg())?new Proxy(n,Pa):n)}function Kt(n){if(n instanceof IDBRequest)return Yg(n);if(ha.has(n))return ha.get(n);const e=t_(n);return e!==n&&(ha.set(n,e),ac.set(e,n)),e}const da=n=>ac.get(n);function n_(n,e,{blocked:t,upgrade:r,blocking:s,terminated:i}={}){const o=indexedDB.open(n,e),c=Kt(o);return r&&o.addEventListener("upgradeneeded",l=>{r(Kt(o.result),l.oldVersion,l.newVersion,Kt(o.transaction),l)}),t&&o.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),c.then(l=>{i&&l.addEventListener("close",()=>i()),s&&l.addEventListener("versionchange",h=>s(h.oldVersion,h.newVersion,h))}).catch(()=>{}),c}const r_=["get","getKey","getAll","getAllKeys","count"],s_=["put","add","delete","clear"],fa=new Map;function pu(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(fa.get(e))return fa.get(e);const t=e.replace(/FromIndex$/,""),r=e!==t,s=s_.includes(t);if(!(t in(r?IDBIndex:IDBObjectStore).prototype)||!(s||r_.includes(t)))return;const i=async function(o,...c){const l=this.transaction(o,s?"readwrite":"readonly");let h=l.store;return r&&(h=h.index(c.shift())),(await Promise.all([h[t](...c),s&&l.done]))[0]};return fa.set(e,i),i}Zg(n=>({...n,get:(e,t,r)=>pu(e,t)||n.get(e,t,r),has:(e,t)=>!!pu(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class i_{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(o_(t)){const r=t.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(t=>t).join(" ")}}function o_(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const Ca="@firebase/app",mu="0.10.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cn=new oc("@firebase/app"),a_="@firebase/app-compat",c_="@firebase/analytics-compat",l_="@firebase/analytics",u_="@firebase/app-check-compat",h_="@firebase/app-check",d_="@firebase/auth",f_="@firebase/auth-compat",p_="@firebase/database",m_="@firebase/database-compat",g_="@firebase/functions",__="@firebase/functions-compat",y_="@firebase/installations",v_="@firebase/installations-compat",I_="@firebase/messaging",E_="@firebase/messaging-compat",w_="@firebase/performance",T_="@firebase/performance-compat",b_="@firebase/remote-config",A_="@firebase/remote-config-compat",S_="@firebase/storage",R_="@firebase/storage-compat",P_="@firebase/firestore",C_="@firebase/vertexai-preview",k_="@firebase/firestore-compat",D_="firebase",V_="10.12.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ka="[DEFAULT]",N_={[Ca]:"fire-core",[a_]:"fire-core-compat",[l_]:"fire-analytics",[c_]:"fire-analytics-compat",[h_]:"fire-app-check",[u_]:"fire-app-check-compat",[d_]:"fire-auth",[f_]:"fire-auth-compat",[p_]:"fire-rtdb",[m_]:"fire-rtdb-compat",[g_]:"fire-fn",[__]:"fire-fn-compat",[y_]:"fire-iid",[v_]:"fire-iid-compat",[I_]:"fire-fcm",[E_]:"fire-fcm-compat",[w_]:"fire-perf",[T_]:"fire-perf-compat",[b_]:"fire-rc",[A_]:"fire-rc-compat",[S_]:"fire-gcs",[R_]:"fire-gcs-compat",[P_]:"fire-fst",[k_]:"fire-fst-compat",[C_]:"fire-vertex","fire-js":"fire-js",[D_]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mi=new Map,x_=new Map,Da=new Map;function gu(n,e){try{n.container.addComponent(e)}catch(t){Cn.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function ur(n){const e=n.name;if(Da.has(e))return Cn.debug(`There were multiple attempts to register component ${e}.`),!1;Da.set(e,n);for(const t of Mi.values())gu(t,n);for(const t of x_.values())gu(t,n);return!0}function cc(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function Tt(n){return n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const O_={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Wt=new Os("app","Firebase",O_);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class M_{constructor(e,t,r){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new Pn("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Wt.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cr=V_;function vd(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const r=Object.assign({name:ka,automaticDataCollectionEnabled:!1},e),s=r.name;if(typeof s!="string"||!s)throw Wt.create("bad-app-name",{appName:String(s)});if(t||(t=fd()),!t)throw Wt.create("no-options");const i=Mi.get(s);if(i){if(vs(t,i.options)&&vs(r,i.config))return i;throw Wt.create("duplicate-app",{appName:s})}const o=new jg(s);for(const l of Da.values())o.addComponent(l);const c=new M_(t,r,o);return Mi.set(s,c),c}function L_(n=ka){const e=Mi.get(n);if(!e&&n===ka&&fd())return vd();if(!e)throw Wt.create("no-app",{appName:n});return e}function Ht(n,e,t){var r;let s=(r=N_[n])!==null&&r!==void 0?r:n;t&&(s+=`-${t}`);const i=s.match(/\s|\//),o=e.match(/\s|\//);if(i||o){const c=[`Unable to register library "${s}" with version "${e}":`];i&&c.push(`library name "${s}" contains illegal characters (whitespace or "/")`),i&&o&&c.push("and"),o&&c.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Cn.warn(c.join(" "));return}ur(new Pn(`${s}-version`,()=>({library:s,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F_="firebase-heartbeat-database",$_=1,Is="firebase-heartbeat-store";let pa=null;function Id(){return pa||(pa=n_(F_,$_,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(Is)}catch(t){console.warn(t)}}}}).catch(n=>{throw Wt.create("idb-open",{originalErrorMessage:n.message})})),pa}async function U_(n){try{const t=(await Id()).transaction(Is),r=await t.objectStore(Is).get(Ed(n));return await t.done,r}catch(e){if(e instanceof kt)Cn.warn(e.message);else{const t=Wt.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Cn.warn(t.message)}}}async function _u(n,e){try{const r=(await Id()).transaction(Is,"readwrite");await r.objectStore(Is).put(e,Ed(n)),await r.done}catch(t){if(t instanceof kt)Cn.warn(t.message);else{const r=Wt.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Cn.warn(r.message)}}}function Ed(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B_=1024,q_=30*24*60*60*1e3;class j_{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new z_(t),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,t;const s=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=yu();if(!(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null))&&!(this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(o=>o.date===i)))return this._heartbeatsCache.heartbeats.push({date:i,agent:s}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(o=>{const c=new Date(o.date).valueOf();return Date.now()-c<=q_}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){var e;if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=yu(),{heartbeatsToSend:r,unsentEntries:s}=G_(this._heartbeatsCache.heartbeats),i=hd(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=t,s.length>0?(this._heartbeatsCache.heartbeats=s,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}}function yu(){return new Date().toISOString().substring(0,10)}function G_(n,e=B_){const t=[];let r=n.slice();for(const s of n){const i=t.find(o=>o.agent===s.agent);if(i){if(i.dates.push(s.date),vu(t)>e){i.dates.pop();break}}else if(t.push({agent:s.agent,dates:[s.date]}),vu(t)>e){t.pop();break}r=r.slice(1)}return{heartbeatsToSend:t,unsentEntries:r}}class z_{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return gd()?Vg().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await U_(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var t;if(await this._canUseIndexedDBPromise){const s=await this.read();return _u(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:s.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var t;if(await this._canUseIndexedDBPromise){const s=await this.read();return _u(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:s.lastSentHeartbeatDate,heartbeats:[...s.heartbeats,...e.heartbeats]})}else return}}function vu(n){return hd(JSON.stringify({version:2,heartbeats:n})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function K_(n){ur(new Pn("platform-logger",e=>new i_(e),"PRIVATE")),ur(new Pn("heartbeat",e=>new j_(e),"PRIVATE")),Ht(Ca,mu,n),Ht(Ca,mu,"esm2017"),Ht("fire-js","")}K_("");var W_="firebase",H_="10.12.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ht(W_,H_,"app");function lc(n,e){var t={};for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&e.indexOf(r)<0&&(t[r]=n[r]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var s=0,r=Object.getOwnPropertySymbols(n);s<r.length;s++)e.indexOf(r[s])<0&&Object.prototype.propertyIsEnumerable.call(n,r[s])&&(t[r[s]]=n[r[s]]);return t}function wd(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Q_=wd,Td=new Os("auth","Firebase",wd());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Li=new oc("@firebase/auth");function J_(n,...e){Li.logLevel<=te.WARN&&Li.warn(`Auth (${Cr}): ${n}`,...e)}function vi(n,...e){Li.logLevel<=te.ERROR&&Li.error(`Auth (${Cr}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ct(n,...e){throw uc(n,...e)}function gt(n,...e){return uc(n,...e)}function bd(n,e,t){const r=Object.assign(Object.assign({},Q_()),{[e]:t});return new Os("auth","Firebase",r).create(e,{appName:n.name})}function Qt(n){return bd(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function uc(n,...e){if(typeof n!="string"){const t=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=n.name),n._errorFactory.create(t,...r)}return Td.create(n,...e)}function W(n,e,...t){if(!n)throw uc(e,...t)}function bt(n){const e="INTERNAL ASSERTION FAILED: "+n;throw vi(e),new Error(e)}function Pt(n,e){n||bt(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Va(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.href)||""}function Y_(){return Iu()==="http:"||Iu()==="https:"}function Iu(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function X_(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Y_()||Cg()||"connection"in navigator)?navigator.onLine:!0}function Z_(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ls{constructor(e,t){this.shortDelay=e,this.longDelay=t,Pt(t>e,"Short delay should be less than long delay!"),this.isMobile=Rg()||kg()}get(){return X_()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hc(n,e){Pt(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ad{static initialize(e,t,r){this.fetchImpl=e,t&&(this.headersImpl=t),r&&(this.responseImpl=r)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;bt("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;bt("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;bt("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ey={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ty=new Ls(3e4,6e4);function Bn(n,e){return n.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:n.tenantId}):e}async function on(n,e,t,r,s={}){return Sd(n,s,async()=>{let i={},o={};r&&(e==="GET"?o=r:i={body:JSON.stringify(r)});const c=Ms(Object.assign({key:n.config.apiKey},o)).slice(1),l=await n._getAdditionalHeaders();return l["Content-Type"]="application/json",n.languageCode&&(l["X-Firebase-Locale"]=n.languageCode),Ad.fetch()(Rd(n,n.config.apiHost,t,c),Object.assign({method:e,headers:l,referrerPolicy:"no-referrer"},i))})}async function Sd(n,e,t){n._canInitEmulator=!1;const r=Object.assign(Object.assign({},ey),e);try{const s=new ry(n),i=await Promise.race([t(),s.promise]);s.clearNetworkTimeout();const o=await i.json();if("needConfirmation"in o)throw ui(n,"account-exists-with-different-credential",o);if(i.ok&&!("errorMessage"in o))return o;{const c=i.ok?o.errorMessage:o.error.message,[l,h]=c.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw ui(n,"credential-already-in-use",o);if(l==="EMAIL_EXISTS")throw ui(n,"email-already-in-use",o);if(l==="USER_DISABLED")throw ui(n,"user-disabled",o);const f=r[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(h)throw bd(n,f,h);ct(n,f)}}catch(s){if(s instanceof kt)throw s;ct(n,"network-request-failed",{message:String(s)})}}async function lo(n,e,t,r,s={}){const i=await on(n,e,t,r,s);return"mfaPendingCredential"in i&&ct(n,"multi-factor-auth-required",{_serverResponse:i}),i}function Rd(n,e,t,r){const s=`${e}${t}?${r}`;return n.config.emulator?hc(n.config,s):`${n.config.apiScheme}://${s}`}function ny(n){switch(n){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class ry{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,r)=>{this.timer=setTimeout(()=>r(gt(this.auth,"network-request-failed")),ty.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function ui(n,e,t){const r={appName:n.name};t.email&&(r.email=t.email),t.phoneNumber&&(r.phoneNumber=t.phoneNumber);const s=gt(n,e,r);return s.customData._tokenResponse=t,s}function Eu(n){return n!==void 0&&n.enterprise!==void 0}class sy{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return ny(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}}async function iy(n,e){return on(n,"GET","/v2/recaptchaConfig",Bn(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function oy(n,e){return on(n,"POST","/v1/accounts:delete",e)}async function Pd(n,e){return on(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hs(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function ay(n,e=!1){const t=Re(n),r=await t.getIdToken(e),s=dc(r);W(s&&s.exp&&s.auth_time&&s.iat,t.auth,"internal-error");const i=typeof s.firebase=="object"?s.firebase:void 0,o=i==null?void 0:i.sign_in_provider;return{claims:s,token:r,authTime:hs(ma(s.auth_time)),issuedAtTime:hs(ma(s.iat)),expirationTime:hs(ma(s.exp)),signInProvider:o||null,signInSecondFactor:(i==null?void 0:i.sign_in_second_factor)||null}}function ma(n){return Number(n)*1e3}function dc(n){const[e,t,r]=n.split(".");if(e===void 0||t===void 0||r===void 0)return vi("JWT malformed, contained fewer than 3 sections"),null;try{const s=dd(t);return s?JSON.parse(s):(vi("Failed to decode base64 JWT payload"),null)}catch(s){return vi("Caught error parsing JWT payload as JSON",s==null?void 0:s.toString()),null}}function wu(n){const e=dc(n);return W(e,"internal-error"),W(typeof e.exp<"u","internal-error"),W(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Es(n,e,t=!1){if(t)return e;try{return await e}catch(r){throw r instanceof kt&&cy(r)&&n.auth.currentUser===n&&await n.auth.signOut(),r}}function cy({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ly{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const r=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),r}else{this.errorBackoff=3e4;const s=((t=this.user.stsTokenManager.expirationTime)!==null&&t!==void 0?t:0)-Date.now()-3e5;return Math.max(0,s)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Na{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=hs(this.lastLoginAt),this.creationTime=hs(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fi(n){var e;const t=n.auth,r=await n.getIdToken(),s=await Es(n,Pd(t,{idToken:r}));W(s==null?void 0:s.users.length,t,"internal-error");const i=s.users[0];n._notifyReloadListener(i);const o=!((e=i.providerUserInfo)===null||e===void 0)&&e.length?Cd(i.providerUserInfo):[],c=hy(n.providerData,o),l=n.isAnonymous,h=!(n.email&&i.passwordHash)&&!(c!=null&&c.length),f=l?h:!1,m={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:c,metadata:new Na(i.createdAt,i.lastLoginAt),isAnonymous:f};Object.assign(n,m)}async function uy(n){const e=Re(n);await Fi(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function hy(n,e){return[...n.filter(r=>!e.some(s=>s.providerId===r.providerId)),...e]}function Cd(n){return n.map(e=>{var{providerId:t}=e,r=lc(e,["providerId"]);return{providerId:t,uid:r.rawId||"",displayName:r.displayName||null,email:r.email||null,phoneNumber:r.phoneNumber||null,photoURL:r.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function dy(n,e){const t=await Sd(n,{},async()=>{const r=Ms({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:s,apiKey:i}=n.config,o=Rd(n,s,"/v1/token",`key=${i}`),c=await n._getAdditionalHeaders();return c["Content-Type"]="application/x-www-form-urlencoded",Ad.fetch()(o,{method:"POST",headers:c,body:r})});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function fy(n,e){return on(n,"POST","/v2/accounts:revokeToken",Bn(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ir{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){W(e.idToken,"internal-error"),W(typeof e.idToken<"u","internal-error"),W(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):wu(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){W(e.length!==0,"internal-error");const t=wu(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(W(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:r,refreshToken:s,expiresIn:i}=await dy(e,t);this.updateTokensAndExpiration(r,s,Number(i))}updateTokensAndExpiration(e,t,r){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+r*1e3}static fromJSON(e,t){const{refreshToken:r,accessToken:s,expirationTime:i}=t,o=new ir;return r&&(W(typeof r=="string","internal-error",{appName:e}),o.refreshToken=r),s&&(W(typeof s=="string","internal-error",{appName:e}),o.accessToken=s),i&&(W(typeof i=="number","internal-error",{appName:e}),o.expirationTime=i),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new ir,this.toJSON())}_performRefresh(){return bt("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mt(n,e){W(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class At{constructor(e){var{uid:t,auth:r,stsTokenManager:s}=e,i=lc(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new ly(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=r,this.stsTokenManager=s,this.accessToken=s.accessToken,this.displayName=i.displayName||null,this.email=i.email||null,this.emailVerified=i.emailVerified||!1,this.phoneNumber=i.phoneNumber||null,this.photoURL=i.photoURL||null,this.isAnonymous=i.isAnonymous||!1,this.tenantId=i.tenantId||null,this.providerData=i.providerData?[...i.providerData]:[],this.metadata=new Na(i.createdAt||void 0,i.lastLoginAt||void 0)}async getIdToken(e){const t=await Es(this,this.stsTokenManager.getToken(this.auth,e));return W(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return ay(this,e)}reload(){return uy(this)}_assign(e){this!==e&&(W(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>Object.assign({},t)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new At(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){W(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let r=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),r=!0),t&&await Fi(this),await this.auth._persistUserIfCurrent(this),r&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Tt(this.auth.app))return Promise.reject(Qt(this.auth));const e=await this.getIdToken();return await Es(this,oy(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var r,s,i,o,c,l,h,f;const m=(r=t.displayName)!==null&&r!==void 0?r:void 0,I=(s=t.email)!==null&&s!==void 0?s:void 0,S=(i=t.phoneNumber)!==null&&i!==void 0?i:void 0,D=(o=t.photoURL)!==null&&o!==void 0?o:void 0,N=(c=t.tenantId)!==null&&c!==void 0?c:void 0,P=(l=t._redirectEventId)!==null&&l!==void 0?l:void 0,H=(h=t.createdAt)!==null&&h!==void 0?h:void 0,K=(f=t.lastLoginAt)!==null&&f!==void 0?f:void 0,{uid:q,emailVerified:X,isAnonymous:V,providerData:M,stsTokenManager:v}=t;W(q&&v,e,"internal-error");const g=ir.fromJSON(this.name,v);W(typeof q=="string",e,"internal-error"),Mt(m,e.name),Mt(I,e.name),W(typeof X=="boolean",e,"internal-error"),W(typeof V=="boolean",e,"internal-error"),Mt(S,e.name),Mt(D,e.name),Mt(N,e.name),Mt(P,e.name),Mt(H,e.name),Mt(K,e.name);const _=new At({uid:q,auth:e,email:I,emailVerified:X,displayName:m,isAnonymous:V,photoURL:D,phoneNumber:S,tenantId:N,stsTokenManager:g,createdAt:H,lastLoginAt:K});return M&&Array.isArray(M)&&(_.providerData=M.map(E=>Object.assign({},E))),P&&(_._redirectEventId=P),_}static async _fromIdTokenResponse(e,t,r=!1){const s=new ir;s.updateFromServerResponse(t);const i=new At({uid:t.localId,auth:e,stsTokenManager:s,isAnonymous:r});return await Fi(i),i}static async _fromGetAccountInfoResponse(e,t,r){const s=t.users[0];W(s.localId!==void 0,"internal-error");const i=s.providerUserInfo!==void 0?Cd(s.providerUserInfo):[],o=!(s.email&&s.passwordHash)&&!(i!=null&&i.length),c=new ir;c.updateFromIdToken(r);const l=new At({uid:s.localId,auth:e,stsTokenManager:c,isAnonymous:o}),h={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:i,metadata:new Na(s.createdAt,s.lastLoginAt),isAnonymous:!(s.email&&s.passwordHash)&&!(i!=null&&i.length)};return Object.assign(l,h),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tu=new Map;function St(n){Pt(n instanceof Function,"Expected a class definition");let e=Tu.get(n);return e?(Pt(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,Tu.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kd{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}kd.type="NONE";const bu=kd;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ii(n,e,t){return`firebase:${n}:${e}:${t}`}class or{constructor(e,t,r){this.persistence=e,this.auth=t,this.userKey=r;const{config:s,name:i}=this.auth;this.fullUserKey=Ii(this.userKey,s.apiKey,i),this.fullPersistenceKey=Ii("persistence",s.apiKey,i),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);return e?At._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,r="authUser"){if(!t.length)return new or(St(bu),e,r);const s=(await Promise.all(t.map(async h=>{if(await h._isAvailable())return h}))).filter(h=>h);let i=s[0]||St(bu);const o=Ii(r,e.config.apiKey,e.name);let c=null;for(const h of t)try{const f=await h._get(o);if(f){const m=At._fromJSON(e,f);h!==i&&(c=m),i=h;break}}catch{}const l=s.filter(h=>h._shouldAllowMigration);return!i._shouldAllowMigration||!l.length?new or(i,e,r):(i=l[0],c&&await i._set(o,c.toJSON()),await Promise.all(t.map(async h=>{if(h!==i)try{await h._remove(o)}catch{}})),new or(i,e,r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Au(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Nd(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(Dd(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Od(e))return"Blackberry";if(Md(e))return"Webos";if(fc(e))return"Safari";if((e.includes("chrome/")||Vd(e))&&!e.includes("edge/"))return"Chrome";if(xd(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,r=n.match(t);if((r==null?void 0:r.length)===2)return r[1]}return"Other"}function Dd(n=be()){return/firefox\//i.test(n)}function fc(n=be()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Vd(n=be()){return/crios\//i.test(n)}function Nd(n=be()){return/iemobile/i.test(n)}function xd(n=be()){return/android/i.test(n)}function Od(n=be()){return/blackberry/i.test(n)}function Md(n=be()){return/webos/i.test(n)}function uo(n=be()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function py(n=be()){var e;return uo(n)&&!!(!((e=window.navigator)===null||e===void 0)&&e.standalone)}function my(){return Dg()&&document.documentMode===10}function Ld(n=be()){return uo(n)||xd(n)||Md(n)||Od(n)||/windows phone/i.test(n)||Nd(n)}function gy(){try{return!!(window&&window!==window.top)}catch{return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fd(n,e=[]){let t;switch(n){case"Browser":t=Au(be());break;case"Worker":t=`${Au(be())}-${n}`;break;default:t=n}const r=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Cr}/${r}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _y{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const r=i=>new Promise((o,c)=>{try{const l=e(i);o(l)}catch(l){c(l)}});r.onAbort=t,this.queue.push(r);const s=this.queue.length-1;return()=>{this.queue[s]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const r of this.queue)await r(e),r.onAbort&&t.push(r.onAbort)}catch(r){t.reverse();for(const s of t)try{s()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:r==null?void 0:r.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yy(n,e={}){return on(n,"GET","/v2/passwordPolicy",Bn(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vy=6;class Iy{constructor(e){var t,r,s,i;const o=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(t=o.minPasswordLength)!==null&&t!==void 0?t:vy,o.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=o.maxPasswordLength),o.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=o.containsLowercaseCharacter),o.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=o.containsUppercaseCharacter),o.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=o.containsNumericCharacter),o.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=o.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(s=(r=e.allowedNonAlphanumericCharacters)===null||r===void 0?void 0:r.join(""))!==null&&s!==void 0?s:"",this.forceUpgradeOnSignin=(i=e.forceUpgradeOnSignin)!==null&&i!==void 0?i:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,r,s,i,o,c;const l={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,l),this.validatePasswordCharacterOptions(e,l),l.isValid&&(l.isValid=(t=l.meetsMinPasswordLength)!==null&&t!==void 0?t:!0),l.isValid&&(l.isValid=(r=l.meetsMaxPasswordLength)!==null&&r!==void 0?r:!0),l.isValid&&(l.isValid=(s=l.containsLowercaseLetter)!==null&&s!==void 0?s:!0),l.isValid&&(l.isValid=(i=l.containsUppercaseLetter)!==null&&i!==void 0?i:!0),l.isValid&&(l.isValid=(o=l.containsNumericCharacter)!==null&&o!==void 0?o:!0),l.isValid&&(l.isValid=(c=l.containsNonAlphanumericCharacter)!==null&&c!==void 0?c:!0),l}validatePasswordLengthOptions(e,t){const r=this.customStrengthOptions.minPasswordLength,s=this.customStrengthOptions.maxPasswordLength;r&&(t.meetsMinPasswordLength=e.length>=r),s&&(t.meetsMaxPasswordLength=e.length<=s)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let r;for(let s=0;s<e.length;s++)r=e.charAt(s),this.updatePasswordCharacterOptionsStatuses(t,r>="a"&&r<="z",r>="A"&&r<="Z",r>="0"&&r<="9",this.allowedNonAlphanumericCharacters.includes(r))}updatePasswordCharacterOptionsStatuses(e,t,r,s,i){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=r)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=s)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ey{constructor(e,t,r,s){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=r,this.config=s,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Su(this),this.idTokenSubscription=new Su(this),this.beforeStateQueue=new _y(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Td,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=s.sdkClientVersion}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=St(t)),this._initializationPromise=this.queue(async()=>{var r,s;if(!this._deleted&&(this.persistenceManager=await or.create(this,e),!this._deleted)){if(!((r=this._popupRedirectResolver)===null||r===void 0)&&r._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((s=this.currentUser)===null||s===void 0?void 0:s.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Pd(this,{idToken:e}),r=await At._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(r)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var t;if(Tt(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(c=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(c,c))}):this.directlySetCurrentUser(null)}const r=await this.assertedPersistence.getCurrentUser();let s=r,i=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(t=this.redirectUser)===null||t===void 0?void 0:t._redirectEventId,c=s==null?void 0:s._redirectEventId,l=await this.tryRedirectSignIn(e);(!o||o===c)&&(l!=null&&l.user)&&(s=l.user,i=!0)}if(!s)return this.directlySetCurrentUser(null);if(!s._redirectEventId){if(i)try{await this.beforeStateQueue.runMiddleware(s)}catch(o){s=r,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return s?this.reloadAndSetCurrentUserOrClear(s):this.directlySetCurrentUser(null)}return W(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===s._redirectEventId?this.directlySetCurrentUser(s):this.reloadAndSetCurrentUserOrClear(s)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Fi(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Z_()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Tt(this.app))return Promise.reject(Qt(this));const t=e?Re(e):null;return t&&W(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&W(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Tt(this.app)?Promise.reject(Qt(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Tt(this.app)?Promise.reject(Qt(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(St(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await yy(this),t=new Iy(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new Os("auth","Firebase",e())}onAuthStateChanged(e,t,r){return this.registerStateListener(this.authStateSubscription,e,t,r)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,r){return this.registerStateListener(this.idTokenSubscription,e,t,r)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const r=this.onAuthStateChanged(()=>{r(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),r={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(r.tenantId=this.tenantId),await fy(this,r)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,t){const r=await this.getOrInitRedirectPersistenceManager(t);return e===null?r.removeCurrentUser():r.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&St(e)||this._popupRedirectResolver;W(t,this,"argument-error"),this.redirectPersistenceManager=await or.create(this,[St(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,r;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)===null||t===void 0?void 0:t._redirectEventId)===e?this._currentUser:((r=this.redirectUser)===null||r===void 0?void 0:r._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const r=(t=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&t!==void 0?t:null;this.lastNotifiedUid!==r&&(this.lastNotifiedUid=r,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,r,s){if(this._deleted)return()=>{};const i=typeof t=="function"?t:t.next.bind(t);let o=!1;const c=this._isInitialized?Promise.resolve():this._initializationPromise;if(W(c,this,"internal-error"),c.then(()=>{o||i(this.currentUser)}),typeof t=="function"){const l=e.addObserver(t,r,s);return()=>{o=!0,l()}}else{const l=e.addObserver(t);return()=>{o=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return W(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Fd(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const r=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());r&&(t["X-Firebase-Client"]=r);const s=await this._getAppCheckToken();return s&&(t["X-Firebase-AppCheck"]=s),t}async _getAppCheckToken(){var e;const t=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return t!=null&&t.error&&J_(`Error while retrieving App Check token: ${t.error}`),t==null?void 0:t.token}}function kr(n){return Re(n)}class Su{constructor(e){this.auth=e,this.observer=null,this.addObserver=Lg(t=>this.observer=t)}get next(){return W(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ho={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function wy(n){ho=n}function $d(n){return ho.loadJS(n)}function Ty(){return ho.recaptchaEnterpriseScript}function by(){return ho.gapiScript}function Ay(n){return`__${n}${Math.floor(Math.random()*1e6)}`}const Sy="recaptcha-enterprise",Ry="NO_RECAPTCHA";class Py{constructor(e){this.type=Sy,this.auth=kr(e)}async verify(e="verify",t=!1){async function r(i){if(!t){if(i.tenantId==null&&i._agentRecaptchaConfig!=null)return i._agentRecaptchaConfig.siteKey;if(i.tenantId!=null&&i._tenantRecaptchaConfigs[i.tenantId]!==void 0)return i._tenantRecaptchaConfigs[i.tenantId].siteKey}return new Promise(async(o,c)=>{iy(i,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)c(new Error("recaptcha Enterprise site key undefined"));else{const h=new sy(l);return i.tenantId==null?i._agentRecaptchaConfig=h:i._tenantRecaptchaConfigs[i.tenantId]=h,o(h.siteKey)}}).catch(l=>{c(l)})})}function s(i,o,c){const l=window.grecaptcha;Eu(l)?l.enterprise.ready(()=>{l.enterprise.execute(i,{action:e}).then(h=>{o(h)}).catch(()=>{o(Ry)})}):c(Error("No reCAPTCHA enterprise script loaded."))}return new Promise((i,o)=>{r(this.auth).then(c=>{if(!t&&Eu(window.grecaptcha))s(c,i,o);else{if(typeof window>"u"){o(new Error("RecaptchaVerifier is only supported in browser"));return}let l=Ty();l.length!==0&&(l+=c),$d(l).then(()=>{s(c,i,o)}).catch(h=>{o(h)})}}).catch(c=>{o(c)})})}}async function Ru(n,e,t,r=!1){const s=new Py(n);let i;try{i=await s.verify(t)}catch{i=await s.verify(t,!0)}const o=Object.assign({},e);return r?Object.assign(o,{captchaResp:i}):Object.assign(o,{captchaResponse:i}),Object.assign(o,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(o,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),o}async function Pu(n,e,t,r){var s;if(!((s=n._getRecaptchaConfig())===null||s===void 0)&&s.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const i=await Ru(n,e,t,t==="getOobCode");return r(n,i)}else return r(n,e).catch(async i=>{if(i.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const o=await Ru(n,e,t,t==="getOobCode");return r(n,o)}else return Promise.reject(i)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cy(n,e){const t=cc(n,"auth");if(t.isInitialized()){const s=t.getImmediate(),i=t.getOptions();if(vs(i,e??{}))return s;ct(s,"already-initialized")}return t.initialize({options:e})}function ky(n,e){const t=(e==null?void 0:e.persistence)||[],r=(Array.isArray(t)?t:[t]).map(St);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(r,e==null?void 0:e.popupRedirectResolver)}function Dy(n,e,t){const r=kr(n);W(r._canInitEmulator,r,"emulator-config-failed"),W(/^https?:\/\//.test(e),r,"invalid-emulator-scheme");const s=!1,i=Ud(e),{host:o,port:c}=Vy(e),l=c===null?"":`:${c}`;r.config.emulator={url:`${i}//${o}${l}/`},r.settings.appVerificationDisabledForTesting=!0,r.emulatorConfig=Object.freeze({host:o,port:c,protocol:i.replace(":",""),options:Object.freeze({disableWarnings:s})}),Ny()}function Ud(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function Vy(n){const e=Ud(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const r=t[2].split("@").pop()||"",s=/^(\[[^\]]+\])(:|$)/.exec(r);if(s){const i=s[1];return{host:i,port:Cu(r.substr(i.length+1))}}else{const[i,o]=r.split(":");return{host:i,port:Cu(o)}}}function Cu(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function Ny(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pc{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return bt("not implemented")}_getIdTokenResponse(e){return bt("not implemented")}_linkToIdToken(e,t){return bt("not implemented")}_getReauthenticationResolver(e){return bt("not implemented")}}async function xy(n,e){return on(n,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Oy(n,e){return lo(n,"POST","/v1/accounts:signInWithPassword",Bn(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function My(n,e){return lo(n,"POST","/v1/accounts:signInWithEmailLink",Bn(n,e))}async function Ly(n,e){return lo(n,"POST","/v1/accounts:signInWithEmailLink",Bn(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ws extends pc{constructor(e,t,r,s=null){super("password",r),this._email=e,this._password=t,this._tenantId=s}static _fromEmailAndPassword(e,t){return new ws(e,t,"password")}static _fromEmailAndCode(e,t,r=null){return new ws(e,t,"emailLink",r)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Pu(e,t,"signInWithPassword",Oy);case"emailLink":return My(e,{email:this._email,oobCode:this._password});default:ct(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const r={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Pu(e,r,"signUpPassword",xy);case"emailLink":return Ly(e,{idToken:t,email:this._email,oobCode:this._password});default:ct(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ar(n,e){return lo(n,"POST","/v1/accounts:signInWithIdp",Bn(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fy="http://localhost";class kn extends pc{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new kn(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):ct("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:r,signInMethod:s}=t,i=lc(t,["providerId","signInMethod"]);if(!r||!s)return null;const o=new kn(r,s);return o.idToken=i.idToken||void 0,o.accessToken=i.accessToken||void 0,o.secret=i.secret,o.nonce=i.nonce,o.pendingToken=i.pendingToken||null,o}_getIdTokenResponse(e){const t=this.buildRequest();return ar(e,t)}_linkToIdToken(e,t){const r=this.buildRequest();return r.idToken=t,ar(e,r)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,ar(e,t)}buildRequest(){const e={requestUri:Fy,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=Ms(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $y(n){switch(n){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function Uy(n){const e=ss(is(n)).link,t=e?ss(is(e)).deep_link_id:null,r=ss(is(n)).deep_link_id;return(r?ss(is(r)).link:null)||r||t||e||n}class mc{constructor(e){var t,r,s,i,o,c;const l=ss(is(e)),h=(t=l.apiKey)!==null&&t!==void 0?t:null,f=(r=l.oobCode)!==null&&r!==void 0?r:null,m=$y((s=l.mode)!==null&&s!==void 0?s:null);W(h&&f&&m,"argument-error"),this.apiKey=h,this.operation=m,this.code=f,this.continueUrl=(i=l.continueUrl)!==null&&i!==void 0?i:null,this.languageCode=(o=l.languageCode)!==null&&o!==void 0?o:null,this.tenantId=(c=l.tenantId)!==null&&c!==void 0?c:null}static parseLink(e){const t=Uy(e);try{return new mc(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dr{constructor(){this.providerId=Dr.PROVIDER_ID}static credential(e,t){return ws._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const r=mc.parseLink(t);return W(r,"argument-error"),ws._fromEmailAndCode(e,r.code,r.tenantId)}}Dr.PROVIDER_ID="password";Dr.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Dr.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bd{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fs extends Bd{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $t extends Fs{constructor(){super("facebook.com")}static credential(e){return kn._fromParams({providerId:$t.PROVIDER_ID,signInMethod:$t.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return $t.credentialFromTaggedObject(e)}static credentialFromError(e){return $t.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return $t.credential(e.oauthAccessToken)}catch{return null}}}$t.FACEBOOK_SIGN_IN_METHOD="facebook.com";$t.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ut extends Fs{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return kn._fromParams({providerId:Ut.PROVIDER_ID,signInMethod:Ut.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return Ut.credentialFromTaggedObject(e)}static credentialFromError(e){return Ut.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:r}=e;if(!t&&!r)return null;try{return Ut.credential(t,r)}catch{return null}}}Ut.GOOGLE_SIGN_IN_METHOD="google.com";Ut.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bt extends Fs{constructor(){super("github.com")}static credential(e){return kn._fromParams({providerId:Bt.PROVIDER_ID,signInMethod:Bt.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Bt.credentialFromTaggedObject(e)}static credentialFromError(e){return Bt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Bt.credential(e.oauthAccessToken)}catch{return null}}}Bt.GITHUB_SIGN_IN_METHOD="github.com";Bt.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qt extends Fs{constructor(){super("twitter.com")}static credential(e,t){return kn._fromParams({providerId:qt.PROVIDER_ID,signInMethod:qt.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return qt.credentialFromTaggedObject(e)}static credentialFromError(e){return qt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:r}=e;if(!t||!r)return null;try{return qt.credential(t,r)}catch{return null}}}qt.TWITTER_SIGN_IN_METHOD="twitter.com";qt.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hr{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,r,s=!1){const i=await At._fromIdTokenResponse(e,r,s),o=ku(r);return new hr({user:i,providerId:o,_tokenResponse:r,operationType:t})}static async _forOperation(e,t,r){await e._updateTokensIfNecessary(r,!0);const s=ku(r);return new hr({user:e,providerId:s,_tokenResponse:r,operationType:t})}}function ku(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $i extends kt{constructor(e,t,r,s){var i;super(t.code,t.message),this.operationType=r,this.user=s,Object.setPrototypeOf(this,$i.prototype),this.customData={appName:e.name,tenantId:(i=e.tenantId)!==null&&i!==void 0?i:void 0,_serverResponse:t.customData._serverResponse,operationType:r}}static _fromErrorAndOperation(e,t,r,s){return new $i(e,t,r,s)}}function qd(n,e,t,r){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(i=>{throw i.code==="auth/multi-factor-auth-required"?$i._fromErrorAndOperation(n,i,e,r):i})}async function By(n,e,t=!1){const r=await Es(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return hr._forOperation(n,"link",r)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qy(n,e,t=!1){const{auth:r}=n;if(Tt(r.app))return Promise.reject(Qt(r));const s="reauthenticate";try{const i=await Es(n,qd(r,s,e,n),t);W(i.idToken,r,"internal-error");const o=dc(i.idToken);W(o,r,"internal-error");const{sub:c}=o;return W(n.uid===c,r,"user-mismatch"),hr._forOperation(n,s,i)}catch(i){throw(i==null?void 0:i.code)==="auth/user-not-found"&&ct(r,"user-mismatch"),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function jd(n,e,t=!1){if(Tt(n.app))return Promise.reject(Qt(n));const r="signIn",s=await qd(n,r,e),i=await hr._fromIdTokenResponse(n,r,s);return t||await n._updateCurrentUser(i.user),i}async function jy(n,e){return jd(kr(n),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Gy(n){const e=kr(n);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}function zy(n,e,t){return Tt(n.app)?Promise.reject(Qt(n)):jy(Re(n),Dr.credential(e,t)).catch(async r=>{throw r.code==="auth/password-does-not-meet-requirements"&&Gy(n),r})}function Ky(n,e,t,r){return Re(n).onIdTokenChanged(e,t,r)}function Wy(n,e,t){return Re(n).beforeAuthStateChanged(e,t)}function Hy(n,e,t,r){return Re(n).onAuthStateChanged(e,t,r)}function Qy(n){return Re(n).signOut()}const Ui="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gd{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Ui,"1"),this.storage.removeItem(Ui),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jy(){const n=be();return fc(n)||uo(n)}const Yy=1e3,Xy=10;class zd extends Gd{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=Jy()&&gy(),this.fallbackToPolling=Ld(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const r=this.storage.getItem(t),s=this.localCache[t];r!==s&&e(t,s,r)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((o,c,l)=>{this.notifyListeners(o,l)});return}const r=e.key;if(t?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const o=this.storage.getItem(r);if(e.newValue!==o)e.newValue!==null?this.storage.setItem(r,e.newValue):this.storage.removeItem(r);else if(this.localCache[r]===e.newValue&&!t)return}const s=()=>{const o=this.storage.getItem(r);!t&&this.localCache[r]===o||this.notifyListeners(r,o)},i=this.storage.getItem(r);my()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(s,Xy):s()}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const s of Array.from(r))s(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,r)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:r}),!0)})},Yy)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}zd.type="LOCAL";const Zy=zd;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kd extends Gd{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Kd.type="SESSION";const Wd=Kd;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ev(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fo{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(s=>s.isListeningto(e));if(t)return t;const r=new fo(e);return this.receivers.push(r),r}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:r,eventType:s,data:i}=t.data,o=this.handlersMap[s];if(!(o!=null&&o.size))return;t.ports[0].postMessage({status:"ack",eventId:r,eventType:s});const c=Array.from(o).map(async h=>h(t.origin,i)),l=await ev(c);t.ports[0].postMessage({status:"done",eventId:r,eventType:s,response:l})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}fo.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gc(n="",e=10){let t="";for(let r=0;r<e;r++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tv{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,r=50){const s=typeof MessageChannel<"u"?new MessageChannel:null;if(!s)throw new Error("connection_unavailable");let i,o;return new Promise((c,l)=>{const h=gc("",20);s.port1.start();const f=setTimeout(()=>{l(new Error("unsupported_event"))},r);o={messageChannel:s,onMessage(m){const I=m;if(I.data.eventId===h)switch(I.data.status){case"ack":clearTimeout(f),i=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),c(I.data.response);break;default:clearTimeout(f),clearTimeout(i),l(new Error("invalid_response"));break}}},this.handlers.add(o),s.port1.addEventListener("message",o.onMessage),this.target.postMessage({eventType:e,eventId:h,data:t},[s.port2])}).finally(()=>{o&&this.removeMessageHandler(o)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _t(){return window}function nv(n){_t().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hd(){return typeof _t().WorkerGlobalScope<"u"&&typeof _t().importScripts=="function"}async function rv(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function sv(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)===null||n===void 0?void 0:n.controller)||null}function iv(){return Hd()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qd="firebaseLocalStorageDb",ov=1,Bi="firebaseLocalStorage",Jd="fbase_key";class $s{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function po(n,e){return n.transaction([Bi],e?"readwrite":"readonly").objectStore(Bi)}function av(){const n=indexedDB.deleteDatabase(Qd);return new $s(n).toPromise()}function xa(){const n=indexedDB.open(Qd,ov);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const r=n.result;try{r.createObjectStore(Bi,{keyPath:Jd})}catch(s){t(s)}}),n.addEventListener("success",async()=>{const r=n.result;r.objectStoreNames.contains(Bi)?e(r):(r.close(),await av(),e(await xa()))})})}async function Du(n,e,t){const r=po(n,!0).put({[Jd]:e,value:t});return new $s(r).toPromise()}async function cv(n,e){const t=po(n,!1).get(e),r=await new $s(t).toPromise();return r===void 0?null:r.value}function Vu(n,e){const t=po(n,!0).delete(e);return new $s(t).toPromise()}const lv=800,uv=3;class Yd{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await xa(),this.db)}async _withRetries(e){let t=0;for(;;)try{const r=await this._openDb();return await e(r)}catch(r){if(t++>uv)throw r;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Hd()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=fo._getInstance(iv()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var e,t;if(this.activeServiceWorker=await rv(),!this.activeServiceWorker)return;this.sender=new tv(this.activeServiceWorker);const r=await this.sender._send("ping",{},800);r&&!((e=r[0])===null||e===void 0)&&e.fulfilled&&!((t=r[0])===null||t===void 0)&&t.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||sv()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await xa();return await Du(e,Ui,"1"),await Vu(e,Ui),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(r=>Du(r,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(r=>cv(r,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Vu(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(s=>{const i=po(s,!1).getAll();return new $s(i).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],r=new Set;if(e.length!==0)for(const{fbase_key:s,value:i}of e)r.add(s),JSON.stringify(this.localCache[s])!==JSON.stringify(i)&&(this.notifyListeners(s,i),t.push(s));for(const s of Object.keys(this.localCache))this.localCache[s]&&!r.has(s)&&(this.notifyListeners(s,null),t.push(s));return t}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const s of Array.from(r))s(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),lv)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Yd.type="LOCAL";const hv=Yd;new Ls(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dv(n,e){return e?St(e):(W(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _c extends pc{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return ar(e,this._buildIdpRequest())}_linkToIdToken(e,t){return ar(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return ar(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function fv(n){return jd(n.auth,new _c(n),n.bypassAuthState)}function pv(n){const{auth:e,user:t}=n;return W(t,e,"internal-error"),qy(t,new _c(n),n.bypassAuthState)}async function mv(n){const{auth:e,user:t}=n;return W(t,e,"internal-error"),By(t,new _c(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xd{constructor(e,t,r,s,i=!1){this.auth=e,this.resolver=r,this.user=s,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(r){this.reject(r)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:r,postBody:s,tenantId:i,error:o,type:c}=e;if(o){this.reject(o);return}const l={auth:this.auth,requestUri:t,sessionId:r,tenantId:i||void 0,postBody:s||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(c)(l))}catch(h){this.reject(h)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return fv;case"linkViaPopup":case"linkViaRedirect":return mv;case"reauthViaPopup":case"reauthViaRedirect":return pv;default:ct(this.auth,"internal-error")}}resolve(e){Pt(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Pt(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gv=new Ls(2e3,1e4);class sr extends Xd{constructor(e,t,r,s,i){super(e,t,s,i),this.provider=r,this.authWindow=null,this.pollId=null,sr.currentPopupAction&&sr.currentPopupAction.cancel(),sr.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return W(e,this.auth,"internal-error"),e}async onExecution(){Pt(this.filter.length===1,"Popup operations only handle one event");const e=gc();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(gt(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)===null||e===void 0?void 0:e.associatedEvent)||null}cancel(){this.reject(gt(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,sr.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,r;if(!((r=(t=this.authWindow)===null||t===void 0?void 0:t.window)===null||r===void 0)&&r.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(gt(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,gv.get())};e()}}sr.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _v="pendingRedirect",Ei=new Map;class yv extends Xd{constructor(e,t,r=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,r),this.eventId=null}async execute(){let e=Ei.get(this.auth._key());if(!e){try{const r=await vv(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(r)}catch(t){e=()=>Promise.reject(t)}Ei.set(this.auth._key(),e)}return this.bypassAuthState||Ei.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function vv(n,e){const t=wv(e),r=Ev(n);if(!await r._isAvailable())return!1;const s=await r._get(t)==="true";return await r._remove(t),s}function Iv(n,e){Ei.set(n._key(),e)}function Ev(n){return St(n._redirectPersistence)}function wv(n){return Ii(_v,n.config.apiKey,n.name)}async function Tv(n,e,t=!1){if(Tt(n.app))return Promise.reject(Qt(n));const r=kr(n),s=dv(r,e),o=await new yv(r,s,t).execute();return o&&!t&&(delete o.user._redirectEventId,await r._persistUserIfCurrent(o.user),await r._setRedirectUser(null,e)),o}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bv=10*60*1e3;class Av{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(r=>{this.isEventForConsumer(e,r)&&(t=!0,this.sendToConsumer(e,r),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!Sv(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var r;if(e.error&&!Zd(e)){const s=((r=e.error.code)===null||r===void 0?void 0:r.split("auth/")[1])||"internal-error";t.onError(gt(this.auth,s))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const r=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&r}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=bv&&this.cachedEventUids.clear(),this.cachedEventUids.has(Nu(e))}saveEventToCache(e){this.cachedEventUids.add(Nu(e)),this.lastProcessedEventTime=Date.now()}}function Nu(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function Zd({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function Sv(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Zd(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rv(n,e={}){return on(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pv=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Cv=/^https?/;async function kv(n){if(n.config.emulator)return;const{authorizedDomains:e}=await Rv(n);for(const t of e)try{if(Dv(t))return}catch{}ct(n,"unauthorized-domain")}function Dv(n){const e=Va(),{protocol:t,hostname:r}=new URL(e);if(n.startsWith("chrome-extension://")){const o=new URL(n);return o.hostname===""&&r===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&o.hostname===r}if(!Cv.test(t))return!1;if(Pv.test(n))return r===n;const s=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+s+"|"+s+")$","i").test(r)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vv=new Ls(3e4,6e4);function xu(){const n=_t().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function Nv(n){return new Promise((e,t)=>{var r,s,i;function o(){xu(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{xu(),t(gt(n,"network-request-failed"))},timeout:Vv.get()})}if(!((s=(r=_t().gapi)===null||r===void 0?void 0:r.iframes)===null||s===void 0)&&s.Iframe)e(gapi.iframes.getContext());else if(!((i=_t().gapi)===null||i===void 0)&&i.load)o();else{const c=Ay("iframefcb");return _t()[c]=()=>{gapi.load?o():t(gt(n,"network-request-failed"))},$d(`${by()}?onload=${c}`).catch(l=>t(l))}}).catch(e=>{throw wi=null,e})}let wi=null;function xv(n){return wi=wi||Nv(n),wi}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ov=new Ls(5e3,15e3),Mv="__/auth/iframe",Lv="emulator/auth/iframe",Fv={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},$v=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function Uv(n){const e=n.config;W(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?hc(e,Lv):`https://${n.config.authDomain}/${Mv}`,r={apiKey:e.apiKey,appName:n.name,v:Cr},s=$v.get(n.config.apiHost);s&&(r.eid=s);const i=n._getFrameworks();return i.length&&(r.fw=i.join(",")),`${t}?${Ms(r).slice(1)}`}async function Bv(n){const e=await xv(n),t=_t().gapi;return W(t,n,"internal-error"),e.open({where:document.body,url:Uv(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:Fv,dontclear:!0},r=>new Promise(async(s,i)=>{await r.restyle({setHideOnLeave:!1});const o=gt(n,"network-request-failed"),c=_t().setTimeout(()=>{i(o)},Ov.get());function l(){_t().clearTimeout(c),s(r)}r.ping(l).then(l,()=>{i(o)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qv={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},jv=500,Gv=600,zv="_blank",Kv="http://localhost";class Ou{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function Wv(n,e,t,r=jv,s=Gv){const i=Math.max((window.screen.availHeight-s)/2,0).toString(),o=Math.max((window.screen.availWidth-r)/2,0).toString();let c="";const l=Object.assign(Object.assign({},qv),{width:r.toString(),height:s.toString(),top:i,left:o}),h=be().toLowerCase();t&&(c=Vd(h)?zv:t),Dd(h)&&(e=e||Kv,l.scrollbars="yes");const f=Object.entries(l).reduce((I,[S,D])=>`${I}${S}=${D},`,"");if(py(h)&&c!=="_self")return Hv(e||"",c),new Ou(null);const m=window.open(e||"",c,f);W(m,n,"popup-blocked");try{m.focus()}catch{}return new Ou(m)}function Hv(n,e){const t=document.createElement("a");t.href=n,t.target=e;const r=document.createEvent("MouseEvent");r.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(r)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qv="__/auth/handler",Jv="emulator/auth/handler",Yv=encodeURIComponent("fac");async function Mu(n,e,t,r,s,i){W(n.config.authDomain,n,"auth-domain-config-required"),W(n.config.apiKey,n,"invalid-api-key");const o={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:r,v:Cr,eventId:s};if(e instanceof Bd){e.setDefaultLanguage(n.languageCode),o.providerId=e.providerId||"",Mg(e.getCustomParameters())||(o.customParameters=JSON.stringify(e.getCustomParameters()));for(const[f,m]of Object.entries({}))o[f]=m}if(e instanceof Fs){const f=e.getScopes().filter(m=>m!=="");f.length>0&&(o.scopes=f.join(","))}n.tenantId&&(o.tid=n.tenantId);const c=o;for(const f of Object.keys(c))c[f]===void 0&&delete c[f];const l=await n._getAppCheckToken(),h=l?`#${Yv}=${encodeURIComponent(l)}`:"";return`${Xv(n)}?${Ms(c).slice(1)}${h}`}function Xv({config:n}){return n.emulator?hc(n,Jv):`https://${n.authDomain}/${Qv}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ga="webStorageSupport";class Zv{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Wd,this._completeRedirectFn=Tv,this._overrideRedirectResult=Iv}async _openPopup(e,t,r,s){var i;Pt((i=this.eventManagers[e._key()])===null||i===void 0?void 0:i.manager,"_initialize() not called before _openPopup()");const o=await Mu(e,t,r,Va(),s);return Wv(e,o,gc())}async _openRedirect(e,t,r,s){await this._originValidation(e);const i=await Mu(e,t,r,Va(),s);return nv(i),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:s,promise:i}=this.eventManagers[t];return s?Promise.resolve(s):(Pt(i,"If manager is not set, promise should be"),i)}const r=this.initAndGetManager(e);return this.eventManagers[t]={promise:r},r.catch(()=>{delete this.eventManagers[t]}),r}async initAndGetManager(e){const t=await Bv(e),r=new Av(e);return t.register("authEvent",s=>(W(s==null?void 0:s.authEvent,e,"invalid-auth-event"),{status:r.onEvent(s.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:r},this.iframes[e._key()]=t,r}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(ga,{type:ga},s=>{var i;const o=(i=s==null?void 0:s[0])===null||i===void 0?void 0:i[ga];o!==void 0&&t(!!o),ct(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=kv(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Ld()||fc()||uo()}}const eI=Zv;var Lu="@firebase/auth",Fu="1.7.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tI{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(r=>{e((r==null?void 0:r.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){W(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nI(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function rI(n){ur(new Pn("auth",(e,{options:t})=>{const r=e.getProvider("app").getImmediate(),s=e.getProvider("heartbeat"),i=e.getProvider("app-check-internal"),{apiKey:o,authDomain:c}=r.options;W(o&&!o.includes(":"),"invalid-api-key",{appName:r.name});const l={apiKey:o,authDomain:c,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Fd(n)},h=new Ey(r,s,i,l);return ky(h,t),h},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,r)=>{e.getProvider("auth-internal").initialize()})),ur(new Pn("auth-internal",e=>{const t=kr(e.getProvider("auth").getImmediate());return(r=>new tI(r))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Ht(Lu,Fu,nI(n)),Ht(Lu,Fu,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sI=5*60,iI=pd("authIdTokenMaxAge")||sI;let $u=null;const oI=n=>async e=>{const t=e&&await e.getIdTokenResult(),r=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(r&&r>iI)return;const s=t==null?void 0:t.token;$u!==s&&($u=s,await fetch(n,{method:s?"POST":"DELETE",headers:s?{Authorization:`Bearer ${s}`}:{}}))};function aI(n=L_()){const e=cc(n,"auth");if(e.isInitialized())return e.getImmediate();const t=Cy(n,{popupRedirectResolver:eI,persistence:[hv,Zy,Wd]}),r=pd("authTokenSyncURL");if(r&&typeof isSecureContext=="boolean"&&isSecureContext){const i=new URL(r,location.origin);if(location.origin===i.origin){const o=oI(i.toString());Wy(t,o,()=>o(t.currentUser)),Ky(t,c=>o(c))}}const s=Ag("auth");return s&&Dy(t,`http://${s}`),t}function cI(){var n,e;return(e=(n=document.getElementsByTagName("head"))===null||n===void 0?void 0:n[0])!==null&&e!==void 0?e:document}wy({loadJS(n){return new Promise((e,t)=>{const r=document.createElement("script");r.setAttribute("src",n),r.onload=e,r.onerror=s=>{const i=gt("internal-error");i.customData=s,t(i)},r.type="text/javascript",r.charset="UTF-8",cI().appendChild(r)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});rI("Browser");var Uu=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var An,ef;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(v,g){function _(){}_.prototype=g.prototype,v.D=g.prototype,v.prototype=new _,v.prototype.constructor=v,v.C=function(E,w,T){for(var y=Array(arguments.length-2),ze=2;ze<arguments.length;ze++)y[ze-2]=arguments[ze];return g.prototype[w].apply(E,y)}}function t(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}e(r,t),r.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function s(v,g,_){_||(_=0);var E=Array(16);if(typeof g=="string")for(var w=0;16>w;++w)E[w]=g.charCodeAt(_++)|g.charCodeAt(_++)<<8|g.charCodeAt(_++)<<16|g.charCodeAt(_++)<<24;else for(w=0;16>w;++w)E[w]=g[_++]|g[_++]<<8|g[_++]<<16|g[_++]<<24;g=v.g[0],_=v.g[1],w=v.g[2];var T=v.g[3],y=g+(T^_&(w^T))+E[0]+3614090360&4294967295;g=_+(y<<7&4294967295|y>>>25),y=T+(w^g&(_^w))+E[1]+3905402710&4294967295,T=g+(y<<12&4294967295|y>>>20),y=w+(_^T&(g^_))+E[2]+606105819&4294967295,w=T+(y<<17&4294967295|y>>>15),y=_+(g^w&(T^g))+E[3]+3250441966&4294967295,_=w+(y<<22&4294967295|y>>>10),y=g+(T^_&(w^T))+E[4]+4118548399&4294967295,g=_+(y<<7&4294967295|y>>>25),y=T+(w^g&(_^w))+E[5]+1200080426&4294967295,T=g+(y<<12&4294967295|y>>>20),y=w+(_^T&(g^_))+E[6]+2821735955&4294967295,w=T+(y<<17&4294967295|y>>>15),y=_+(g^w&(T^g))+E[7]+4249261313&4294967295,_=w+(y<<22&4294967295|y>>>10),y=g+(T^_&(w^T))+E[8]+1770035416&4294967295,g=_+(y<<7&4294967295|y>>>25),y=T+(w^g&(_^w))+E[9]+2336552879&4294967295,T=g+(y<<12&4294967295|y>>>20),y=w+(_^T&(g^_))+E[10]+4294925233&4294967295,w=T+(y<<17&4294967295|y>>>15),y=_+(g^w&(T^g))+E[11]+2304563134&4294967295,_=w+(y<<22&4294967295|y>>>10),y=g+(T^_&(w^T))+E[12]+1804603682&4294967295,g=_+(y<<7&4294967295|y>>>25),y=T+(w^g&(_^w))+E[13]+4254626195&4294967295,T=g+(y<<12&4294967295|y>>>20),y=w+(_^T&(g^_))+E[14]+2792965006&4294967295,w=T+(y<<17&4294967295|y>>>15),y=_+(g^w&(T^g))+E[15]+1236535329&4294967295,_=w+(y<<22&4294967295|y>>>10),y=g+(w^T&(_^w))+E[1]+4129170786&4294967295,g=_+(y<<5&4294967295|y>>>27),y=T+(_^w&(g^_))+E[6]+3225465664&4294967295,T=g+(y<<9&4294967295|y>>>23),y=w+(g^_&(T^g))+E[11]+643717713&4294967295,w=T+(y<<14&4294967295|y>>>18),y=_+(T^g&(w^T))+E[0]+3921069994&4294967295,_=w+(y<<20&4294967295|y>>>12),y=g+(w^T&(_^w))+E[5]+3593408605&4294967295,g=_+(y<<5&4294967295|y>>>27),y=T+(_^w&(g^_))+E[10]+38016083&4294967295,T=g+(y<<9&4294967295|y>>>23),y=w+(g^_&(T^g))+E[15]+3634488961&4294967295,w=T+(y<<14&4294967295|y>>>18),y=_+(T^g&(w^T))+E[4]+3889429448&4294967295,_=w+(y<<20&4294967295|y>>>12),y=g+(w^T&(_^w))+E[9]+568446438&4294967295,g=_+(y<<5&4294967295|y>>>27),y=T+(_^w&(g^_))+E[14]+3275163606&4294967295,T=g+(y<<9&4294967295|y>>>23),y=w+(g^_&(T^g))+E[3]+4107603335&4294967295,w=T+(y<<14&4294967295|y>>>18),y=_+(T^g&(w^T))+E[8]+1163531501&4294967295,_=w+(y<<20&4294967295|y>>>12),y=g+(w^T&(_^w))+E[13]+2850285829&4294967295,g=_+(y<<5&4294967295|y>>>27),y=T+(_^w&(g^_))+E[2]+4243563512&4294967295,T=g+(y<<9&4294967295|y>>>23),y=w+(g^_&(T^g))+E[7]+1735328473&4294967295,w=T+(y<<14&4294967295|y>>>18),y=_+(T^g&(w^T))+E[12]+2368359562&4294967295,_=w+(y<<20&4294967295|y>>>12),y=g+(_^w^T)+E[5]+4294588738&4294967295,g=_+(y<<4&4294967295|y>>>28),y=T+(g^_^w)+E[8]+2272392833&4294967295,T=g+(y<<11&4294967295|y>>>21),y=w+(T^g^_)+E[11]+1839030562&4294967295,w=T+(y<<16&4294967295|y>>>16),y=_+(w^T^g)+E[14]+4259657740&4294967295,_=w+(y<<23&4294967295|y>>>9),y=g+(_^w^T)+E[1]+2763975236&4294967295,g=_+(y<<4&4294967295|y>>>28),y=T+(g^_^w)+E[4]+1272893353&4294967295,T=g+(y<<11&4294967295|y>>>21),y=w+(T^g^_)+E[7]+4139469664&4294967295,w=T+(y<<16&4294967295|y>>>16),y=_+(w^T^g)+E[10]+3200236656&4294967295,_=w+(y<<23&4294967295|y>>>9),y=g+(_^w^T)+E[13]+681279174&4294967295,g=_+(y<<4&4294967295|y>>>28),y=T+(g^_^w)+E[0]+3936430074&4294967295,T=g+(y<<11&4294967295|y>>>21),y=w+(T^g^_)+E[3]+3572445317&4294967295,w=T+(y<<16&4294967295|y>>>16),y=_+(w^T^g)+E[6]+76029189&4294967295,_=w+(y<<23&4294967295|y>>>9),y=g+(_^w^T)+E[9]+3654602809&4294967295,g=_+(y<<4&4294967295|y>>>28),y=T+(g^_^w)+E[12]+3873151461&4294967295,T=g+(y<<11&4294967295|y>>>21),y=w+(T^g^_)+E[15]+530742520&4294967295,w=T+(y<<16&4294967295|y>>>16),y=_+(w^T^g)+E[2]+3299628645&4294967295,_=w+(y<<23&4294967295|y>>>9),y=g+(w^(_|~T))+E[0]+4096336452&4294967295,g=_+(y<<6&4294967295|y>>>26),y=T+(_^(g|~w))+E[7]+1126891415&4294967295,T=g+(y<<10&4294967295|y>>>22),y=w+(g^(T|~_))+E[14]+2878612391&4294967295,w=T+(y<<15&4294967295|y>>>17),y=_+(T^(w|~g))+E[5]+4237533241&4294967295,_=w+(y<<21&4294967295|y>>>11),y=g+(w^(_|~T))+E[12]+1700485571&4294967295,g=_+(y<<6&4294967295|y>>>26),y=T+(_^(g|~w))+E[3]+2399980690&4294967295,T=g+(y<<10&4294967295|y>>>22),y=w+(g^(T|~_))+E[10]+4293915773&4294967295,w=T+(y<<15&4294967295|y>>>17),y=_+(T^(w|~g))+E[1]+2240044497&4294967295,_=w+(y<<21&4294967295|y>>>11),y=g+(w^(_|~T))+E[8]+1873313359&4294967295,g=_+(y<<6&4294967295|y>>>26),y=T+(_^(g|~w))+E[15]+4264355552&4294967295,T=g+(y<<10&4294967295|y>>>22),y=w+(g^(T|~_))+E[6]+2734768916&4294967295,w=T+(y<<15&4294967295|y>>>17),y=_+(T^(w|~g))+E[13]+1309151649&4294967295,_=w+(y<<21&4294967295|y>>>11),y=g+(w^(_|~T))+E[4]+4149444226&4294967295,g=_+(y<<6&4294967295|y>>>26),y=T+(_^(g|~w))+E[11]+3174756917&4294967295,T=g+(y<<10&4294967295|y>>>22),y=w+(g^(T|~_))+E[2]+718787259&4294967295,w=T+(y<<15&4294967295|y>>>17),y=_+(T^(w|~g))+E[9]+3951481745&4294967295,v.g[0]=v.g[0]+g&4294967295,v.g[1]=v.g[1]+(w+(y<<21&4294967295|y>>>11))&4294967295,v.g[2]=v.g[2]+w&4294967295,v.g[3]=v.g[3]+T&4294967295}r.prototype.u=function(v,g){g===void 0&&(g=v.length);for(var _=g-this.blockSize,E=this.B,w=this.h,T=0;T<g;){if(w==0)for(;T<=_;)s(this,v,T),T+=this.blockSize;if(typeof v=="string"){for(;T<g;)if(E[w++]=v.charCodeAt(T++),w==this.blockSize){s(this,E),w=0;break}}else for(;T<g;)if(E[w++]=v[T++],w==this.blockSize){s(this,E),w=0;break}}this.h=w,this.o+=g},r.prototype.v=function(){var v=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);v[0]=128;for(var g=1;g<v.length-8;++g)v[g]=0;var _=8*this.o;for(g=v.length-8;g<v.length;++g)v[g]=_&255,_/=256;for(this.u(v),v=Array(16),g=_=0;4>g;++g)for(var E=0;32>E;E+=8)v[_++]=this.g[g]>>>E&255;return v};function i(v,g){var _=c;return Object.prototype.hasOwnProperty.call(_,v)?_[v]:_[v]=g(v)}function o(v,g){this.h=g;for(var _=[],E=!0,w=v.length-1;0<=w;w--){var T=v[w]|0;E&&T==g||(_[w]=T,E=!1)}this.g=_}var c={};function l(v){return-128<=v&&128>v?i(v,function(g){return new o([g|0],0>g?-1:0)}):new o([v|0],0>v?-1:0)}function h(v){if(isNaN(v)||!isFinite(v))return m;if(0>v)return P(h(-v));for(var g=[],_=1,E=0;v>=_;E++)g[E]=v/_|0,_*=4294967296;return new o(g,0)}function f(v,g){if(v.length==0)throw Error("number format error: empty string");if(g=g||10,2>g||36<g)throw Error("radix out of range: "+g);if(v.charAt(0)=="-")return P(f(v.substring(1),g));if(0<=v.indexOf("-"))throw Error('number format error: interior "-" character');for(var _=h(Math.pow(g,8)),E=m,w=0;w<v.length;w+=8){var T=Math.min(8,v.length-w),y=parseInt(v.substring(w,w+T),g);8>T?(T=h(Math.pow(g,T)),E=E.j(T).add(h(y))):(E=E.j(_),E=E.add(h(y)))}return E}var m=l(0),I=l(1),S=l(16777216);n=o.prototype,n.m=function(){if(N(this))return-P(this).m();for(var v=0,g=1,_=0;_<this.g.length;_++){var E=this.i(_);v+=(0<=E?E:4294967296+E)*g,g*=4294967296}return v},n.toString=function(v){if(v=v||10,2>v||36<v)throw Error("radix out of range: "+v);if(D(this))return"0";if(N(this))return"-"+P(this).toString(v);for(var g=h(Math.pow(v,6)),_=this,E="";;){var w=X(_,g).g;_=H(_,w.j(g));var T=((0<_.g.length?_.g[0]:_.h)>>>0).toString(v);if(_=w,D(_))return T+E;for(;6>T.length;)T="0"+T;E=T+E}},n.i=function(v){return 0>v?0:v<this.g.length?this.g[v]:this.h};function D(v){if(v.h!=0)return!1;for(var g=0;g<v.g.length;g++)if(v.g[g]!=0)return!1;return!0}function N(v){return v.h==-1}n.l=function(v){return v=H(this,v),N(v)?-1:D(v)?0:1};function P(v){for(var g=v.g.length,_=[],E=0;E<g;E++)_[E]=~v.g[E];return new o(_,~v.h).add(I)}n.abs=function(){return N(this)?P(this):this},n.add=function(v){for(var g=Math.max(this.g.length,v.g.length),_=[],E=0,w=0;w<=g;w++){var T=E+(this.i(w)&65535)+(v.i(w)&65535),y=(T>>>16)+(this.i(w)>>>16)+(v.i(w)>>>16);E=y>>>16,T&=65535,y&=65535,_[w]=y<<16|T}return new o(_,_[_.length-1]&-2147483648?-1:0)};function H(v,g){return v.add(P(g))}n.j=function(v){if(D(this)||D(v))return m;if(N(this))return N(v)?P(this).j(P(v)):P(P(this).j(v));if(N(v))return P(this.j(P(v)));if(0>this.l(S)&&0>v.l(S))return h(this.m()*v.m());for(var g=this.g.length+v.g.length,_=[],E=0;E<2*g;E++)_[E]=0;for(E=0;E<this.g.length;E++)for(var w=0;w<v.g.length;w++){var T=this.i(E)>>>16,y=this.i(E)&65535,ze=v.i(w)>>>16,lt=v.i(w)&65535;_[2*E+2*w]+=y*lt,K(_,2*E+2*w),_[2*E+2*w+1]+=T*lt,K(_,2*E+2*w+1),_[2*E+2*w+1]+=y*ze,K(_,2*E+2*w+1),_[2*E+2*w+2]+=T*ze,K(_,2*E+2*w+2)}for(E=0;E<g;E++)_[E]=_[2*E+1]<<16|_[2*E];for(E=g;E<2*g;E++)_[E]=0;return new o(_,0)};function K(v,g){for(;(v[g]&65535)!=v[g];)v[g+1]+=v[g]>>>16,v[g]&=65535,g++}function q(v,g){this.g=v,this.h=g}function X(v,g){if(D(g))throw Error("division by zero");if(D(v))return new q(m,m);if(N(v))return g=X(P(v),g),new q(P(g.g),P(g.h));if(N(g))return g=X(v,P(g)),new q(P(g.g),g.h);if(30<v.g.length){if(N(v)||N(g))throw Error("slowDivide_ only works with positive integers.");for(var _=I,E=g;0>=E.l(v);)_=V(_),E=V(E);var w=M(_,1),T=M(E,1);for(E=M(E,2),_=M(_,2);!D(E);){var y=T.add(E);0>=y.l(v)&&(w=w.add(_),T=y),E=M(E,1),_=M(_,1)}return g=H(v,w.j(g)),new q(w,g)}for(w=m;0<=v.l(g);){for(_=Math.max(1,Math.floor(v.m()/g.m())),E=Math.ceil(Math.log(_)/Math.LN2),E=48>=E?1:Math.pow(2,E-48),T=h(_),y=T.j(g);N(y)||0<y.l(v);)_-=E,T=h(_),y=T.j(g);D(T)&&(T=I),w=w.add(T),v=H(v,y)}return new q(w,v)}n.A=function(v){return X(this,v).h},n.and=function(v){for(var g=Math.max(this.g.length,v.g.length),_=[],E=0;E<g;E++)_[E]=this.i(E)&v.i(E);return new o(_,this.h&v.h)},n.or=function(v){for(var g=Math.max(this.g.length,v.g.length),_=[],E=0;E<g;E++)_[E]=this.i(E)|v.i(E);return new o(_,this.h|v.h)},n.xor=function(v){for(var g=Math.max(this.g.length,v.g.length),_=[],E=0;E<g;E++)_[E]=this.i(E)^v.i(E);return new o(_,this.h^v.h)};function V(v){for(var g=v.g.length+1,_=[],E=0;E<g;E++)_[E]=v.i(E)<<1|v.i(E-1)>>>31;return new o(_,v.h)}function M(v,g){var _=g>>5;g%=32;for(var E=v.g.length-_,w=[],T=0;T<E;T++)w[T]=0<g?v.i(T+_)>>>g|v.i(T+_+1)<<32-g:v.i(T+_);return new o(w,v.h)}r.prototype.digest=r.prototype.v,r.prototype.reset=r.prototype.s,r.prototype.update=r.prototype.u,ef=r,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.A,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=h,o.fromString=f,An=o}).apply(typeof Uu<"u"?Uu:typeof self<"u"?self:typeof window<"u"?window:{});var hi=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var tf,nf,os,rf,Ti,Oa,sf,of,af;(function(){var n,e=typeof Object.defineProperties=="function"?Object.defineProperty:function(a,u,d){return a==Array.prototype||a==Object.prototype||(a[u]=d.value),a};function t(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof hi=="object"&&hi];for(var u=0;u<a.length;++u){var d=a[u];if(d&&d.Math==Math)return d}throw Error("Cannot find global object")}var r=t(this);function s(a,u){if(u)e:{var d=r;a=a.split(".");for(var p=0;p<a.length-1;p++){var b=a[p];if(!(b in d))break e;d=d[b]}a=a[a.length-1],p=d[a],u=u(p),u!=p&&u!=null&&e(d,a,{configurable:!0,writable:!0,value:u})}}function i(a,u){a instanceof String&&(a+="");var d=0,p=!1,b={next:function(){if(!p&&d<a.length){var R=d++;return{value:u(R,a[R]),done:!1}}return p=!0,{done:!0,value:void 0}}};return b[Symbol.iterator]=function(){return b},b}s("Array.prototype.values",function(a){return a||function(){return i(this,function(u,d){return d})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},c=this||self;function l(a){var u=typeof a;return u=u!="object"?u:a?Array.isArray(a)?"array":u:"null",u=="array"||u=="object"&&typeof a.length=="number"}function h(a){var u=typeof a;return u=="object"&&a!=null||u=="function"}function f(a,u,d){return a.call.apply(a.bind,arguments)}function m(a,u,d){if(!a)throw Error();if(2<arguments.length){var p=Array.prototype.slice.call(arguments,2);return function(){var b=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(b,p),a.apply(u,b)}}return function(){return a.apply(u,arguments)}}function I(a,u,d){return I=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?f:m,I.apply(null,arguments)}function S(a,u){var d=Array.prototype.slice.call(arguments,1);return function(){var p=d.slice();return p.push.apply(p,arguments),a.apply(this,p)}}function D(a,u){function d(){}d.prototype=u.prototype,a.aa=u.prototype,a.prototype=new d,a.prototype.constructor=a,a.Qb=function(p,b,R){for(var O=Array(arguments.length-2),ue=2;ue<arguments.length;ue++)O[ue-2]=arguments[ue];return u.prototype[b].apply(p,O)}}function N(a){const u=a.length;if(0<u){const d=Array(u);for(let p=0;p<u;p++)d[p]=a[p];return d}return[]}function P(a,u){for(let d=1;d<arguments.length;d++){const p=arguments[d];if(l(p)){const b=a.length||0,R=p.length||0;a.length=b+R;for(let O=0;O<R;O++)a[b+O]=p[O]}else a.push(p)}}class H{constructor(u,d){this.i=u,this.j=d,this.h=0,this.g=null}get(){let u;return 0<this.h?(this.h--,u=this.g,this.g=u.next,u.next=null):u=this.i(),u}}function K(a){return/^[\s\xa0]*$/.test(a)}function q(){var a=c.navigator;return a&&(a=a.userAgent)?a:""}function X(a){return X[" "](a),a}X[" "]=function(){};var V=q().indexOf("Gecko")!=-1&&!(q().toLowerCase().indexOf("webkit")!=-1&&q().indexOf("Edge")==-1)&&!(q().indexOf("Trident")!=-1||q().indexOf("MSIE")!=-1)&&q().indexOf("Edge")==-1;function M(a,u,d){for(const p in a)u.call(d,a[p],p,a)}function v(a,u){for(const d in a)u.call(void 0,a[d],d,a)}function g(a){const u={};for(const d in a)u[d]=a[d];return u}const _="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function E(a,u){let d,p;for(let b=1;b<arguments.length;b++){p=arguments[b];for(d in p)a[d]=p[d];for(let R=0;R<_.length;R++)d=_[R],Object.prototype.hasOwnProperty.call(p,d)&&(a[d]=p[d])}}function w(a){var u=1;a=a.split(":");const d=[];for(;0<u&&a.length;)d.push(a.shift()),u--;return a.length&&d.push(a.join(":")),d}function T(a){c.setTimeout(()=>{throw a},0)}function y(){var a=Uo;let u=null;return a.g&&(u=a.g,a.g=a.g.next,a.g||(a.h=null),u.next=null),u}class ze{constructor(){this.h=this.g=null}add(u,d){const p=lt.get();p.set(u,d),this.h?this.h.next=p:this.g=p,this.h=p}}var lt=new H(()=>new Lm,a=>a.reset());class Lm{constructor(){this.next=this.g=this.h=null}set(u,d){this.h=u,this.g=d,this.next=null}reset(){this.next=this.g=this.h=null}}let Mr,Lr=!1,Uo=new ze,ul=()=>{const a=c.Promise.resolve(void 0);Mr=()=>{a.then(Fm)}};var Fm=()=>{for(var a;a=y();){try{a.h.call(a.g)}catch(d){T(d)}var u=lt;u.j(a),100>u.h&&(u.h++,a.next=u.g,u.g=a)}Lr=!1};function Vt(){this.s=this.s,this.C=this.C}Vt.prototype.s=!1,Vt.prototype.ma=function(){this.s||(this.s=!0,this.N())},Vt.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function Ve(a,u){this.type=a,this.g=this.target=u,this.defaultPrevented=!1}Ve.prototype.h=function(){this.defaultPrevented=!0};var $m=function(){if(!c.addEventListener||!Object.defineProperty)return!1;var a=!1,u=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const d=()=>{};c.addEventListener("test",d,u),c.removeEventListener("test",d,u)}catch{}return a}();function Fr(a,u){if(Ve.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a){var d=this.type=a.type,p=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;if(this.target=a.target||a.srcElement,this.g=u,u=a.relatedTarget){if(V){e:{try{X(u.nodeName);var b=!0;break e}catch{}b=!1}b||(u=null)}}else d=="mouseover"?u=a.fromElement:d=="mouseout"&&(u=a.toElement);this.relatedTarget=u,p?(this.clientX=p.clientX!==void 0?p.clientX:p.pageX,this.clientY=p.clientY!==void 0?p.clientY:p.pageY,this.screenX=p.screenX||0,this.screenY=p.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=typeof a.pointerType=="string"?a.pointerType:Um[a.pointerType]||"",this.state=a.state,this.i=a,a.defaultPrevented&&Fr.aa.h.call(this)}}D(Fr,Ve);var Um={2:"touch",3:"pen",4:"mouse"};Fr.prototype.h=function(){Fr.aa.h.call(this);var a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var Ks="closure_listenable_"+(1e6*Math.random()|0),Bm=0;function qm(a,u,d,p,b){this.listener=a,this.proxy=null,this.src=u,this.type=d,this.capture=!!p,this.ha=b,this.key=++Bm,this.da=this.fa=!1}function Ws(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function Hs(a){this.src=a,this.g={},this.h=0}Hs.prototype.add=function(a,u,d,p,b){var R=a.toString();a=this.g[R],a||(a=this.g[R]=[],this.h++);var O=qo(a,u,p,b);return-1<O?(u=a[O],d||(u.fa=!1)):(u=new qm(u,this.src,R,!!p,b),u.fa=d,a.push(u)),u};function Bo(a,u){var d=u.type;if(d in a.g){var p=a.g[d],b=Array.prototype.indexOf.call(p,u,void 0),R;(R=0<=b)&&Array.prototype.splice.call(p,b,1),R&&(Ws(u),a.g[d].length==0&&(delete a.g[d],a.h--))}}function qo(a,u,d,p){for(var b=0;b<a.length;++b){var R=a[b];if(!R.da&&R.listener==u&&R.capture==!!d&&R.ha==p)return b}return-1}var jo="closure_lm_"+(1e6*Math.random()|0),Go={};function hl(a,u,d,p,b){if(Array.isArray(u)){for(var R=0;R<u.length;R++)hl(a,u[R],d,p,b);return null}return d=pl(d),a&&a[Ks]?a.K(u,d,h(p)?!!p.capture:!1,b):jm(a,u,d,!1,p,b)}function jm(a,u,d,p,b,R){if(!u)throw Error("Invalid event type");var O=h(b)?!!b.capture:!!b,ue=Ko(a);if(ue||(a[jo]=ue=new Hs(a)),d=ue.add(u,d,p,O,R),d.proxy)return d;if(p=Gm(),d.proxy=p,p.src=a,p.listener=d,a.addEventListener)$m||(b=O),b===void 0&&(b=!1),a.addEventListener(u.toString(),p,b);else if(a.attachEvent)a.attachEvent(fl(u.toString()),p);else if(a.addListener&&a.removeListener)a.addListener(p);else throw Error("addEventListener and attachEvent are unavailable.");return d}function Gm(){function a(d){return u.call(a.src,a.listener,d)}const u=zm;return a}function dl(a,u,d,p,b){if(Array.isArray(u))for(var R=0;R<u.length;R++)dl(a,u[R],d,p,b);else p=h(p)?!!p.capture:!!p,d=pl(d),a&&a[Ks]?(a=a.i,u=String(u).toString(),u in a.g&&(R=a.g[u],d=qo(R,d,p,b),-1<d&&(Ws(R[d]),Array.prototype.splice.call(R,d,1),R.length==0&&(delete a.g[u],a.h--)))):a&&(a=Ko(a))&&(u=a.g[u.toString()],a=-1,u&&(a=qo(u,d,p,b)),(d=-1<a?u[a]:null)&&zo(d))}function zo(a){if(typeof a!="number"&&a&&!a.da){var u=a.src;if(u&&u[Ks])Bo(u.i,a);else{var d=a.type,p=a.proxy;u.removeEventListener?u.removeEventListener(d,p,a.capture):u.detachEvent?u.detachEvent(fl(d),p):u.addListener&&u.removeListener&&u.removeListener(p),(d=Ko(u))?(Bo(d,a),d.h==0&&(d.src=null,u[jo]=null)):Ws(a)}}}function fl(a){return a in Go?Go[a]:Go[a]="on"+a}function zm(a,u){if(a.da)a=!0;else{u=new Fr(u,this);var d=a.listener,p=a.ha||a.src;a.fa&&zo(a),a=d.call(p,u)}return a}function Ko(a){return a=a[jo],a instanceof Hs?a:null}var Wo="__closure_events_fn_"+(1e9*Math.random()>>>0);function pl(a){return typeof a=="function"?a:(a[Wo]||(a[Wo]=function(u){return a.handleEvent(u)}),a[Wo])}function Ne(){Vt.call(this),this.i=new Hs(this),this.M=this,this.F=null}D(Ne,Vt),Ne.prototype[Ks]=!0,Ne.prototype.removeEventListener=function(a,u,d,p){dl(this,a,u,d,p)};function Ue(a,u){var d,p=a.F;if(p)for(d=[];p;p=p.F)d.push(p);if(a=a.M,p=u.type||u,typeof u=="string")u=new Ve(u,a);else if(u instanceof Ve)u.target=u.target||a;else{var b=u;u=new Ve(p,a),E(u,b)}if(b=!0,d)for(var R=d.length-1;0<=R;R--){var O=u.g=d[R];b=Qs(O,p,!0,u)&&b}if(O=u.g=a,b=Qs(O,p,!0,u)&&b,b=Qs(O,p,!1,u)&&b,d)for(R=0;R<d.length;R++)O=u.g=d[R],b=Qs(O,p,!1,u)&&b}Ne.prototype.N=function(){if(Ne.aa.N.call(this),this.i){var a=this.i,u;for(u in a.g){for(var d=a.g[u],p=0;p<d.length;p++)Ws(d[p]);delete a.g[u],a.h--}}this.F=null},Ne.prototype.K=function(a,u,d,p){return this.i.add(String(a),u,!1,d,p)},Ne.prototype.L=function(a,u,d,p){return this.i.add(String(a),u,!0,d,p)};function Qs(a,u,d,p){if(u=a.i.g[String(u)],!u)return!0;u=u.concat();for(var b=!0,R=0;R<u.length;++R){var O=u[R];if(O&&!O.da&&O.capture==d){var ue=O.listener,ke=O.ha||O.src;O.fa&&Bo(a.i,O),b=ue.call(ke,p)!==!1&&b}}return b&&!p.defaultPrevented}function ml(a,u,d){if(typeof a=="function")d&&(a=I(a,d));else if(a&&typeof a.handleEvent=="function")a=I(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<Number(u)?-1:c.setTimeout(a,u||0)}function gl(a){a.g=ml(()=>{a.g=null,a.i&&(a.i=!1,gl(a))},a.l);const u=a.h;a.h=null,a.m.apply(null,u)}class Km extends Vt{constructor(u,d){super(),this.m=u,this.l=d,this.h=null,this.i=!1,this.g=null}j(u){this.h=arguments,this.g?this.i=!0:gl(this)}N(){super.N(),this.g&&(c.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function $r(a){Vt.call(this),this.h=a,this.g={}}D($r,Vt);var _l=[];function yl(a){M(a.g,function(u,d){this.g.hasOwnProperty(d)&&zo(u)},a),a.g={}}$r.prototype.N=function(){$r.aa.N.call(this),yl(this)},$r.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Ho=c.JSON.stringify,Wm=c.JSON.parse,Hm=class{stringify(a){return c.JSON.stringify(a,void 0)}parse(a){return c.JSON.parse(a,void 0)}};function Qo(){}Qo.prototype.h=null;function vl(a){return a.h||(a.h=a.i())}function Il(){}var Ur={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function Jo(){Ve.call(this,"d")}D(Jo,Ve);function Yo(){Ve.call(this,"c")}D(Yo,Ve);var dn={},El=null;function Js(){return El=El||new Ne}dn.La="serverreachability";function wl(a){Ve.call(this,dn.La,a)}D(wl,Ve);function Br(a){const u=Js();Ue(u,new wl(u))}dn.STAT_EVENT="statevent";function Tl(a,u){Ve.call(this,dn.STAT_EVENT,a),this.stat=u}D(Tl,Ve);function Be(a){const u=Js();Ue(u,new Tl(u,a))}dn.Ma="timingevent";function bl(a,u){Ve.call(this,dn.Ma,a),this.size=u}D(bl,Ve);function qr(a,u){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return c.setTimeout(function(){a()},u)}function jr(){this.g=!0}jr.prototype.xa=function(){this.g=!1};function Qm(a,u,d,p,b,R){a.info(function(){if(a.g)if(R)for(var O="",ue=R.split("&"),ke=0;ke<ue.length;ke++){var oe=ue[ke].split("=");if(1<oe.length){var xe=oe[0];oe=oe[1];var Oe=xe.split("_");O=2<=Oe.length&&Oe[1]=="type"?O+(xe+"="+oe+"&"):O+(xe+"=redacted&")}}else O=null;else O=R;return"XMLHTTP REQ ("+p+") [attempt "+b+"]: "+u+`
`+d+`
`+O})}function Jm(a,u,d,p,b,R,O){a.info(function(){return"XMLHTTP RESP ("+p+") [ attempt "+b+"]: "+u+`
`+d+`
`+R+" "+O})}function Gn(a,u,d,p){a.info(function(){return"XMLHTTP TEXT ("+u+"): "+Xm(a,d)+(p?" "+p:"")})}function Ym(a,u){a.info(function(){return"TIMEOUT: "+u})}jr.prototype.info=function(){};function Xm(a,u){if(!a.g)return u;if(!u)return null;try{var d=JSON.parse(u);if(d){for(a=0;a<d.length;a++)if(Array.isArray(d[a])){var p=d[a];if(!(2>p.length)){var b=p[1];if(Array.isArray(b)&&!(1>b.length)){var R=b[0];if(R!="noop"&&R!="stop"&&R!="close")for(var O=1;O<b.length;O++)b[O]=""}}}}return Ho(d)}catch{return u}}var Ys={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},Al={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},Xo;function Xs(){}D(Xs,Qo),Xs.prototype.g=function(){return new XMLHttpRequest},Xs.prototype.i=function(){return{}},Xo=new Xs;function Nt(a,u,d,p){this.j=a,this.i=u,this.l=d,this.R=p||1,this.U=new $r(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new Sl}function Sl(){this.i=null,this.g="",this.h=!1}var Rl={},Zo={};function ea(a,u,d){a.L=1,a.v=ni(Et(u)),a.m=d,a.P=!0,Pl(a,null)}function Pl(a,u){a.F=Date.now(),Zs(a),a.A=Et(a.v);var d=a.A,p=a.R;Array.isArray(p)||(p=[String(p)]),ql(d.i,"t",p),a.C=0,d=a.j.J,a.h=new Sl,a.g=ou(a.j,d?u:null,!a.m),0<a.O&&(a.M=new Km(I(a.Y,a,a.g),a.O)),u=a.U,d=a.g,p=a.ca;var b="readystatechange";Array.isArray(b)||(b&&(_l[0]=b.toString()),b=_l);for(var R=0;R<b.length;R++){var O=hl(d,b[R],p||u.handleEvent,!1,u.h||u);if(!O)break;u.g[O.key]=O}u=a.H?g(a.H):{},a.m?(a.u||(a.u="POST"),u["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.A,a.u,a.m,u)):(a.u="GET",a.g.ea(a.A,a.u,null,u)),Br(),Qm(a.i,a.u,a.A,a.l,a.R,a.m)}Nt.prototype.ca=function(a){a=a.target;const u=this.M;u&&wt(a)==3?u.j():this.Y(a)},Nt.prototype.Y=function(a){try{if(a==this.g)e:{const Oe=wt(this.g);var u=this.g.Ba();const Wn=this.g.Z();if(!(3>Oe)&&(Oe!=3||this.g&&(this.h.h||this.g.oa()||Ql(this.g)))){this.J||Oe!=4||u==7||(u==8||0>=Wn?Br(3):Br(2)),ta(this);var d=this.g.Z();this.X=d;t:if(Cl(this)){var p=Ql(this.g);a="";var b=p.length,R=wt(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){fn(this),Gr(this);var O="";break t}this.h.i=new c.TextDecoder}for(u=0;u<b;u++)this.h.h=!0,a+=this.h.i.decode(p[u],{stream:!(R&&u==b-1)});p.length=0,this.h.g+=a,this.C=0,O=this.h.g}else O=this.g.oa();if(this.o=d==200,Jm(this.i,this.u,this.A,this.l,this.R,Oe,d),this.o){if(this.T&&!this.K){t:{if(this.g){var ue,ke=this.g;if((ue=ke.g?ke.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!K(ue)){var oe=ue;break t}}oe=null}if(d=oe)Gn(this.i,this.l,d,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,na(this,d);else{this.o=!1,this.s=3,Be(12),fn(this),Gr(this);break e}}if(this.P){d=!0;let ot;for(;!this.J&&this.C<O.length;)if(ot=Zm(this,O),ot==Zo){Oe==4&&(this.s=4,Be(14),d=!1),Gn(this.i,this.l,null,"[Incomplete Response]");break}else if(ot==Rl){this.s=4,Be(15),Gn(this.i,this.l,O,"[Invalid Chunk]"),d=!1;break}else Gn(this.i,this.l,ot,null),na(this,ot);if(Cl(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),Oe!=4||O.length!=0||this.h.h||(this.s=1,Be(16),d=!1),this.o=this.o&&d,!d)Gn(this.i,this.l,O,"[Invalid Chunked Response]"),fn(this),Gr(this);else if(0<O.length&&!this.W){this.W=!0;var xe=this.j;xe.g==this&&xe.ba&&!xe.M&&(xe.j.info("Great, no buffering proxy detected. Bytes received: "+O.length),ca(xe),xe.M=!0,Be(11))}}else Gn(this.i,this.l,O,null),na(this,O);Oe==4&&fn(this),this.o&&!this.J&&(Oe==4?nu(this.j,this):(this.o=!1,Zs(this)))}else gg(this.g),d==400&&0<O.indexOf("Unknown SID")?(this.s=3,Be(12)):(this.s=0,Be(13)),fn(this),Gr(this)}}}catch{}finally{}};function Cl(a){return a.g?a.u=="GET"&&a.L!=2&&a.j.Ca:!1}function Zm(a,u){var d=a.C,p=u.indexOf(`
`,d);return p==-1?Zo:(d=Number(u.substring(d,p)),isNaN(d)?Rl:(p+=1,p+d>u.length?Zo:(u=u.slice(p,p+d),a.C=p+d,u)))}Nt.prototype.cancel=function(){this.J=!0,fn(this)};function Zs(a){a.S=Date.now()+a.I,kl(a,a.I)}function kl(a,u){if(a.B!=null)throw Error("WatchDog timer not null");a.B=qr(I(a.ba,a),u)}function ta(a){a.B&&(c.clearTimeout(a.B),a.B=null)}Nt.prototype.ba=function(){this.B=null;const a=Date.now();0<=a-this.S?(Ym(this.i,this.A),this.L!=2&&(Br(),Be(17)),fn(this),this.s=2,Gr(this)):kl(this,this.S-a)};function Gr(a){a.j.G==0||a.J||nu(a.j,a)}function fn(a){ta(a);var u=a.M;u&&typeof u.ma=="function"&&u.ma(),a.M=null,yl(a.U),a.g&&(u=a.g,a.g=null,u.abort(),u.ma())}function na(a,u){try{var d=a.j;if(d.G!=0&&(d.g==a||ra(d.h,a))){if(!a.K&&ra(d.h,a)&&d.G==3){try{var p=d.Da.g.parse(u)}catch{p=null}if(Array.isArray(p)&&p.length==3){var b=p;if(b[0]==0){e:if(!d.u){if(d.g)if(d.g.F+3e3<a.F)ai(d),ii(d);else break e;aa(d),Be(18)}}else d.za=b[1],0<d.za-d.T&&37500>b[2]&&d.F&&d.v==0&&!d.C&&(d.C=qr(I(d.Za,d),6e3));if(1>=Nl(d.h)&&d.ca){try{d.ca()}catch{}d.ca=void 0}}else mn(d,11)}else if((a.K||d.g==a)&&ai(d),!K(u))for(b=d.Da.g.parse(u),u=0;u<b.length;u++){let oe=b[u];if(d.T=oe[0],oe=oe[1],d.G==2)if(oe[0]=="c"){d.K=oe[1],d.ia=oe[2];const xe=oe[3];xe!=null&&(d.la=xe,d.j.info("VER="+d.la));const Oe=oe[4];Oe!=null&&(d.Aa=Oe,d.j.info("SVER="+d.Aa));const Wn=oe[5];Wn!=null&&typeof Wn=="number"&&0<Wn&&(p=1.5*Wn,d.L=p,d.j.info("backChannelRequestTimeoutMs_="+p)),p=d;const ot=a.g;if(ot){const li=ot.g?ot.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(li){var R=p.h;R.g||li.indexOf("spdy")==-1&&li.indexOf("quic")==-1&&li.indexOf("h2")==-1||(R.j=R.l,R.g=new Set,R.h&&(sa(R,R.h),R.h=null))}if(p.D){const la=ot.g?ot.g.getResponseHeader("X-HTTP-Session-Id"):null;la&&(p.ya=la,de(p.I,p.D,la))}}d.G=3,d.l&&d.l.ua(),d.ba&&(d.R=Date.now()-a.F,d.j.info("Handshake RTT: "+d.R+"ms")),p=d;var O=a;if(p.qa=iu(p,p.J?p.ia:null,p.W),O.K){xl(p.h,O);var ue=O,ke=p.L;ke&&(ue.I=ke),ue.B&&(ta(ue),Zs(ue)),p.g=O}else eu(p);0<d.i.length&&oi(d)}else oe[0]!="stop"&&oe[0]!="close"||mn(d,7);else d.G==3&&(oe[0]=="stop"||oe[0]=="close"?oe[0]=="stop"?mn(d,7):oa(d):oe[0]!="noop"&&d.l&&d.l.ta(oe),d.v=0)}}Br(4)}catch{}}var eg=class{constructor(a,u){this.g=a,this.map=u}};function Dl(a){this.l=a||10,c.PerformanceNavigationTiming?(a=c.performance.getEntriesByType("navigation"),a=0<a.length&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(c.chrome&&c.chrome.loadTimes&&c.chrome.loadTimes()&&c.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function Vl(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function Nl(a){return a.h?1:a.g?a.g.size:0}function ra(a,u){return a.h?a.h==u:a.g?a.g.has(u):!1}function sa(a,u){a.g?a.g.add(u):a.h=u}function xl(a,u){a.h&&a.h==u?a.h=null:a.g&&a.g.has(u)&&a.g.delete(u)}Dl.prototype.cancel=function(){if(this.i=Ol(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function Ol(a){if(a.h!=null)return a.i.concat(a.h.D);if(a.g!=null&&a.g.size!==0){let u=a.i;for(const d of a.g.values())u=u.concat(d.D);return u}return N(a.i)}function tg(a){if(a.V&&typeof a.V=="function")return a.V();if(typeof Map<"u"&&a instanceof Map||typeof Set<"u"&&a instanceof Set)return Array.from(a.values());if(typeof a=="string")return a.split("");if(l(a)){for(var u=[],d=a.length,p=0;p<d;p++)u.push(a[p]);return u}u=[],d=0;for(p in a)u[d++]=a[p];return u}function ng(a){if(a.na&&typeof a.na=="function")return a.na();if(!a.V||typeof a.V!="function"){if(typeof Map<"u"&&a instanceof Map)return Array.from(a.keys());if(!(typeof Set<"u"&&a instanceof Set)){if(l(a)||typeof a=="string"){var u=[];a=a.length;for(var d=0;d<a;d++)u.push(d);return u}u=[],d=0;for(const p in a)u[d++]=p;return u}}}function Ml(a,u){if(a.forEach&&typeof a.forEach=="function")a.forEach(u,void 0);else if(l(a)||typeof a=="string")Array.prototype.forEach.call(a,u,void 0);else for(var d=ng(a),p=tg(a),b=p.length,R=0;R<b;R++)u.call(void 0,p[R],d&&d[R],a)}var Ll=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function rg(a,u){if(a){a=a.split("&");for(var d=0;d<a.length;d++){var p=a[d].indexOf("="),b=null;if(0<=p){var R=a[d].substring(0,p);b=a[d].substring(p+1)}else R=a[d];u(R,b?decodeURIComponent(b.replace(/\+/g," ")):"")}}}function pn(a){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,a instanceof pn){this.h=a.h,ei(this,a.j),this.o=a.o,this.g=a.g,ti(this,a.s),this.l=a.l;var u=a.i,d=new Wr;d.i=u.i,u.g&&(d.g=new Map(u.g),d.h=u.h),Fl(this,d),this.m=a.m}else a&&(u=String(a).match(Ll))?(this.h=!1,ei(this,u[1]||"",!0),this.o=zr(u[2]||""),this.g=zr(u[3]||"",!0),ti(this,u[4]),this.l=zr(u[5]||"",!0),Fl(this,u[6]||"",!0),this.m=zr(u[7]||"")):(this.h=!1,this.i=new Wr(null,this.h))}pn.prototype.toString=function(){var a=[],u=this.j;u&&a.push(Kr(u,$l,!0),":");var d=this.g;return(d||u=="file")&&(a.push("//"),(u=this.o)&&a.push(Kr(u,$l,!0),"@"),a.push(encodeURIComponent(String(d)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),d=this.s,d!=null&&a.push(":",String(d))),(d=this.l)&&(this.g&&d.charAt(0)!="/"&&a.push("/"),a.push(Kr(d,d.charAt(0)=="/"?og:ig,!0))),(d=this.i.toString())&&a.push("?",d),(d=this.m)&&a.push("#",Kr(d,cg)),a.join("")};function Et(a){return new pn(a)}function ei(a,u,d){a.j=d?zr(u,!0):u,a.j&&(a.j=a.j.replace(/:$/,""))}function ti(a,u){if(u){if(u=Number(u),isNaN(u)||0>u)throw Error("Bad port number "+u);a.s=u}else a.s=null}function Fl(a,u,d){u instanceof Wr?(a.i=u,lg(a.i,a.h)):(d||(u=Kr(u,ag)),a.i=new Wr(u,a.h))}function de(a,u,d){a.i.set(u,d)}function ni(a){return de(a,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),a}function zr(a,u){return a?u?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function Kr(a,u,d){return typeof a=="string"?(a=encodeURI(a).replace(u,sg),d&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function sg(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var $l=/[#\/\?@]/g,ig=/[#\?:]/g,og=/[#\?]/g,ag=/[#\?@]/g,cg=/#/g;function Wr(a,u){this.h=this.g=null,this.i=a||null,this.j=!!u}function xt(a){a.g||(a.g=new Map,a.h=0,a.i&&rg(a.i,function(u,d){a.add(decodeURIComponent(u.replace(/\+/g," ")),d)}))}n=Wr.prototype,n.add=function(a,u){xt(this),this.i=null,a=zn(this,a);var d=this.g.get(a);return d||this.g.set(a,d=[]),d.push(u),this.h+=1,this};function Ul(a,u){xt(a),u=zn(a,u),a.g.has(u)&&(a.i=null,a.h-=a.g.get(u).length,a.g.delete(u))}function Bl(a,u){return xt(a),u=zn(a,u),a.g.has(u)}n.forEach=function(a,u){xt(this),this.g.forEach(function(d,p){d.forEach(function(b){a.call(u,b,p,this)},this)},this)},n.na=function(){xt(this);const a=Array.from(this.g.values()),u=Array.from(this.g.keys()),d=[];for(let p=0;p<u.length;p++){const b=a[p];for(let R=0;R<b.length;R++)d.push(u[p])}return d},n.V=function(a){xt(this);let u=[];if(typeof a=="string")Bl(this,a)&&(u=u.concat(this.g.get(zn(this,a))));else{a=Array.from(this.g.values());for(let d=0;d<a.length;d++)u=u.concat(a[d])}return u},n.set=function(a,u){return xt(this),this.i=null,a=zn(this,a),Bl(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[u]),this.h+=1,this},n.get=function(a,u){return a?(a=this.V(a),0<a.length?String(a[0]):u):u};function ql(a,u,d){Ul(a,u),0<d.length&&(a.i=null,a.g.set(zn(a,u),N(d)),a.h+=d.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],u=Array.from(this.g.keys());for(var d=0;d<u.length;d++){var p=u[d];const R=encodeURIComponent(String(p)),O=this.V(p);for(p=0;p<O.length;p++){var b=R;O[p]!==""&&(b+="="+encodeURIComponent(String(O[p]))),a.push(b)}}return this.i=a.join("&")};function zn(a,u){return u=String(u),a.j&&(u=u.toLowerCase()),u}function lg(a,u){u&&!a.j&&(xt(a),a.i=null,a.g.forEach(function(d,p){var b=p.toLowerCase();p!=b&&(Ul(this,p),ql(this,b,d))},a)),a.j=u}function ug(a,u){const d=new jr;if(c.Image){const p=new Image;p.onload=S(Ot,d,"TestLoadImage: loaded",!0,u,p),p.onerror=S(Ot,d,"TestLoadImage: error",!1,u,p),p.onabort=S(Ot,d,"TestLoadImage: abort",!1,u,p),p.ontimeout=S(Ot,d,"TestLoadImage: timeout",!1,u,p),c.setTimeout(function(){p.ontimeout&&p.ontimeout()},1e4),p.src=a}else u(!1)}function hg(a,u){const d=new jr,p=new AbortController,b=setTimeout(()=>{p.abort(),Ot(d,"TestPingServer: timeout",!1,u)},1e4);fetch(a,{signal:p.signal}).then(R=>{clearTimeout(b),R.ok?Ot(d,"TestPingServer: ok",!0,u):Ot(d,"TestPingServer: server error",!1,u)}).catch(()=>{clearTimeout(b),Ot(d,"TestPingServer: error",!1,u)})}function Ot(a,u,d,p,b){try{b&&(b.onload=null,b.onerror=null,b.onabort=null,b.ontimeout=null),p(d)}catch{}}function dg(){this.g=new Hm}function fg(a,u,d){const p=d||"";try{Ml(a,function(b,R){let O=b;h(b)&&(O=Ho(b)),u.push(p+R+"="+encodeURIComponent(O))})}catch(b){throw u.push(p+"type="+encodeURIComponent("_badmap")),b}}function Hr(a){this.l=a.Ub||null,this.j=a.eb||!1}D(Hr,Qo),Hr.prototype.g=function(){return new ri(this.l,this.j)},Hr.prototype.i=function(a){return function(){return a}}({});function ri(a,u){Ne.call(this),this.D=a,this.o=u,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}D(ri,Ne),n=ri.prototype,n.open=function(a,u){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=a,this.A=u,this.readyState=1,Jr(this)},n.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const u={headers:this.u,method:this.B,credentials:this.m,cache:void 0};a&&(u.body=a),(this.D||c).fetch(new Request(this.A,u)).then(this.Sa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,Qr(this)),this.readyState=0},n.Sa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,Jr(this)),this.g&&(this.readyState=3,Jr(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof c.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;jl(this)}else a.text().then(this.Ra.bind(this),this.ga.bind(this))};function jl(a){a.j.read().then(a.Pa.bind(a)).catch(a.ga.bind(a))}n.Pa=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var u=a.value?a.value:new Uint8Array(0);(u=this.v.decode(u,{stream:!a.done}))&&(this.response=this.responseText+=u)}a.done?Qr(this):Jr(this),this.readyState==3&&jl(this)}},n.Ra=function(a){this.g&&(this.response=this.responseText=a,Qr(this))},n.Qa=function(a){this.g&&(this.response=a,Qr(this))},n.ga=function(){this.g&&Qr(this)};function Qr(a){a.readyState=4,a.l=null,a.j=null,a.v=null,Jr(a)}n.setRequestHeader=function(a,u){this.u.append(a,u)},n.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],u=this.h.entries();for(var d=u.next();!d.done;)d=d.value,a.push(d[0]+": "+d[1]),d=u.next();return a.join(`\r
`)};function Jr(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty(ri.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function Gl(a){let u="";return M(a,function(d,p){u+=p,u+=":",u+=d,u+=`\r
`}),u}function ia(a,u,d){e:{for(p in d){var p=!1;break e}p=!0}p||(d=Gl(d),typeof a=="string"?d!=null&&encodeURIComponent(String(d)):de(a,u,d))}function me(a){Ne.call(this),this.headers=new Map,this.o=a||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}D(me,Ne);var pg=/^https?$/i,mg=["POST","PUT"];n=me.prototype,n.Ha=function(a){this.J=a},n.ea=function(a,u,d,p){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);u=u?u.toUpperCase():"GET",this.D=a,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():Xo.g(),this.v=this.o?vl(this.o):vl(Xo),this.g.onreadystatechange=I(this.Ea,this);try{this.B=!0,this.g.open(u,String(a),!0),this.B=!1}catch(R){zl(this,R);return}if(a=d||"",d=new Map(this.headers),p)if(Object.getPrototypeOf(p)===Object.prototype)for(var b in p)d.set(b,p[b]);else if(typeof p.keys=="function"&&typeof p.get=="function")for(const R of p.keys())d.set(R,p.get(R));else throw Error("Unknown input type for opt_headers: "+String(p));p=Array.from(d.keys()).find(R=>R.toLowerCase()=="content-type"),b=c.FormData&&a instanceof c.FormData,!(0<=Array.prototype.indexOf.call(mg,u,void 0))||p||b||d.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[R,O]of d)this.g.setRequestHeader(R,O);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{Hl(this),this.u=!0,this.g.send(a),this.u=!1}catch(R){zl(this,R)}};function zl(a,u){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=u,a.m=5,Kl(a),si(a)}function Kl(a){a.A||(a.A=!0,Ue(a,"complete"),Ue(a,"error"))}n.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=a||7,Ue(this,"complete"),Ue(this,"abort"),si(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),si(this,!0)),me.aa.N.call(this)},n.Ea=function(){this.s||(this.B||this.u||this.j?Wl(this):this.bb())},n.bb=function(){Wl(this)};function Wl(a){if(a.h&&typeof o<"u"&&(!a.v[1]||wt(a)!=4||a.Z()!=2)){if(a.u&&wt(a)==4)ml(a.Ea,0,a);else if(Ue(a,"readystatechange"),wt(a)==4){a.h=!1;try{const O=a.Z();e:switch(O){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var u=!0;break e;default:u=!1}var d;if(!(d=u)){var p;if(p=O===0){var b=String(a.D).match(Ll)[1]||null;!b&&c.self&&c.self.location&&(b=c.self.location.protocol.slice(0,-1)),p=!pg.test(b?b.toLowerCase():"")}d=p}if(d)Ue(a,"complete"),Ue(a,"success");else{a.m=6;try{var R=2<wt(a)?a.g.statusText:""}catch{R=""}a.l=R+" ["+a.Z()+"]",Kl(a)}}finally{si(a)}}}}function si(a,u){if(a.g){Hl(a);const d=a.g,p=a.v[0]?()=>{}:null;a.g=null,a.v=null,u||Ue(a,"ready");try{d.onreadystatechange=p}catch{}}}function Hl(a){a.I&&(c.clearTimeout(a.I),a.I=null)}n.isActive=function(){return!!this.g};function wt(a){return a.g?a.g.readyState:0}n.Z=function(){try{return 2<wt(this)?this.g.status:-1}catch{return-1}},n.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.Oa=function(a){if(this.g){var u=this.g.responseText;return a&&u.indexOf(a)==0&&(u=u.substring(a.length)),Wm(u)}};function Ql(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.H){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function gg(a){const u={};a=(a.g&&2<=wt(a)&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let p=0;p<a.length;p++){if(K(a[p]))continue;var d=w(a[p]);const b=d[0];if(d=d[1],typeof d!="string")continue;d=d.trim();const R=u[b]||[];u[b]=R,R.push(d)}v(u,function(p){return p.join(", ")})}n.Ba=function(){return this.m},n.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function Yr(a,u,d){return d&&d.internalChannelParams&&d.internalChannelParams[a]||u}function Jl(a){this.Aa=0,this.i=[],this.j=new jr,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=Yr("failFast",!1,a),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=Yr("baseRetryDelayMs",5e3,a),this.cb=Yr("retryDelaySeedMs",1e4,a),this.Wa=Yr("forwardChannelMaxRetries",2,a),this.wa=Yr("forwardChannelRequestTimeoutMs",2e4,a),this.pa=a&&a.xmlHttpFactory||void 0,this.Xa=a&&a.Tb||void 0,this.Ca=a&&a.useFetchStreams||!1,this.L=void 0,this.J=a&&a.supportsCrossDomainXhr||!1,this.K="",this.h=new Dl(a&&a.concurrentRequestLimit),this.Da=new dg,this.P=a&&a.fastHandshake||!1,this.O=a&&a.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=a&&a.Rb||!1,a&&a.xa&&this.j.xa(),a&&a.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&a&&a.detectBufferingProxy||!1,this.ja=void 0,a&&a.longPollingTimeout&&0<a.longPollingTimeout&&(this.ja=a.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}n=Jl.prototype,n.la=8,n.G=1,n.connect=function(a,u,d,p){Be(0),this.W=a,this.H=u||{},d&&p!==void 0&&(this.H.OSID=d,this.H.OAID=p),this.F=this.X,this.I=iu(this,null,this.W),oi(this)};function oa(a){if(Yl(a),a.G==3){var u=a.U++,d=Et(a.I);if(de(d,"SID",a.K),de(d,"RID",u),de(d,"TYPE","terminate"),Xr(a,d),u=new Nt(a,a.j,u),u.L=2,u.v=ni(Et(d)),d=!1,c.navigator&&c.navigator.sendBeacon)try{d=c.navigator.sendBeacon(u.v.toString(),"")}catch{}!d&&c.Image&&(new Image().src=u.v,d=!0),d||(u.g=ou(u.j,null),u.g.ea(u.v)),u.F=Date.now(),Zs(u)}su(a)}function ii(a){a.g&&(ca(a),a.g.cancel(),a.g=null)}function Yl(a){ii(a),a.u&&(c.clearTimeout(a.u),a.u=null),ai(a),a.h.cancel(),a.s&&(typeof a.s=="number"&&c.clearTimeout(a.s),a.s=null)}function oi(a){if(!Vl(a.h)&&!a.s){a.s=!0;var u=a.Ga;Mr||ul(),Lr||(Mr(),Lr=!0),Uo.add(u,a),a.B=0}}function _g(a,u){return Nl(a.h)>=a.h.j-(a.s?1:0)?!1:a.s?(a.i=u.D.concat(a.i),!0):a.G==1||a.G==2||a.B>=(a.Va?0:a.Wa)?!1:(a.s=qr(I(a.Ga,a,u),ru(a,a.B)),a.B++,!0)}n.Ga=function(a){if(this.s)if(this.s=null,this.G==1){if(!a){this.U=Math.floor(1e5*Math.random()),a=this.U++;const b=new Nt(this,this.j,a);let R=this.o;if(this.S&&(R?(R=g(R),E(R,this.S)):R=this.S),this.m!==null||this.O||(b.H=R,R=null),this.P)e:{for(var u=0,d=0;d<this.i.length;d++){t:{var p=this.i[d];if("__data__"in p.map&&(p=p.map.__data__,typeof p=="string")){p=p.length;break t}p=void 0}if(p===void 0)break;if(u+=p,4096<u){u=d;break e}if(u===4096||d===this.i.length-1){u=d+1;break e}}u=1e3}else u=1e3;u=Zl(this,b,u),d=Et(this.I),de(d,"RID",a),de(d,"CVER",22),this.D&&de(d,"X-HTTP-Session-Id",this.D),Xr(this,d),R&&(this.O?u="headers="+encodeURIComponent(String(Gl(R)))+"&"+u:this.m&&ia(d,this.m,R)),sa(this.h,b),this.Ua&&de(d,"TYPE","init"),this.P?(de(d,"$req",u),de(d,"SID","null"),b.T=!0,ea(b,d,null)):ea(b,d,u),this.G=2}}else this.G==3&&(a?Xl(this,a):this.i.length==0||Vl(this.h)||Xl(this))};function Xl(a,u){var d;u?d=u.l:d=a.U++;const p=Et(a.I);de(p,"SID",a.K),de(p,"RID",d),de(p,"AID",a.T),Xr(a,p),a.m&&a.o&&ia(p,a.m,a.o),d=new Nt(a,a.j,d,a.B+1),a.m===null&&(d.H=a.o),u&&(a.i=u.D.concat(a.i)),u=Zl(a,d,1e3),d.I=Math.round(.5*a.wa)+Math.round(.5*a.wa*Math.random()),sa(a.h,d),ea(d,p,u)}function Xr(a,u){a.H&&M(a.H,function(d,p){de(u,p,d)}),a.l&&Ml({},function(d,p){de(u,p,d)})}function Zl(a,u,d){d=Math.min(a.i.length,d);var p=a.l?I(a.l.Na,a.l,a):null;e:{var b=a.i;let R=-1;for(;;){const O=["count="+d];R==-1?0<d?(R=b[0].g,O.push("ofs="+R)):R=0:O.push("ofs="+R);let ue=!0;for(let ke=0;ke<d;ke++){let oe=b[ke].g;const xe=b[ke].map;if(oe-=R,0>oe)R=Math.max(0,b[ke].g-100),ue=!1;else try{fg(xe,O,"req"+oe+"_")}catch{p&&p(xe)}}if(ue){p=O.join("&");break e}}}return a=a.i.splice(0,d),u.D=a,p}function eu(a){if(!a.g&&!a.u){a.Y=1;var u=a.Fa;Mr||ul(),Lr||(Mr(),Lr=!0),Uo.add(u,a),a.v=0}}function aa(a){return a.g||a.u||3<=a.v?!1:(a.Y++,a.u=qr(I(a.Fa,a),ru(a,a.v)),a.v++,!0)}n.Fa=function(){if(this.u=null,tu(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var a=2*this.R;this.j.info("BP detection timer enabled: "+a),this.A=qr(I(this.ab,this),a)}},n.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,Be(10),ii(this),tu(this))};function ca(a){a.A!=null&&(c.clearTimeout(a.A),a.A=null)}function tu(a){a.g=new Nt(a,a.j,"rpc",a.Y),a.m===null&&(a.g.H=a.o),a.g.O=0;var u=Et(a.qa);de(u,"RID","rpc"),de(u,"SID",a.K),de(u,"AID",a.T),de(u,"CI",a.F?"0":"1"),!a.F&&a.ja&&de(u,"TO",a.ja),de(u,"TYPE","xmlhttp"),Xr(a,u),a.m&&a.o&&ia(u,a.m,a.o),a.L&&(a.g.I=a.L);var d=a.g;a=a.ia,d.L=1,d.v=ni(Et(u)),d.m=null,d.P=!0,Pl(d,a)}n.Za=function(){this.C!=null&&(this.C=null,ii(this),aa(this),Be(19))};function ai(a){a.C!=null&&(c.clearTimeout(a.C),a.C=null)}function nu(a,u){var d=null;if(a.g==u){ai(a),ca(a),a.g=null;var p=2}else if(ra(a.h,u))d=u.D,xl(a.h,u),p=1;else return;if(a.G!=0){if(u.o)if(p==1){d=u.m?u.m.length:0,u=Date.now()-u.F;var b=a.B;p=Js(),Ue(p,new bl(p,d)),oi(a)}else eu(a);else if(b=u.s,b==3||b==0&&0<u.X||!(p==1&&_g(a,u)||p==2&&aa(a)))switch(d&&0<d.length&&(u=a.h,u.i=u.i.concat(d)),b){case 1:mn(a,5);break;case 4:mn(a,10);break;case 3:mn(a,6);break;default:mn(a,2)}}}function ru(a,u){let d=a.Ta+Math.floor(Math.random()*a.cb);return a.isActive()||(d*=2),d*u}function mn(a,u){if(a.j.info("Error code "+u),u==2){var d=I(a.fb,a),p=a.Xa;const b=!p;p=new pn(p||"//www.google.com/images/cleardot.gif"),c.location&&c.location.protocol=="http"||ei(p,"https"),ni(p),b?ug(p.toString(),d):hg(p.toString(),d)}else Be(2);a.G=0,a.l&&a.l.sa(u),su(a),Yl(a)}n.fb=function(a){a?(this.j.info("Successfully pinged google.com"),Be(2)):(this.j.info("Failed to ping google.com"),Be(1))};function su(a){if(a.G=0,a.ka=[],a.l){const u=Ol(a.h);(u.length!=0||a.i.length!=0)&&(P(a.ka,u),P(a.ka,a.i),a.h.i.length=0,N(a.i),a.i.length=0),a.l.ra()}}function iu(a,u,d){var p=d instanceof pn?Et(d):new pn(d);if(p.g!="")u&&(p.g=u+"."+p.g),ti(p,p.s);else{var b=c.location;p=b.protocol,u=u?u+"."+b.hostname:b.hostname,b=+b.port;var R=new pn(null);p&&ei(R,p),u&&(R.g=u),b&&ti(R,b),d&&(R.l=d),p=R}return d=a.D,u=a.ya,d&&u&&de(p,d,u),de(p,"VER",a.la),Xr(a,p),p}function ou(a,u,d){if(u&&!a.J)throw Error("Can't create secondary domain capable XhrIo object.");return u=a.Ca&&!a.pa?new me(new Hr({eb:d})):new me(a.pa),u.Ha(a.J),u}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function au(){}n=au.prototype,n.ua=function(){},n.ta=function(){},n.sa=function(){},n.ra=function(){},n.isActive=function(){return!0},n.Na=function(){};function ci(){}ci.prototype.g=function(a,u){return new Ye(a,u)};function Ye(a,u){Ne.call(this),this.g=new Jl(u),this.l=a,this.h=u&&u.messageUrlParams||null,a=u&&u.messageHeaders||null,u&&u.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=u&&u.initMessageHeaders||null,u&&u.messageContentType&&(a?a["X-WebChannel-Content-Type"]=u.messageContentType:a={"X-WebChannel-Content-Type":u.messageContentType}),u&&u.va&&(a?a["X-WebChannel-Client-Profile"]=u.va:a={"X-WebChannel-Client-Profile":u.va}),this.g.S=a,(a=u&&u.Sb)&&!K(a)&&(this.g.m=a),this.v=u&&u.supportsCrossDomainXhr||!1,this.u=u&&u.sendRawJson||!1,(u=u&&u.httpSessionIdParam)&&!K(u)&&(this.g.D=u,a=this.h,a!==null&&u in a&&(a=this.h,u in a&&delete a[u])),this.j=new Kn(this)}D(Ye,Ne),Ye.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},Ye.prototype.close=function(){oa(this.g)},Ye.prototype.o=function(a){var u=this.g;if(typeof a=="string"){var d={};d.__data__=a,a=d}else this.u&&(d={},d.__data__=Ho(a),a=d);u.i.push(new eg(u.Ya++,a)),u.G==3&&oi(u)},Ye.prototype.N=function(){this.g.l=null,delete this.j,oa(this.g),delete this.g,Ye.aa.N.call(this)};function cu(a){Jo.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var u=a.__sm__;if(u){e:{for(const d in u){a=d;break e}a=void 0}(this.i=a)&&(a=this.i,u=u!==null&&a in u?u[a]:void 0),this.data=u}else this.data=a}D(cu,Jo);function lu(){Yo.call(this),this.status=1}D(lu,Yo);function Kn(a){this.g=a}D(Kn,au),Kn.prototype.ua=function(){Ue(this.g,"a")},Kn.prototype.ta=function(a){Ue(this.g,new cu(a))},Kn.prototype.sa=function(a){Ue(this.g,new lu)},Kn.prototype.ra=function(){Ue(this.g,"b")},ci.prototype.createWebChannel=ci.prototype.g,Ye.prototype.send=Ye.prototype.o,Ye.prototype.open=Ye.prototype.m,Ye.prototype.close=Ye.prototype.close,af=function(){return new ci},of=function(){return Js()},sf=dn,Oa={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},Ys.NO_ERROR=0,Ys.TIMEOUT=8,Ys.HTTP_ERROR=6,Ti=Ys,Al.COMPLETE="complete",rf=Al,Il.EventType=Ur,Ur.OPEN="a",Ur.CLOSE="b",Ur.ERROR="c",Ur.MESSAGE="d",Ne.prototype.listen=Ne.prototype.K,os=Il,nf=Hr,me.prototype.listenOnce=me.prototype.L,me.prototype.getLastError=me.prototype.Ka,me.prototype.getLastErrorCode=me.prototype.Ba,me.prototype.getStatus=me.prototype.Z,me.prototype.getResponseJson=me.prototype.Oa,me.prototype.getResponseText=me.prototype.oa,me.prototype.send=me.prototype.ea,me.prototype.setWithCredentials=me.prototype.Ha,tf=me}).apply(typeof hi<"u"?hi:typeof self<"u"?self:typeof window<"u"?window:{});const Bu="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Le{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Le.UNAUTHENTICATED=new Le(null),Le.GOOGLE_CREDENTIALS=new Le("google-credentials-uid"),Le.FIRST_PARTY=new Le("first-party-uid"),Le.MOCK_USER=new Le("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Vr="10.12.1";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dn=new oc("@firebase/firestore");function Zn(){return Dn.logLevel}function k(n,...e){if(Dn.logLevel<=te.DEBUG){const t=e.map(yc);Dn.debug(`Firestore (${Vr}): ${n}`,...t)}}function ve(n,...e){if(Dn.logLevel<=te.ERROR){const t=e.map(yc);Dn.error(`Firestore (${Vr}): ${n}`,...t)}}function Ts(n,...e){if(Dn.logLevel<=te.WARN){const t=e.map(yc);Dn.warn(`Firestore (${Vr}): ${n}`,...t)}}function yc(n){if(typeof n=="string")return n;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function U(n="Unexpected state"){const e=`FIRESTORE (${Vr}) INTERNAL ASSERTION FAILED: `+n;throw ve(e),new Error(e)}function j(n,e){n||U()}function B(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const C={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class $ extends kt{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jt{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lI{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class uI{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(Le.UNAUTHENTICATED))}shutdown(){}}class hI{constructor(e){this.t=e,this.currentUser=Le.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){let r=this.i;const s=l=>this.i!==r?(r=this.i,t(l)):Promise.resolve();let i=new Jt;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new Jt,e.enqueueRetryable(()=>s(this.currentUser))};const o=()=>{const l=i;e.enqueueRetryable(async()=>{await l.promise,await s(this.currentUser)})},c=l=>{k("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.auth.addAuthTokenListener(this.o),o()};this.t.onInit(l=>c(l)),setTimeout(()=>{if(!this.auth){const l=this.t.getImmediate({optional:!0});l?c(l):(k("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new Jt)}},0),o()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(r=>this.i!==e?(k("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(j(typeof r.accessToken=="string"),new lI(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const e=this.auth&&this.auth.getUid();return j(e===null||typeof e=="string"),new Le(e)}}class dI{constructor(e,t,r){this.l=e,this.h=t,this.P=r,this.type="FirstParty",this.user=Le.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);const e=this.T();return e&&this.I.set("Authorization",e),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class fI{constructor(e,t,r){this.l=e,this.h=t,this.P=r}getToken(){return Promise.resolve(new dI(this.l,this.h,this.P))}start(e,t){e.enqueueRetryable(()=>t(Le.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class pI{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class mI{constructor(e){this.A=e,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(e,t){const r=i=>{i.error!=null&&k("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const o=i.token!==this.R;return this.R=i.token,k("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?t(i.token):Promise.resolve()};this.o=i=>{e.enqueueRetryable(()=>r(i))};const s=i=>{k("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.appCheck.addTokenListener(this.o)};this.A.onInit(i=>s(i)),setTimeout(()=>{if(!this.appCheck){const i=this.A.getImmediate({optional:!0});i?s(i):k("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(j(typeof t.token=="string"),this.R=t.token,new pI(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gI(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let r=0;r<n;r++)t[r]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cf{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=Math.floor(256/e.length)*e.length;let r="";for(;r.length<20;){const s=gI(40);for(let i=0;i<s.length;++i)r.length<20&&s[i]<t&&(r+=e.charAt(s[i]%e.length))}return r}}function Y(n,e){return n<e?-1:n>e?1:0}function dr(n,e,t){return n.length===e.length&&n.every((r,s)=>t(r,e[s]))}function lf(n){return n+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pe{constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new $(C.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new $(C.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<-62135596800)throw new $(C.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new $(C.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return pe.fromMillis(Date.now())}static fromDate(e){return pe.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),r=Math.floor(1e6*(e-1e3*t));return new pe(t,r)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?Y(this.nanoseconds,e.nanoseconds):Y(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class G{constructor(e){this.timestamp=e}static fromTimestamp(e){return new G(e)}static min(){return new G(new pe(0,0))}static max(){return new G(new pe(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bs{constructor(e,t,r){t===void 0?t=0:t>e.length&&U(),r===void 0?r=e.length-t:r>e.length-t&&U(),this.segments=e,this.offset=t,this.len=r}get length(){return this.len}isEqual(e){return bs.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof bs?e.forEach(r=>{t.push(r)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,r=this.limit();t<r;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const r=Math.min(e.length,t.length);for(let s=0;s<r;s++){const i=e.get(s),o=t.get(s);if(i<o)return-1;if(i>o)return 1}return e.length<t.length?-1:e.length>t.length?1:0}}class ae extends bs{construct(e,t,r){return new ae(e,t,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const r of e){if(r.indexOf("//")>=0)throw new $(C.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);t.push(...r.split("/").filter(s=>s.length>0))}return new ae(t)}static emptyPath(){return new ae([])}}const _I=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class fe extends bs{construct(e,t,r){return new fe(e,t,r)}static isValidIdentifier(e){return _I.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),fe.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)==="__name__"}static keyField(){return new fe(["__name__"])}static fromServerFormat(e){const t=[];let r="",s=0;const i=()=>{if(r.length===0)throw new $(C.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(r),r=""};let o=!1;for(;s<e.length;){const c=e[s];if(c==="\\"){if(s+1===e.length)throw new $(C.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const l=e[s+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new $(C.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);r+=l,s+=2}else c==="`"?(o=!o,s++):c!=="."||o?(r+=c,s++):(i(),s++)}if(i(),o)throw new $(C.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new fe(t)}static emptyPath(){return new fe([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class F{constructor(e){this.path=e}static fromPath(e){return new F(ae.fromString(e))}static fromName(e){return new F(ae.fromString(e).popFirst(5))}static empty(){return new F(ae.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&ae.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return ae.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new F(new ae(e.slice()))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qi{constructor(e,t,r,s){this.indexId=e,this.collectionGroup=t,this.fields=r,this.indexState=s}}function Ma(n){return n.fields.find(e=>e.kind===2)}function yn(n){return n.fields.filter(e=>e.kind!==2)}qi.UNKNOWN_ID=-1;class bi{constructor(e,t){this.fieldPath=e,this.kind=t}}class As{constructor(e,t){this.sequenceNumber=e,this.offset=t}static empty(){return new As(0,rt.min())}}function uf(n,e){const t=n.toTimestamp().seconds,r=n.toTimestamp().nanoseconds+1,s=G.fromTimestamp(r===1e9?new pe(t+1,0):new pe(t,r));return new rt(s,F.empty(),e)}function hf(n){return new rt(n.readTime,n.key,-1)}class rt{constructor(e,t,r){this.readTime=e,this.documentKey=t,this.largestBatchId=r}static min(){return new rt(G.min(),F.empty(),-1)}static max(){return new rt(G.max(),F.empty(),-1)}}function vc(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=F.comparator(n.documentKey,e.documentKey),t!==0?t:Y(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const df="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class ff{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function an(n){if(n.code!==C.FAILED_PRECONDITION||n.message!==df)throw n;k("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class A{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&U(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new A((r,s)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(r,s)},this.catchCallback=i=>{this.wrapFailure(t,i).next(r,s)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof A?t:A.resolve(t)}catch(t){return A.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):A.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):A.reject(t)}static resolve(e){return new A((t,r)=>{t(e)})}static reject(e){return new A((t,r)=>{r(e)})}static waitFor(e){return new A((t,r)=>{let s=0,i=0,o=!1;e.forEach(c=>{++s,c.next(()=>{++i,o&&i===s&&t()},l=>r(l))}),o=!0,i===s&&t()})}static or(e){let t=A.resolve(!1);for(const r of e)t=t.next(s=>s?A.resolve(s):r());return t}static forEach(e,t){const r=[];return e.forEach((s,i)=>{r.push(t.call(this,s,i))}),this.waitFor(r)}static mapArray(e,t){return new A((r,s)=>{const i=e.length,o=new Array(i);let c=0;for(let l=0;l<i;l++){const h=l;t(e[h]).next(f=>{o[h]=f,++c,c===i&&r(o)},f=>s(f))}})}static doWhile(e,t){return new A((r,s)=>{const i=()=>{e()===!0?t().next(()=>{i()},s):r()};i()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mo{constructor(e,t){this.action=e,this.transaction=t,this.aborted=!1,this.V=new Jt,this.transaction.oncomplete=()=>{this.V.resolve()},this.transaction.onabort=()=>{t.error?this.V.reject(new ds(e,t.error)):this.V.resolve()},this.transaction.onerror=r=>{const s=Ic(r.target.error);this.V.reject(new ds(e,s))}}static open(e,t,r,s){try{return new mo(t,e.transaction(s,r))}catch(i){throw new ds(t,i)}}get m(){return this.V.promise}abort(e){e&&this.V.reject(e),this.aborted||(k("SimpleDb","Aborting transaction:",e?e.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}g(){const e=this.transaction;this.aborted||typeof e.commit!="function"||e.commit()}store(e){const t=this.transaction.objectStore(e);return new vI(t)}}class Yt{constructor(e,t,r){this.name=e,this.version=t,this.p=r,Yt.S(be())===12.2&&ve("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}static delete(e){return k("SimpleDb","Removing database:",e),vn(window.indexedDB.deleteDatabase(e)).toPromise()}static D(){if(!gd())return!1;if(Yt.C())return!0;const e=be(),t=Yt.S(e),r=0<t&&t<10,s=pf(e),i=0<s&&s<4.5;return!(e.indexOf("MSIE ")>0||e.indexOf("Trident/")>0||e.indexOf("Edge/")>0||r||i)}static C(){var e;return typeof process<"u"&&((e=process.__PRIVATE_env)===null||e===void 0?void 0:e.v)==="YES"}static F(e,t){return e.store(t)}static S(e){const t=e.match(/i(?:phone|pad|pod) os ([\d_]+)/i),r=t?t[1].split("_").slice(0,2).join("."):"-1";return Number(r)}async M(e){return this.db||(k("SimpleDb","Opening database:",this.name),this.db=await new Promise((t,r)=>{const s=indexedDB.open(this.name,this.version);s.onsuccess=i=>{const o=i.target.result;t(o)},s.onblocked=()=>{r(new ds(e,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},s.onerror=i=>{const o=i.target.error;o.name==="VersionError"?r(new $(C.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):o.name==="InvalidStateError"?r(new $(C.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+o)):r(new ds(e,o))},s.onupgradeneeded=i=>{k("SimpleDb",'Database "'+this.name+'" requires upgrade from version:',i.oldVersion);const o=i.target.result;this.p.O(o,s.transaction,i.oldVersion,this.version).next(()=>{k("SimpleDb","Database upgrade to version "+this.version+" complete")})}})),this.N&&(this.db.onversionchange=t=>this.N(t)),this.db}L(e){this.N=e,this.db&&(this.db.onversionchange=t=>e(t))}async runTransaction(e,t,r,s){const i=t==="readonly";let o=0;for(;;){++o;try{this.db=await this.M(e);const c=mo.open(this.db,e,i?"readonly":"readwrite",r),l=s(c).next(h=>(c.g(),h)).catch(h=>(c.abort(h),A.reject(h))).toPromise();return l.catch(()=>{}),await c.m,l}catch(c){const l=c,h=l.name!=="FirebaseError"&&o<3;if(k("SimpleDb","Transaction failed with error:",l.message,"Retrying:",h),this.close(),!h)return Promise.reject(l)}}}close(){this.db&&this.db.close(),this.db=void 0}}function pf(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}class yI{constructor(e){this.B=e,this.k=!1,this.q=null}get isDone(){return this.k}get K(){return this.q}set cursor(e){this.B=e}done(){this.k=!0}$(e){this.q=e}delete(){return vn(this.B.delete())}}class ds extends ${constructor(e,t){super(C.UNAVAILABLE,`IndexedDB transaction '${e}' failed: ${t}`),this.name="IndexedDbTransactionError"}}function cn(n){return n.name==="IndexedDbTransactionError"}class vI{constructor(e){this.store=e}put(e,t){let r;return t!==void 0?(k("SimpleDb","PUT",this.store.name,e,t),r=this.store.put(t,e)):(k("SimpleDb","PUT",this.store.name,"<auto-key>",e),r=this.store.put(e)),vn(r)}add(e){return k("SimpleDb","ADD",this.store.name,e,e),vn(this.store.add(e))}get(e){return vn(this.store.get(e)).next(t=>(t===void 0&&(t=null),k("SimpleDb","GET",this.store.name,e,t),t))}delete(e){return k("SimpleDb","DELETE",this.store.name,e),vn(this.store.delete(e))}count(){return k("SimpleDb","COUNT",this.store.name),vn(this.store.count())}U(e,t){const r=this.options(e,t),s=r.index?this.store.index(r.index):this.store;if(typeof s.getAll=="function"){const i=s.getAll(r.range);return new A((o,c)=>{i.onerror=l=>{c(l.target.error)},i.onsuccess=l=>{o(l.target.result)}})}{const i=this.cursor(r),o=[];return this.W(i,(c,l)=>{o.push(l)}).next(()=>o)}}G(e,t){const r=this.store.getAll(e,t===null?void 0:t);return new A((s,i)=>{r.onerror=o=>{i(o.target.error)},r.onsuccess=o=>{s(o.target.result)}})}j(e,t){k("SimpleDb","DELETE ALL",this.store.name);const r=this.options(e,t);r.H=!1;const s=this.cursor(r);return this.W(s,(i,o,c)=>c.delete())}J(e,t){let r;t?r=e:(r={},t=e);const s=this.cursor(r);return this.W(s,t)}Y(e){const t=this.cursor({});return new A((r,s)=>{t.onerror=i=>{const o=Ic(i.target.error);s(o)},t.onsuccess=i=>{const o=i.target.result;o?e(o.primaryKey,o.value).next(c=>{c?o.continue():r()}):r()}})}W(e,t){const r=[];return new A((s,i)=>{e.onerror=o=>{i(o.target.error)},e.onsuccess=o=>{const c=o.target.result;if(!c)return void s();const l=new yI(c),h=t(c.primaryKey,c.value,l);if(h instanceof A){const f=h.catch(m=>(l.done(),A.reject(m)));r.push(f)}l.isDone?s():l.K===null?c.continue():c.continue(l.K)}}).next(()=>A.waitFor(r))}options(e,t){let r;return e!==void 0&&(typeof e=="string"?r=e:t=e),{index:r,range:t}}cursor(e){let t="next";if(e.reverse&&(t="prev"),e.index){const r=this.store.index(e.index);return e.H?r.openKeyCursor(e.range,t):r.openCursor(e.range,t)}return this.store.openCursor(e.range,t)}}function vn(n){return new A((e,t)=>{n.onsuccess=r=>{const s=r.target.result;e(s)},n.onerror=r=>{const s=Ic(r.target.error);t(s)}})}let qu=!1;function Ic(n){const e=Yt.S(be());if(e>=12.2&&e<13){const t="An internal error was encountered in the Indexed Database server";if(n.message.indexOf(t)>=0){const r=new $("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${t}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return qu||(qu=!0,setTimeout(()=>{throw r},0)),r}}return n}class II{constructor(e,t){this.asyncQueue=e,this.Z=t,this.task=null}start(){this.X(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}X(e){k("IndexBackfiller",`Scheduled in ${e}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",e,async()=>{this.task=null;try{k("IndexBackfiller",`Documents written: ${await this.Z.ee()}`)}catch(t){cn(t)?k("IndexBackfiller","Ignoring IndexedDB error during index backfill: ",t):await an(t)}await this.X(6e4)})}}class EI{constructor(e,t){this.localStore=e,this.persistence=t}async ee(e=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",t=>this.te(t,e))}te(e,t){const r=new Set;let s=t,i=!0;return A.doWhile(()=>i===!0&&s>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(e).next(o=>{if(o!==null&&!r.has(o))return k("IndexBackfiller",`Processing collection: ${o}`),this.ne(e,o,s).next(c=>{s-=c,r.add(o)});i=!1})).next(()=>t-s)}ne(e,t,r){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(e,t).next(s=>this.localStore.localDocuments.getNextDocuments(e,t,s,r).next(i=>{const o=i.changes;return this.localStore.indexManager.updateIndexEntries(e,o).next(()=>this.re(s,i)).next(c=>(k("IndexBackfiller",`Updating offset: ${c}`),this.localStore.indexManager.updateCollectionGroup(e,t,c))).next(()=>o.size)}))}re(e,t){let r=e;return t.changes.forEach((s,i)=>{const o=hf(i);vc(o,r)>0&&(r=o)}),new rt(r.readTime,r.documentKey,Math.max(t.batchId,e.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class We{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=r=>this.ie(r),this.se=r=>t.writeSequenceNumber(r))}ie(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.se&&this.se(e),e}}We.oe=-1;function go(n){return n==null}function Ss(n){return n===0&&1/n==-1/0}function mf(n){return typeof n=="number"&&Number.isInteger(n)&&!Ss(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function je(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=ju(e)),e=wI(n.get(t),e);return ju(e)}function wI(n,e){let t=e;const r=n.length;for(let s=0;s<r;s++){const i=n.charAt(s);switch(i){case"\0":t+="";break;case"":t+="";break;default:t+=i}}return t}function ju(n){return n+""}function dt(n){const e=n.length;if(j(e>=2),e===2)return j(n.charAt(0)===""&&n.charAt(1)===""),ae.emptyPath();const t=e-2,r=[];let s="";for(let i=0;i<e;){const o=n.indexOf("",i);switch((o<0||o>t)&&U(),n.charAt(o+1)){case"":const c=n.substring(i,o);let l;s.length===0?l=c:(s+=c,l=s,s=""),r.push(l);break;case"":s+=n.substring(i,o),s+="\0";break;case"":s+=n.substring(i,o+1);break;default:U()}i=o+2}return new ae(r)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gu=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ai(n,e){return[n,je(e)]}function gf(n,e,t){return[n,je(e),t]}const TI={},bI=["prefixPath","collectionGroup","readTime","documentId"],AI=["prefixPath","collectionGroup","documentId"],SI=["collectionGroup","readTime","prefixPath","documentId"],RI=["canonicalId","targetId"],PI=["targetId","path"],CI=["path","targetId"],kI=["collectionId","parent"],DI=["indexId","uid"],VI=["uid","sequenceNumber"],NI=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],xI=["indexId","uid","orderedDocumentKey"],OI=["userId","collectionPath","documentId"],MI=["userId","collectionPath","largestBatchId"],LI=["userId","collectionGroup","largestBatchId"],_f=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],FI=[..._f,"documentOverlays"],yf=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],vf=yf,If=[...vf,"indexConfiguration","indexState","indexEntries"],$I=If;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class La extends ff{constructor(e,t){super(),this._e=e,this.currentSequenceNumber=t}}function Ce(n,e){const t=B(n);return Yt.F(t._e,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zu(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function qn(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function Ef(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class he{constructor(e,t){this.comparator=e,this.root=t||De.EMPTY}insert(e,t){return new he(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,De.BLACK,null,null))}remove(e){return new he(this.comparator,this.root.remove(e,this.comparator).copy(null,null,De.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const r=this.comparator(e,t.key);if(r===0)return t.value;r<0?t=t.left:r>0&&(t=t.right)}return null}indexOf(e){let t=0,r=this.root;for(;!r.isEmpty();){const s=this.comparator(e,r.key);if(s===0)return t+r.left.size;s<0?r=r.left:(t+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,r)=>(e(t,r),!1))}toString(){const e=[];return this.inorderTraversal((t,r)=>(e.push(`${t}:${r}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new di(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new di(this.root,e,this.comparator,!1)}getReverseIterator(){return new di(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new di(this.root,e,this.comparator,!0)}}class di{constructor(e,t,r,s){this.isReverse=s,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?r(e.key,t):1,t&&s&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class De{constructor(e,t,r,s,i){this.key=e,this.value=t,this.color=r??De.RED,this.left=s??De.EMPTY,this.right=i??De.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,r,s,i){return new De(e??this.key,t??this.value,r??this.color,s??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,r){let s=this;const i=r(e,s.key);return s=i<0?s.copy(null,null,null,s.left.insert(e,t,r),null):i===0?s.copy(null,t,null,null,null):s.copy(null,null,null,null,s.right.insert(e,t,r)),s.fixUp()}removeMin(){if(this.left.isEmpty())return De.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let r,s=this;if(t(e,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(e,t),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),t(e,s.key)===0){if(s.right.isEmpty())return De.EMPTY;r=s.right.min(),s=s.copy(r.key,r.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(e,t))}return s.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,De.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,De.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw U();const e=this.left.check();if(e!==this.right.check())throw U();return e+(this.isRed()?0:1)}}De.EMPTY=null,De.RED=!0,De.BLACK=!1;De.EMPTY=new class{constructor(){this.size=0}get key(){throw U()}get value(){throw U()}get color(){throw U()}get left(){throw U()}get right(){throw U()}copy(e,t,r,s,i){return this}insert(e,t,r){return new De(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class le{constructor(e){this.comparator=e,this.data=new he(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,r)=>(e(t),!1))}forEachInRange(e,t){const r=this.data.getIteratorFrom(e[0]);for(;r.hasNext();){const s=r.getNext();if(this.comparator(s.key,e[1])>=0)return;t(s.key)}}forEachWhile(e,t){let r;for(r=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();r.hasNext();)if(!e(r.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Ku(this.data.getIterator())}getIteratorFrom(e){return new Ku(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(r=>{t=t.add(r)}),t}isEqual(e){if(!(e instanceof le)||this.size!==e.size)return!1;const t=this.data.getIterator(),r=e.data.getIterator();for(;t.hasNext();){const s=t.getNext().key,i=r.getNext().key;if(this.comparator(s,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new le(this.comparator);return t.data=e,t}}class Ku{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function Hn(n){return n.hasNext()?n.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class He{constructor(e){this.fields=e,e.sort(fe.comparator)}static empty(){return new He([])}unionWith(e){let t=new le(fe.comparator);for(const r of this.fields)t=t.add(r);for(const r of e)t=t.add(r);return new He(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return dr(this.fields,e.fields,(t,r)=>t.isEqual(r))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wf extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pe{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(s){try{return atob(s)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new wf("Invalid base64 string: "+i):i}}(e);return new Pe(t)}static fromUint8Array(e){const t=function(s){let i="";for(let o=0;o<s.length;++o)i+=String.fromCharCode(s[o]);return i}(e);return new Pe(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const r=new Uint8Array(t.length);for(let s=0;s<t.length;s++)r[s]=t.charCodeAt(s);return r}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return Y(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}Pe.EMPTY_BYTE_STRING=new Pe("");const UI=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Ct(n){if(j(!!n),typeof n=="string"){let e=0;const t=UI.exec(n);if(j(!!t),t[1]){let s=t[1];s=(s+"000000000").substr(0,9),e=Number(s)}const r=new Date(n);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:ge(n.seconds),nanos:ge(n.nanos)}}function ge(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function tn(n){return typeof n=="string"?Pe.fromBase64String(n):Pe.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ec(n){var e,t;return((t=(((e=n==null?void 0:n.mapValue)===null||e===void 0?void 0:e.fields)||{}).__type__)===null||t===void 0?void 0:t.stringValue)==="server_timestamp"}function wc(n){const e=n.mapValue.fields.__previous_value__;return Ec(e)?wc(e):e}function Rs(n){const e=Ct(n.mapValue.fields.__local_write_time__.timestampValue);return new pe(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BI{constructor(e,t,r,s,i,o,c,l,h){this.databaseId=e,this.appId=t,this.persistenceKey=r,this.host=s,this.ssl=i,this.forceLongPolling=o,this.autoDetectLongPolling=c,this.longPollingOptions=l,this.useFetchStreams=h}}class Vn{constructor(e,t){this.projectId=e,this.database=t||"(default)"}static empty(){return new Vn("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(e){return e instanceof Vn&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zt={mapValue:{fields:{__type__:{stringValue:"__max__"}}}},Si={nullValue:"NULL_VALUE"};function Nn(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?Ec(n)?4:Tf(n)?9007199254740991:10:U()}function yt(n,e){if(n===e)return!0;const t=Nn(n);if(t!==Nn(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return Rs(n).isEqual(Rs(e));case 3:return function(s,i){if(typeof s.timestampValue=="string"&&typeof i.timestampValue=="string"&&s.timestampValue.length===i.timestampValue.length)return s.timestampValue===i.timestampValue;const o=Ct(s.timestampValue),c=Ct(i.timestampValue);return o.seconds===c.seconds&&o.nanos===c.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(s,i){return tn(s.bytesValue).isEqual(tn(i.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(s,i){return ge(s.geoPointValue.latitude)===ge(i.geoPointValue.latitude)&&ge(s.geoPointValue.longitude)===ge(i.geoPointValue.longitude)}(n,e);case 2:return function(s,i){if("integerValue"in s&&"integerValue"in i)return ge(s.integerValue)===ge(i.integerValue);if("doubleValue"in s&&"doubleValue"in i){const o=ge(s.doubleValue),c=ge(i.doubleValue);return o===c?Ss(o)===Ss(c):isNaN(o)&&isNaN(c)}return!1}(n,e);case 9:return dr(n.arrayValue.values||[],e.arrayValue.values||[],yt);case 10:return function(s,i){const o=s.mapValue.fields||{},c=i.mapValue.fields||{};if(zu(o)!==zu(c))return!1;for(const l in o)if(o.hasOwnProperty(l)&&(c[l]===void 0||!yt(o[l],c[l])))return!1;return!0}(n,e);default:return U()}}function Ps(n,e){return(n.values||[]).find(t=>yt(t,e))!==void 0}function nn(n,e){if(n===e)return 0;const t=Nn(n),r=Nn(e);if(t!==r)return Y(t,r);switch(t){case 0:case 9007199254740991:return 0;case 1:return Y(n.booleanValue,e.booleanValue);case 2:return function(i,o){const c=ge(i.integerValue||i.doubleValue),l=ge(o.integerValue||o.doubleValue);return c<l?-1:c>l?1:c===l?0:isNaN(c)?isNaN(l)?0:-1:1}(n,e);case 3:return Wu(n.timestampValue,e.timestampValue);case 4:return Wu(Rs(n),Rs(e));case 5:return Y(n.stringValue,e.stringValue);case 6:return function(i,o){const c=tn(i),l=tn(o);return c.compareTo(l)}(n.bytesValue,e.bytesValue);case 7:return function(i,o){const c=i.split("/"),l=o.split("/");for(let h=0;h<c.length&&h<l.length;h++){const f=Y(c[h],l[h]);if(f!==0)return f}return Y(c.length,l.length)}(n.referenceValue,e.referenceValue);case 8:return function(i,o){const c=Y(ge(i.latitude),ge(o.latitude));return c!==0?c:Y(ge(i.longitude),ge(o.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return function(i,o){const c=i.values||[],l=o.values||[];for(let h=0;h<c.length&&h<l.length;++h){const f=nn(c[h],l[h]);if(f)return f}return Y(c.length,l.length)}(n.arrayValue,e.arrayValue);case 10:return function(i,o){if(i===zt.mapValue&&o===zt.mapValue)return 0;if(i===zt.mapValue)return 1;if(o===zt.mapValue)return-1;const c=i.fields||{},l=Object.keys(c),h=o.fields||{},f=Object.keys(h);l.sort(),f.sort();for(let m=0;m<l.length&&m<f.length;++m){const I=Y(l[m],f[m]);if(I!==0)return I;const S=nn(c[l[m]],h[f[m]]);if(S!==0)return S}return Y(l.length,f.length)}(n.mapValue,e.mapValue);default:throw U()}}function Wu(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return Y(n,e);const t=Ct(n),r=Ct(e),s=Y(t.seconds,r.seconds);return s!==0?s:Y(t.nanos,r.nanos)}function fr(n){return Fa(n)}function Fa(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const r=Ct(t);return`time(${r.seconds},${r.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return tn(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return F.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let r="[",s=!0;for(const i of t.values||[])s?s=!1:r+=",",r+=Fa(i);return r+"]"}(n.arrayValue):"mapValue"in n?function(t){const r=Object.keys(t.fields||{}).sort();let s="{",i=!0;for(const o of r)i?i=!1:s+=",",s+=`${o}:${Fa(t.fields[o])}`;return s+"}"}(n.mapValue):U()}function Tc(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function $a(n){return!!n&&"integerValue"in n}function Cs(n){return!!n&&"arrayValue"in n}function Hu(n){return!!n&&"nullValue"in n}function Qu(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function Ri(n){return!!n&&"mapValue"in n}function fs(n){if(n.geoPointValue)return{geoPointValue:Object.assign({},n.geoPointValue)};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:Object.assign({},n.timestampValue)};if(n.mapValue){const e={mapValue:{fields:{}}};return qn(n.mapValue.fields,(t,r)=>e.mapValue.fields[t]=fs(r)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=fs(n.arrayValue.values[t]);return e}return Object.assign({},n)}function Tf(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue==="__max__"}function qI(n){return"nullValue"in n?Si:"booleanValue"in n?{booleanValue:!1}:"integerValue"in n||"doubleValue"in n?{doubleValue:NaN}:"timestampValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in n?{stringValue:""}:"bytesValue"in n?{bytesValue:""}:"referenceValue"in n?Tc(Vn.empty(),F.empty()):"geoPointValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in n?{arrayValue:{}}:"mapValue"in n?{mapValue:{}}:U()}function jI(n){return"nullValue"in n?{booleanValue:!1}:"booleanValue"in n?{doubleValue:NaN}:"integerValue"in n||"doubleValue"in n?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in n?{stringValue:""}:"stringValue"in n?{bytesValue:""}:"bytesValue"in n?Tc(Vn.empty(),F.empty()):"referenceValue"in n?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in n?{arrayValue:{}}:"arrayValue"in n?{mapValue:{}}:"mapValue"in n?zt:U()}function Ju(n,e){const t=nn(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?-1:!n.inclusive&&e.inclusive?1:0}function Yu(n,e){const t=nn(n.value,e.value);return t!==0?t:n.inclusive&&!e.inclusive?1:!n.inclusive&&e.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fe{constructor(e){this.value=e}static empty(){return new Fe({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let r=0;r<e.length-1;++r)if(t=(t.mapValue.fields||{})[e.get(r)],!Ri(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=fs(t)}setAll(e){let t=fe.emptyPath(),r={},s=[];e.forEach((o,c)=>{if(!t.isImmediateParentOf(c)){const l=this.getFieldsMap(t);this.applyChanges(l,r,s),r={},s=[],t=c.popLast()}o?r[c.lastSegment()]=fs(o):s.push(c.lastSegment())});const i=this.getFieldsMap(t);this.applyChanges(i,r,s)}delete(e){const t=this.field(e.popLast());Ri(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return yt(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let r=0;r<e.length;++r){let s=t.mapValue.fields[e.get(r)];Ri(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},t.mapValue.fields[e.get(r)]=s),t=s}return t.mapValue.fields}applyChanges(e,t,r){qn(t,(s,i)=>e[s]=i);for(const s of r)delete e[s]}clone(){return new Fe(fs(this.value))}}function bf(n){const e=[];return qn(n.fields,(t,r)=>{const s=new fe([t]);if(Ri(r)){const i=bf(r.mapValue).fields;if(i.length===0)e.push(s);else for(const o of i)e.push(s.child(o))}else e.push(s)}),new He(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _e{constructor(e,t,r,s,i,o,c){this.key=e,this.documentType=t,this.version=r,this.readTime=s,this.createTime=i,this.data=o,this.documentState=c}static newInvalidDocument(e){return new _e(e,0,G.min(),G.min(),G.min(),Fe.empty(),0)}static newFoundDocument(e,t,r,s){return new _e(e,1,t,G.min(),r,s,0)}static newNoDocument(e,t){return new _e(e,2,t,G.min(),G.min(),Fe.empty(),0)}static newUnknownDocument(e,t){return new _e(e,3,t,G.min(),G.min(),Fe.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(G.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=Fe.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=Fe.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=G.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof _e&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new _e(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pr{constructor(e,t){this.position=e,this.inclusive=t}}function Xu(n,e,t){let r=0;for(let s=0;s<n.position.length;s++){const i=e[s],o=n.position[s];if(i.field.isKeyField()?r=F.comparator(F.fromName(o.referenceValue),t.key):r=nn(o,t.data.field(i.field)),i.dir==="desc"&&(r*=-1),r!==0)break}return r}function Zu(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!yt(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ji{constructor(e,t="asc"){this.field=e,this.dir=t}}function GI(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Af{}class re extends Af{constructor(e,t,r){super(),this.field=e,this.op=t,this.value=r}static create(e,t,r){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,r):new zI(e,t,r):t==="array-contains"?new HI(e,r):t==="in"?new Df(e,r):t==="not-in"?new QI(e,r):t==="array-contains-any"?new JI(e,r):new re(e,t,r)}static createKeyFieldInFilter(e,t,r){return t==="in"?new KI(e,r):new WI(e,r)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&this.matchesComparison(nn(t,this.value)):t!==null&&Nn(this.value)===Nn(t)&&this.matchesComparison(nn(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return U()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class ce extends Af{constructor(e,t){super(),this.filters=e,this.op=t,this.ae=null}static create(e,t){return new ce(e,t)}matches(e){return mr(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.ae!==null||(this.ae=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.ae}getFilters(){return Object.assign([],this.filters)}}function mr(n){return n.op==="and"}function Ua(n){return n.op==="or"}function bc(n){return Sf(n)&&mr(n)}function Sf(n){for(const e of n.filters)if(e instanceof ce)return!1;return!0}function Ba(n){if(n instanceof re)return n.field.canonicalString()+n.op.toString()+fr(n.value);if(bc(n))return n.filters.map(e=>Ba(e)).join(",");{const e=n.filters.map(t=>Ba(t)).join(",");return`${n.op}(${e})`}}function Rf(n,e){return n instanceof re?function(r,s){return s instanceof re&&r.op===s.op&&r.field.isEqual(s.field)&&yt(r.value,s.value)}(n,e):n instanceof ce?function(r,s){return s instanceof ce&&r.op===s.op&&r.filters.length===s.filters.length?r.filters.reduce((i,o,c)=>i&&Rf(o,s.filters[c]),!0):!1}(n,e):void U()}function Pf(n,e){const t=n.filters.concat(e);return ce.create(t,n.op)}function Cf(n){return n instanceof re?function(t){return`${t.field.canonicalString()} ${t.op} ${fr(t.value)}`}(n):n instanceof ce?function(t){return t.op.toString()+" {"+t.getFilters().map(Cf).join(" ,")+"}"}(n):"Filter"}class zI extends re{constructor(e,t,r){super(e,t,r),this.key=F.fromName(r.referenceValue)}matches(e){const t=F.comparator(e.key,this.key);return this.matchesComparison(t)}}class KI extends re{constructor(e,t){super(e,"in",t),this.keys=kf("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class WI extends re{constructor(e,t){super(e,"not-in",t),this.keys=kf("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function kf(n,e){var t;return(((t=e.arrayValue)===null||t===void 0?void 0:t.values)||[]).map(r=>F.fromName(r.referenceValue))}class HI extends re{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return Cs(t)&&Ps(t.arrayValue,this.value)}}class Df extends re{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Ps(this.value.arrayValue,t)}}class QI extends re{constructor(e,t){super(e,"not-in",t)}matches(e){if(Ps(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&!Ps(this.value.arrayValue,t)}}class JI extends re{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!Cs(t)||!t.arrayValue.values)&&t.arrayValue.values.some(r=>Ps(this.value.arrayValue,r))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class YI{constructor(e,t=null,r=[],s=[],i=null,o=null,c=null){this.path=e,this.collectionGroup=t,this.orderBy=r,this.filters=s,this.limit=i,this.startAt=o,this.endAt=c,this.ue=null}}function qa(n,e=null,t=[],r=[],s=null,i=null,o=null){return new YI(n,e,t,r,s,i,o)}function xn(n){const e=B(n);if(e.ue===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(r=>Ba(r)).join(","),t+="|ob:",t+=e.orderBy.map(r=>function(i){return i.field.canonicalString()+i.dir}(r)).join(","),go(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(r=>fr(r)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(r=>fr(r)).join(",")),e.ue=t}return e.ue}function Us(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!GI(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!Rf(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Zu(n.startAt,e.startAt)&&Zu(n.endAt,e.endAt)}function Gi(n){return F.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function zi(n,e){return n.filters.filter(t=>t instanceof re&&t.field.isEqual(e))}function eh(n,e,t){let r=Si,s=!0;for(const i of zi(n,e)){let o=Si,c=!0;switch(i.op){case"<":case"<=":o=qI(i.value);break;case"==":case"in":case">=":o=i.value;break;case">":o=i.value,c=!1;break;case"!=":case"not-in":o=Si}Ju({value:r,inclusive:s},{value:o,inclusive:c})<0&&(r=o,s=c)}if(t!==null){for(let i=0;i<n.orderBy.length;++i)if(n.orderBy[i].field.isEqual(e)){const o=t.position[i];Ju({value:r,inclusive:s},{value:o,inclusive:t.inclusive})<0&&(r=o,s=t.inclusive);break}}return{value:r,inclusive:s}}function th(n,e,t){let r=zt,s=!0;for(const i of zi(n,e)){let o=zt,c=!0;switch(i.op){case">=":case">":o=jI(i.value),c=!1;break;case"==":case"in":case"<=":o=i.value;break;case"<":o=i.value,c=!1;break;case"!=":case"not-in":o=zt}Yu({value:r,inclusive:s},{value:o,inclusive:c})>0&&(r=o,s=c)}if(t!==null){for(let i=0;i<n.orderBy.length;++i)if(n.orderBy[i].field.isEqual(e)){const o=t.position[i];Yu({value:r,inclusive:s},{value:o,inclusive:t.inclusive})>0&&(r=o,s=t.inclusive);break}}return{value:r,inclusive:s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _o{constructor(e,t=null,r=[],s=[],i=null,o="F",c=null,l=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=r,this.filters=s,this.limit=i,this.limitType=o,this.startAt=c,this.endAt=l,this.ce=null,this.le=null,this.he=null,this.startAt,this.endAt}}function Vf(n,e,t,r,s,i,o,c){return new _o(n,e,t,r,s,i,o,c)}function yo(n){return new _o(n)}function nh(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function XI(n){return n.collectionGroup!==null}function ps(n){const e=B(n);if(e.ce===null){e.ce=[];const t=new Set;for(const i of e.explicitOrderBy)e.ce.push(i),t.add(i.field.canonicalString());const r=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let c=new le(fe.comparator);return o.filters.forEach(l=>{l.getFlattenedFilters().forEach(h=>{h.isInequality()&&(c=c.add(h.field))})}),c})(e).forEach(i=>{t.has(i.canonicalString())||i.isKeyField()||e.ce.push(new ji(i,r))}),t.has(fe.keyField().canonicalString())||e.ce.push(new ji(fe.keyField(),r))}return e.ce}function et(n){const e=B(n);return e.le||(e.le=ZI(e,ps(n))),e.le}function ZI(n,e){if(n.limitType==="F")return qa(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(s=>{const i=s.dir==="desc"?"asc":"desc";return new ji(s.field,i)});const t=n.endAt?new pr(n.endAt.position,n.endAt.inclusive):null,r=n.startAt?new pr(n.startAt.position,n.startAt.inclusive):null;return qa(n.path,n.collectionGroup,e,n.filters,n.limit,t,r)}}function ja(n,e,t){return new _o(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function vo(n,e){return Us(et(n),et(e))&&n.limitType===e.limitType}function Nf(n){return`${xn(et(n))}|lt:${n.limitType}`}function er(n){return`Query(target=${function(t){let r=t.path.canonicalString();return t.collectionGroup!==null&&(r+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(r+=`, filters: [${t.filters.map(s=>Cf(s)).join(", ")}]`),go(t.limit)||(r+=", limit: "+t.limit),t.orderBy.length>0&&(r+=`, orderBy: [${t.orderBy.map(s=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(s)).join(", ")}]`),t.startAt&&(r+=", startAt: ",r+=t.startAt.inclusive?"b:":"a:",r+=t.startAt.position.map(s=>fr(s)).join(",")),t.endAt&&(r+=", endAt: ",r+=t.endAt.inclusive?"a:":"b:",r+=t.endAt.position.map(s=>fr(s)).join(",")),`Target(${r})`}(et(n))}; limitType=${n.limitType})`}function Bs(n,e){return e.isFoundDocument()&&function(r,s){const i=s.key.path;return r.collectionGroup!==null?s.key.hasCollectionId(r.collectionGroup)&&r.path.isPrefixOf(i):F.isDocumentKey(r.path)?r.path.isEqual(i):r.path.isImmediateParentOf(i)}(n,e)&&function(r,s){for(const i of ps(r))if(!i.field.isKeyField()&&s.data.field(i.field)===null)return!1;return!0}(n,e)&&function(r,s){for(const i of r.filters)if(!i.matches(s))return!1;return!0}(n,e)&&function(r,s){return!(r.startAt&&!function(o,c,l){const h=Xu(o,c,l);return o.inclusive?h<=0:h<0}(r.startAt,ps(r),s)||r.endAt&&!function(o,c,l){const h=Xu(o,c,l);return o.inclusive?h>=0:h>0}(r.endAt,ps(r),s))}(n,e)}function xf(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function Of(n){return(e,t)=>{let r=!1;for(const s of ps(n)){const i=eE(s,e,t);if(i!==0)return i;r=r||s.field.isKeyField()}return 0}}function eE(n,e,t){const r=n.field.isKeyField()?F.comparator(e.key,t.key):function(i,o,c){const l=o.data.field(i),h=c.data.field(i);return l!==null&&h!==null?nn(l,h):U()}(n.field,e,t);switch(n.dir){case"asc":return r;case"desc":return-1*r;default:return U()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r!==void 0){for(const[s,i]of r)if(this.equalsFn(s,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const r=this.mapKeyFn(e),s=this.inner[r];if(s===void 0)return this.inner[r]=[[e,t]],void this.innerSize++;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],e))return void(s[i]=[e,t]);s.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r===void 0)return!1;for(let s=0;s<r.length;s++)if(this.equalsFn(r[s][0],e))return r.length===1?delete this.inner[t]:r.splice(s,1),this.innerSize--,!0;return!1}forEach(e){qn(this.inner,(t,r)=>{for(const[s,i]of r)e(s,i)})}isEmpty(){return Ef(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tE=new he(F.comparator);function Xe(){return tE}const Mf=new he(F.comparator);function as(...n){let e=Mf;for(const t of n)e=e.insert(t.key,t);return e}function Lf(n){let e=Mf;return n.forEach((t,r)=>e=e.insert(t,r.overlayedDocument)),e}function ft(){return ms()}function Ff(){return ms()}function ms(){return new ln(n=>n.toString(),(n,e)=>n.isEqual(e))}const nE=new he(F.comparator),rE=new le(F.comparator);function ee(...n){let e=rE;for(const t of n)e=e.add(t);return e}const sE=new le(Y);function Ac(){return sE}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $f(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Ss(e)?"-0":e}}function Uf(n){return{integerValue:""+n}}function iE(n,e){return mf(e)?Uf(e):$f(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Io{constructor(){this._=void 0}}function oE(n,e,t){return n instanceof ks?function(s,i){const o={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:s.seconds,nanos:s.nanoseconds}}}};return i&&Ec(i)&&(i=wc(i)),i&&(o.fields.__previous_value__=i),{mapValue:o}}(t,e):n instanceof gr?qf(n,e):n instanceof _r?jf(n,e):function(s,i){const o=Bf(s,i),c=rh(o)+rh(s.Pe);return $a(o)&&$a(s.Pe)?Uf(c):$f(s.serializer,c)}(n,e)}function aE(n,e,t){return n instanceof gr?qf(n,e):n instanceof _r?jf(n,e):t}function Bf(n,e){return n instanceof Ds?function(r){return $a(r)||function(i){return!!i&&"doubleValue"in i}(r)}(e)?e:{integerValue:0}:null}class ks extends Io{}class gr extends Io{constructor(e){super(),this.elements=e}}function qf(n,e){const t=Gf(e);for(const r of n.elements)t.some(s=>yt(s,r))||t.push(r);return{arrayValue:{values:t}}}class _r extends Io{constructor(e){super(),this.elements=e}}function jf(n,e){let t=Gf(e);for(const r of n.elements)t=t.filter(s=>!yt(s,r));return{arrayValue:{values:t}}}class Ds extends Io{constructor(e,t){super(),this.serializer=e,this.Pe=t}}function rh(n){return ge(n.integerValue||n.doubleValue)}function Gf(n){return Cs(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cE{constructor(e,t){this.field=e,this.transform=t}}function lE(n,e){return n.field.isEqual(e.field)&&function(r,s){return r instanceof gr&&s instanceof gr||r instanceof _r&&s instanceof _r?dr(r.elements,s.elements,yt):r instanceof Ds&&s instanceof Ds?yt(r.Pe,s.Pe):r instanceof ks&&s instanceof ks}(n.transform,e.transform)}class uE{constructor(e,t){this.version=e,this.transformResults=t}}class qe{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new qe}static exists(e){return new qe(void 0,e)}static updateTime(e){return new qe(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function Pi(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class Eo{}function zf(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new wo(n.key,qe.none()):new Nr(n.key,n.data,qe.none());{const t=n.data,r=Fe.empty();let s=new le(fe.comparator);for(let i of e.fields)if(!s.has(i)){let o=t.field(i);o===null&&i.length>1&&(i=i.popLast(),o=t.field(i)),o===null?r.delete(i):r.set(i,o),s=s.add(i)}return new Dt(n.key,r,new He(s.toArray()),qe.none())}}function hE(n,e,t){n instanceof Nr?function(s,i,o){const c=s.value.clone(),l=ih(s.fieldTransforms,i,o.transformResults);c.setAll(l),i.convertToFoundDocument(o.version,c).setHasCommittedMutations()}(n,e,t):n instanceof Dt?function(s,i,o){if(!Pi(s.precondition,i))return void i.convertToUnknownDocument(o.version);const c=ih(s.fieldTransforms,i,o.transformResults),l=i.data;l.setAll(Kf(s)),l.setAll(c),i.convertToFoundDocument(o.version,l).setHasCommittedMutations()}(n,e,t):function(s,i,o){i.convertToNoDocument(o.version).setHasCommittedMutations()}(0,e,t)}function gs(n,e,t,r){return n instanceof Nr?function(i,o,c,l){if(!Pi(i.precondition,o))return c;const h=i.value.clone(),f=oh(i.fieldTransforms,l,o);return h.setAll(f),o.convertToFoundDocument(o.version,h).setHasLocalMutations(),null}(n,e,t,r):n instanceof Dt?function(i,o,c,l){if(!Pi(i.precondition,o))return c;const h=oh(i.fieldTransforms,l,o),f=o.data;return f.setAll(Kf(i)),f.setAll(h),o.convertToFoundDocument(o.version,f).setHasLocalMutations(),c===null?null:c.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(m=>m.field))}(n,e,t,r):function(i,o,c){return Pi(i.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):c}(n,e,t)}function dE(n,e){let t=null;for(const r of n.fieldTransforms){const s=e.data.field(r.field),i=Bf(r.transform,s||null);i!=null&&(t===null&&(t=Fe.empty()),t.set(r.field,i))}return t||null}function sh(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(r,s){return r===void 0&&s===void 0||!(!r||!s)&&dr(r,s,(i,o)=>lE(i,o))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Nr extends Eo{constructor(e,t,r,s=[]){super(),this.key=e,this.value=t,this.precondition=r,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class Dt extends Eo{constructor(e,t,r,s,i=[]){super(),this.key=e,this.data=t,this.fieldMask=r,this.precondition=s,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function Kf(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const r=n.data.field(t);e.set(t,r)}}),e}function ih(n,e,t){const r=new Map;j(n.length===t.length);for(let s=0;s<t.length;s++){const i=n[s],o=i.transform,c=e.data.field(i.field);r.set(i.field,aE(o,c,t[s]))}return r}function oh(n,e,t){const r=new Map;for(const s of n){const i=s.transform,o=t.data.field(s.field);r.set(s.field,oE(i,o,e))}return r}class wo extends Eo{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Wf extends Eo{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sc{constructor(e,t,r,s){this.batchId=e,this.localWriteTime=t,this.baseMutations=r,this.mutations=s}applyToRemoteDocument(e,t){const r=t.mutationResults;for(let s=0;s<this.mutations.length;s++){const i=this.mutations[s];i.key.isEqual(e.key)&&hE(i,e,r[s])}}applyToLocalView(e,t){for(const r of this.baseMutations)r.key.isEqual(e.key)&&(t=gs(r,e,t,this.localWriteTime));for(const r of this.mutations)r.key.isEqual(e.key)&&(t=gs(r,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const r=Ff();return this.mutations.forEach(s=>{const i=e.get(s.key),o=i.overlayedDocument;let c=this.applyToLocalView(o,i.mutatedFields);c=t.has(s.key)?null:c;const l=zf(o,c);l!==null&&r.set(s.key,l),o.isValidDocument()||o.convertToNoDocument(G.min())}),r}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),ee())}isEqual(e){return this.batchId===e.batchId&&dr(this.mutations,e.mutations,(t,r)=>sh(t,r))&&dr(this.baseMutations,e.baseMutations,(t,r)=>sh(t,r))}}class Rc{constructor(e,t,r,s){this.batch=e,this.commitVersion=t,this.mutationResults=r,this.docVersions=s}static from(e,t,r){j(e.mutations.length===r.length);let s=function(){return nE}();const i=e.mutations;for(let o=0;o<i.length;o++)s=s.insert(i[o].key,r[o].version);return new Rc(e,t,r,s)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pc{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fE{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ie,se;function pE(n){switch(n){default:return U();case C.CANCELLED:case C.UNKNOWN:case C.DEADLINE_EXCEEDED:case C.RESOURCE_EXHAUSTED:case C.INTERNAL:case C.UNAVAILABLE:case C.UNAUTHENTICATED:return!1;case C.INVALID_ARGUMENT:case C.NOT_FOUND:case C.ALREADY_EXISTS:case C.PERMISSION_DENIED:case C.FAILED_PRECONDITION:case C.ABORTED:case C.OUT_OF_RANGE:case C.UNIMPLEMENTED:case C.DATA_LOSS:return!0}}function Hf(n){if(n===void 0)return ve("GRPC error has no .code"),C.UNKNOWN;switch(n){case Ie.OK:return C.OK;case Ie.CANCELLED:return C.CANCELLED;case Ie.UNKNOWN:return C.UNKNOWN;case Ie.DEADLINE_EXCEEDED:return C.DEADLINE_EXCEEDED;case Ie.RESOURCE_EXHAUSTED:return C.RESOURCE_EXHAUSTED;case Ie.INTERNAL:return C.INTERNAL;case Ie.UNAVAILABLE:return C.UNAVAILABLE;case Ie.UNAUTHENTICATED:return C.UNAUTHENTICATED;case Ie.INVALID_ARGUMENT:return C.INVALID_ARGUMENT;case Ie.NOT_FOUND:return C.NOT_FOUND;case Ie.ALREADY_EXISTS:return C.ALREADY_EXISTS;case Ie.PERMISSION_DENIED:return C.PERMISSION_DENIED;case Ie.FAILED_PRECONDITION:return C.FAILED_PRECONDITION;case Ie.ABORTED:return C.ABORTED;case Ie.OUT_OF_RANGE:return C.OUT_OF_RANGE;case Ie.UNIMPLEMENTED:return C.UNIMPLEMENTED;case Ie.DATA_LOSS:return C.DATA_LOSS;default:return U()}}(se=Ie||(Ie={}))[se.OK=0]="OK",se[se.CANCELLED=1]="CANCELLED",se[se.UNKNOWN=2]="UNKNOWN",se[se.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",se[se.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",se[se.NOT_FOUND=5]="NOT_FOUND",se[se.ALREADY_EXISTS=6]="ALREADY_EXISTS",se[se.PERMISSION_DENIED=7]="PERMISSION_DENIED",se[se.UNAUTHENTICATED=16]="UNAUTHENTICATED",se[se.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",se[se.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",se[se.ABORTED=10]="ABORTED",se[se.OUT_OF_RANGE=11]="OUT_OF_RANGE",se[se.UNIMPLEMENTED=12]="UNIMPLEMENTED",se[se.INTERNAL=13]="INTERNAL",se[se.UNAVAILABLE=14]="UNAVAILABLE",se[se.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mE(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gE=new An([4294967295,4294967295],0);function ah(n){const e=mE().encode(n),t=new ef;return t.update(e),new Uint8Array(t.digest())}function ch(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),r=e.getUint32(4,!0),s=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new An([t,r],0),new An([s,i],0)]}class Cc{constructor(e,t,r){if(this.bitmap=e,this.padding=t,this.hashCount=r,t<0||t>=8)throw new cs(`Invalid padding: ${t}`);if(r<0)throw new cs(`Invalid hash count: ${r}`);if(e.length>0&&this.hashCount===0)throw new cs(`Invalid hash count: ${r}`);if(e.length===0&&t!==0)throw new cs(`Invalid padding when bitmap length is 0: ${t}`);this.Ie=8*e.length-t,this.Te=An.fromNumber(this.Ie)}Ee(e,t,r){let s=e.add(t.multiply(An.fromNumber(r)));return s.compare(gE)===1&&(s=new An([s.getBits(0),s.getBits(1)],0)),s.modulo(this.Te).toNumber()}de(e){return(this.bitmap[Math.floor(e/8)]&1<<e%8)!=0}mightContain(e){if(this.Ie===0)return!1;const t=ah(e),[r,s]=ch(t);for(let i=0;i<this.hashCount;i++){const o=this.Ee(r,s,i);if(!this.de(o))return!1}return!0}static create(e,t,r){const s=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new Cc(i,s,t);return r.forEach(c=>o.insert(c)),o}insert(e){if(this.Ie===0)return;const t=ah(e),[r,s]=ch(t);for(let i=0;i<this.hashCount;i++){const o=this.Ee(r,s,i);this.Ae(o)}}Ae(e){const t=Math.floor(e/8),r=e%8;this.bitmap[t]|=1<<r}}class cs extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qs{constructor(e,t,r,s,i){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=r,this.documentUpdates=s,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(e,t,r){const s=new Map;return s.set(e,js.createSynthesizedTargetChangeForCurrentChange(e,t,r)),new qs(G.min(),s,new he(Y),Xe(),ee())}}class js{constructor(e,t,r,s,i){this.resumeToken=e,this.current=t,this.addedDocuments=r,this.modifiedDocuments=s,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,r){return new js(r,t,ee(),ee(),ee())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ci{constructor(e,t,r,s){this.Re=e,this.removedTargetIds=t,this.key=r,this.Ve=s}}class Qf{constructor(e,t){this.targetId=e,this.me=t}}class Jf{constructor(e,t,r=Pe.EMPTY_BYTE_STRING,s=null){this.state=e,this.targetIds=t,this.resumeToken=r,this.cause=s}}class lh{constructor(){this.fe=0,this.ge=hh(),this.pe=Pe.EMPTY_BYTE_STRING,this.ye=!1,this.we=!0}get current(){return this.ye}get resumeToken(){return this.pe}get Se(){return this.fe!==0}get be(){return this.we}De(e){e.approximateByteSize()>0&&(this.we=!0,this.pe=e)}Ce(){let e=ee(),t=ee(),r=ee();return this.ge.forEach((s,i)=>{switch(i){case 0:e=e.add(s);break;case 2:t=t.add(s);break;case 1:r=r.add(s);break;default:U()}}),new js(this.pe,this.ye,e,t,r)}ve(){this.we=!1,this.ge=hh()}Fe(e,t){this.we=!0,this.ge=this.ge.insert(e,t)}Me(e){this.we=!0,this.ge=this.ge.remove(e)}xe(){this.fe+=1}Oe(){this.fe-=1,j(this.fe>=0)}Ne(){this.we=!0,this.ye=!0}}class _E{constructor(e){this.Le=e,this.Be=new Map,this.ke=Xe(),this.qe=uh(),this.Qe=new he(Y)}Ke(e){for(const t of e.Re)e.Ve&&e.Ve.isFoundDocument()?this.$e(t,e.Ve):this.Ue(t,e.key,e.Ve);for(const t of e.removedTargetIds)this.Ue(t,e.key,e.Ve)}We(e){this.forEachTarget(e,t=>{const r=this.Ge(t);switch(e.state){case 0:this.ze(t)&&r.De(e.resumeToken);break;case 1:r.Oe(),r.Se||r.ve(),r.De(e.resumeToken);break;case 2:r.Oe(),r.Se||this.removeTarget(t);break;case 3:this.ze(t)&&(r.Ne(),r.De(e.resumeToken));break;case 4:this.ze(t)&&(this.je(t),r.De(e.resumeToken));break;default:U()}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.Be.forEach((r,s)=>{this.ze(s)&&t(s)})}He(e){const t=e.targetId,r=e.me.count,s=this.Je(t);if(s){const i=s.target;if(Gi(i))if(r===0){const o=new F(i.path);this.Ue(t,o,_e.newNoDocument(o,G.min()))}else j(r===1);else{const o=this.Ye(t);if(o!==r){const c=this.Ze(e),l=c?this.Xe(c,e,o):1;if(l!==0){this.je(t);const h=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Qe=this.Qe.insert(t,h)}}}}}Ze(e){const t=e.me.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:r="",padding:s=0},hashCount:i=0}=t;let o,c;try{o=tn(r).toUint8Array()}catch(l){if(l instanceof wf)return Ts("Decoding the base64 bloom filter in existence filter failed ("+l.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw l}try{c=new Cc(o,s,i)}catch(l){return Ts(l instanceof cs?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return c.Ie===0?null:c}Xe(e,t,r){return t.me.count===r-this.nt(e,t.targetId)?0:2}nt(e,t){const r=this.Le.getRemoteKeysForTarget(t);let s=0;return r.forEach(i=>{const o=this.Le.tt(),c=`projects/${o.projectId}/databases/${o.database}/documents/${i.path.canonicalString()}`;e.mightContain(c)||(this.Ue(t,i,null),s++)}),s}rt(e){const t=new Map;this.Be.forEach((i,o)=>{const c=this.Je(o);if(c){if(i.current&&Gi(c.target)){const l=new F(c.target.path);this.ke.get(l)!==null||this.it(o,l)||this.Ue(o,l,_e.newNoDocument(l,e))}i.be&&(t.set(o,i.Ce()),i.ve())}});let r=ee();this.qe.forEach((i,o)=>{let c=!0;o.forEachWhile(l=>{const h=this.Je(l);return!h||h.purpose==="TargetPurposeLimboResolution"||(c=!1,!1)}),c&&(r=r.add(i))}),this.ke.forEach((i,o)=>o.setReadTime(e));const s=new qs(e,t,this.Qe,this.ke,r);return this.ke=Xe(),this.qe=uh(),this.Qe=new he(Y),s}$e(e,t){if(!this.ze(e))return;const r=this.it(e,t.key)?2:0;this.Ge(e).Fe(t.key,r),this.ke=this.ke.insert(t.key,t),this.qe=this.qe.insert(t.key,this.st(t.key).add(e))}Ue(e,t,r){if(!this.ze(e))return;const s=this.Ge(e);this.it(e,t)?s.Fe(t,1):s.Me(t),this.qe=this.qe.insert(t,this.st(t).delete(e)),r&&(this.ke=this.ke.insert(t,r))}removeTarget(e){this.Be.delete(e)}Ye(e){const t=this.Ge(e).Ce();return this.Le.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}xe(e){this.Ge(e).xe()}Ge(e){let t=this.Be.get(e);return t||(t=new lh,this.Be.set(e,t)),t}st(e){let t=this.qe.get(e);return t||(t=new le(Y),this.qe=this.qe.insert(e,t)),t}ze(e){const t=this.Je(e)!==null;return t||k("WatchChangeAggregator","Detected inactive target",e),t}Je(e){const t=this.Be.get(e);return t&&t.Se?null:this.Le.ot(e)}je(e){this.Be.set(e,new lh),this.Le.getRemoteKeysForTarget(e).forEach(t=>{this.Ue(e,t,null)})}it(e,t){return this.Le.getRemoteKeysForTarget(e).has(t)}}function uh(){return new he(F.comparator)}function hh(){return new he(F.comparator)}const yE={asc:"ASCENDING",desc:"DESCENDING"},vE={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},IE={and:"AND",or:"OR"};class EE{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function Ga(n,e){return n.useProto3Json||go(e)?e:{value:e}}function yr(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Yf(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function wE(n,e){return yr(n,e.toTimestamp())}function Ge(n){return j(!!n),G.fromTimestamp(function(t){const r=Ct(t);return new pe(r.seconds,r.nanos)}(n))}function kc(n,e){return za(n,e).canonicalString()}function za(n,e){const t=function(s){return new ae(["projects",s.projectId,"databases",s.database])}(n).child("documents");return e===void 0?t:t.child(e)}function Xf(n){const e=ae.fromString(n);return j(ap(e)),e}function Ki(n,e){return kc(n.databaseId,e.path)}function Sn(n,e){const t=Xf(e);if(t.get(1)!==n.databaseId.projectId)throw new $(C.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new $(C.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new F(tp(t))}function Zf(n,e){return kc(n.databaseId,e)}function ep(n){const e=Xf(n);return e.length===4?ae.emptyPath():tp(e)}function Ka(n){return new ae(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function tp(n){return j(n.length>4&&n.get(4)==="documents"),n.popFirst(5)}function dh(n,e,t){return{name:Ki(n,e),fields:t.value.mapValue.fields}}function TE(n,e,t){const r=Sn(n,e.name),s=Ge(e.updateTime),i=e.createTime?Ge(e.createTime):G.min(),o=new Fe({mapValue:{fields:e.fields}}),c=_e.newFoundDocument(r,s,i,o);return t&&c.setHasCommittedMutations(),t?c.setHasCommittedMutations():c}function bE(n,e){let t;if("targetChange"in e){e.targetChange;const r=function(h){return h==="NO_CHANGE"?0:h==="ADD"?1:h==="REMOVE"?2:h==="CURRENT"?3:h==="RESET"?4:U()}(e.targetChange.targetChangeType||"NO_CHANGE"),s=e.targetChange.targetIds||[],i=function(h,f){return h.useProto3Json?(j(f===void 0||typeof f=="string"),Pe.fromBase64String(f||"")):(j(f===void 0||f instanceof Buffer||f instanceof Uint8Array),Pe.fromUint8Array(f||new Uint8Array))}(n,e.targetChange.resumeToken),o=e.targetChange.cause,c=o&&function(h){const f=h.code===void 0?C.UNKNOWN:Hf(h.code);return new $(f,h.message||"")}(o);t=new Jf(r,s,i,c||null)}else if("documentChange"in e){e.documentChange;const r=e.documentChange;r.document,r.document.name,r.document.updateTime;const s=Sn(n,r.document.name),i=Ge(r.document.updateTime),o=r.document.createTime?Ge(r.document.createTime):G.min(),c=new Fe({mapValue:{fields:r.document.fields}}),l=_e.newFoundDocument(s,i,o,c),h=r.targetIds||[],f=r.removedTargetIds||[];t=new Ci(h,f,l.key,l)}else if("documentDelete"in e){e.documentDelete;const r=e.documentDelete;r.document;const s=Sn(n,r.document),i=r.readTime?Ge(r.readTime):G.min(),o=_e.newNoDocument(s,i),c=r.removedTargetIds||[];t=new Ci([],c,o.key,o)}else if("documentRemove"in e){e.documentRemove;const r=e.documentRemove;r.document;const s=Sn(n,r.document),i=r.removedTargetIds||[];t=new Ci([],i,s,null)}else{if(!("filter"in e))return U();{e.filter;const r=e.filter;r.targetId;const{count:s=0,unchangedNames:i}=r,o=new fE(s,i),c=r.targetId;t=new Qf(c,o)}}return t}function Wi(n,e){let t;if(e instanceof Nr)t={update:dh(n,e.key,e.value)};else if(e instanceof wo)t={delete:Ki(n,e.key)};else if(e instanceof Dt)t={update:dh(n,e.key,e.data),updateMask:kE(e.fieldMask)};else{if(!(e instanceof Wf))return U();t={verify:Ki(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(r=>function(i,o){const c=o.transform;if(c instanceof ks)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(c instanceof gr)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:c.elements}};if(c instanceof _r)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:c.elements}};if(c instanceof Ds)return{fieldPath:o.field.canonicalString(),increment:c.Pe};throw U()}(0,r))),e.precondition.isNone||(t.currentDocument=function(s,i){return i.updateTime!==void 0?{updateTime:wE(s,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:U()}(n,e.precondition)),t}function Wa(n,e){const t=e.currentDocument?function(i){return i.updateTime!==void 0?qe.updateTime(Ge(i.updateTime)):i.exists!==void 0?qe.exists(i.exists):qe.none()}(e.currentDocument):qe.none(),r=e.updateTransforms?e.updateTransforms.map(s=>function(o,c){let l=null;if("setToServerValue"in c)j(c.setToServerValue==="REQUEST_TIME"),l=new ks;else if("appendMissingElements"in c){const f=c.appendMissingElements.values||[];l=new gr(f)}else if("removeAllFromArray"in c){const f=c.removeAllFromArray.values||[];l=new _r(f)}else"increment"in c?l=new Ds(o,c.increment):U();const h=fe.fromServerFormat(c.fieldPath);return new cE(h,l)}(n,s)):[];if(e.update){e.update.name;const s=Sn(n,e.update.name),i=new Fe({mapValue:{fields:e.update.fields}});if(e.updateMask){const o=function(l){const h=l.fieldPaths||[];return new He(h.map(f=>fe.fromServerFormat(f)))}(e.updateMask);return new Dt(s,i,o,t,r)}return new Nr(s,i,t,r)}if(e.delete){const s=Sn(n,e.delete);return new wo(s,t)}if(e.verify){const s=Sn(n,e.verify);return new Wf(s,t)}return U()}function AE(n,e){return n&&n.length>0?(j(e!==void 0),n.map(t=>function(s,i){let o=s.updateTime?Ge(s.updateTime):Ge(i);return o.isEqual(G.min())&&(o=Ge(i)),new uE(o,s.transformResults||[])}(t,e))):[]}function np(n,e){return{documents:[Zf(n,e.path)]}}function rp(n,e){const t={structuredQuery:{}},r=e.path;let s;e.collectionGroup!==null?(s=r,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(s=r.popLast(),t.structuredQuery.from=[{collectionId:r.lastSegment()}]),t.parent=Zf(n,s);const i=function(h){if(h.length!==0)return op(ce.create(h,"and"))}(e.filters);i&&(t.structuredQuery.where=i);const o=function(h){if(h.length!==0)return h.map(f=>function(I){return{field:tr(I.field),direction:RE(I.dir)}}(f))}(e.orderBy);o&&(t.structuredQuery.orderBy=o);const c=Ga(n,e.limit);return c!==null&&(t.structuredQuery.limit=c),e.startAt&&(t.structuredQuery.startAt=function(h){return{before:h.inclusive,values:h.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(h){return{before:!h.inclusive,values:h.position}}(e.endAt)),{_t:t,parent:s}}function sp(n){let e=ep(n.parent);const t=n.structuredQuery,r=t.from?t.from.length:0;let s=null;if(r>0){j(r===1);const f=t.from[0];f.allDescendants?s=f.collectionId:e=e.child(f.collectionId)}let i=[];t.where&&(i=function(m){const I=ip(m);return I instanceof ce&&bc(I)?I.getFilters():[I]}(t.where));let o=[];t.orderBy&&(o=function(m){return m.map(I=>function(D){return new ji(nr(D.field),function(P){switch(P){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(D.direction))}(I))}(t.orderBy));let c=null;t.limit&&(c=function(m){let I;return I=typeof m=="object"?m.value:m,go(I)?null:I}(t.limit));let l=null;t.startAt&&(l=function(m){const I=!!m.before,S=m.values||[];return new pr(S,I)}(t.startAt));let h=null;return t.endAt&&(h=function(m){const I=!m.before,S=m.values||[];return new pr(S,I)}(t.endAt)),Vf(e,s,o,i,c,"F",l,h)}function SE(n,e){const t=function(s){switch(s){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return U()}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function ip(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const r=nr(t.unaryFilter.field);return re.create(r,"==",{doubleValue:NaN});case"IS_NULL":const s=nr(t.unaryFilter.field);return re.create(s,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=nr(t.unaryFilter.field);return re.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=nr(t.unaryFilter.field);return re.create(o,"!=",{nullValue:"NULL_VALUE"});default:return U()}}(n):n.fieldFilter!==void 0?function(t){return re.create(nr(t.fieldFilter.field),function(s){switch(s){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return U()}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return ce.create(t.compositeFilter.filters.map(r=>ip(r)),function(s){switch(s){case"AND":return"and";case"OR":return"or";default:return U()}}(t.compositeFilter.op))}(n):U()}function RE(n){return yE[n]}function PE(n){return vE[n]}function CE(n){return IE[n]}function tr(n){return{fieldPath:n.canonicalString()}}function nr(n){return fe.fromServerFormat(n.fieldPath)}function op(n){return n instanceof re?function(t){if(t.op==="=="){if(Qu(t.value))return{unaryFilter:{field:tr(t.field),op:"IS_NAN"}};if(Hu(t.value))return{unaryFilter:{field:tr(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(Qu(t.value))return{unaryFilter:{field:tr(t.field),op:"IS_NOT_NAN"}};if(Hu(t.value))return{unaryFilter:{field:tr(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:tr(t.field),op:PE(t.op),value:t.value}}}(n):n instanceof ce?function(t){const r=t.getFilters().map(s=>op(s));return r.length===1?r[0]:{compositeFilter:{op:CE(t.op),filters:r}}}(n):U()}function kE(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function ap(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rt{constructor(e,t,r,s,i=G.min(),o=G.min(),c=Pe.EMPTY_BYTE_STRING,l=null){this.target=e,this.targetId=t,this.purpose=r,this.sequenceNumber=s,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=c,this.expectedCount=l}withSequenceNumber(e){return new Rt(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new Rt(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new Rt(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new Rt(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cp{constructor(e){this.ct=e}}function DE(n,e){let t;if(e.document)t=TE(n.ct,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const r=F.fromSegments(e.noDocument.path),s=Mn(e.noDocument.readTime);t=_e.newNoDocument(r,s),e.hasCommittedMutations&&t.setHasCommittedMutations()}else{if(!e.unknownDocument)return U();{const r=F.fromSegments(e.unknownDocument.path),s=Mn(e.unknownDocument.version);t=_e.newUnknownDocument(r,s)}}return e.readTime&&t.setReadTime(function(s){const i=new pe(s[0],s[1]);return G.fromTimestamp(i)}(e.readTime)),t}function fh(n,e){const t=e.key,r={prefixPath:t.getCollectionPath().popLast().toArray(),collectionGroup:t.collectionGroup,documentId:t.path.lastSegment(),readTime:Hi(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())r.document=function(i,o){return{name:Ki(i,o.key),fields:o.data.value.mapValue.fields,updateTime:yr(i,o.version.toTimestamp()),createTime:yr(i,o.createTime.toTimestamp())}}(n.ct,e);else if(e.isNoDocument())r.noDocument={path:t.path.toArray(),readTime:On(e.version)};else{if(!e.isUnknownDocument())return U();r.unknownDocument={path:t.path.toArray(),version:On(e.version)}}return r}function Hi(n){const e=n.toTimestamp();return[e.seconds,e.nanoseconds]}function On(n){const e=n.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function Mn(n){const e=new pe(n.seconds,n.nanoseconds);return G.fromTimestamp(e)}function In(n,e){const t=(e.baseMutations||[]).map(i=>Wa(n.ct,i));for(let i=0;i<e.mutations.length-1;++i){const o=e.mutations[i];if(i+1<e.mutations.length&&e.mutations[i+1].transform!==void 0){const c=e.mutations[i+1];o.updateTransforms=c.transform.fieldTransforms,e.mutations.splice(i+1,1),++i}}const r=e.mutations.map(i=>Wa(n.ct,i)),s=pe.fromMillis(e.localWriteTimeMs);return new Sc(e.batchId,s,t,r)}function ls(n){const e=Mn(n.readTime),t=n.lastLimboFreeSnapshotVersion!==void 0?Mn(n.lastLimboFreeSnapshotVersion):G.min();let r;return r=function(i){return i.documents!==void 0}(n.query)?function(i){return j(i.documents.length===1),et(yo(ep(i.documents[0])))}(n.query):function(i){return et(sp(i))}(n.query),new Rt(r,n.targetId,"TargetPurposeListen",n.lastListenSequenceNumber,e,t,Pe.fromBase64String(n.resumeToken))}function lp(n,e){const t=On(e.snapshotVersion),r=On(e.lastLimboFreeSnapshotVersion);let s;s=Gi(e.target)?np(n.ct,e.target):rp(n.ct,e.target)._t;const i=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:xn(e.target),readTime:t,resumeToken:i,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:r,query:s}}function up(n){const e=sp({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?ja(e,e.limit,"L"):e}function _a(n,e){return new Pc(e.largestBatchId,Wa(n.ct,e.overlayMutation))}function ph(n,e){const t=e.path.lastSegment();return[n,je(e.path.popLast()),t]}function mh(n,e,t,r){return{indexId:n,uid:e,sequenceNumber:t,readTime:On(r.readTime),documentKey:je(r.documentKey.path),largestBatchId:r.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VE{getBundleMetadata(e,t){return gh(e).get(t).next(r=>{if(r)return function(i){return{id:i.bundleId,createTime:Mn(i.createTime),version:i.version}}(r)})}saveBundleMetadata(e,t){return gh(e).put(function(s){return{bundleId:s.id,createTime:On(Ge(s.createTime)),version:s.version}}(t))}getNamedQuery(e,t){return _h(e).get(t).next(r=>{if(r)return function(i){return{name:i.name,query:up(i.bundledQuery),readTime:Mn(i.readTime)}}(r)})}saveNamedQuery(e,t){return _h(e).put(function(s){return{name:s.name,readTime:On(Ge(s.readTime)),bundledQuery:s.bundledQuery}}(t))}}function gh(n){return Ce(n,"bundles")}function _h(n){return Ce(n,"namedQueries")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class To{constructor(e,t){this.serializer=e,this.userId=t}static lt(e,t){const r=t.uid||"";return new To(e,r)}getOverlay(e,t){return Zr(e).get(ph(this.userId,t)).next(r=>r?_a(this.serializer,r):null)}getOverlays(e,t){const r=ft();return A.forEach(t,s=>this.getOverlay(e,s).next(i=>{i!==null&&r.set(s,i)})).next(()=>r)}saveOverlays(e,t,r){const s=[];return r.forEach((i,o)=>{const c=new Pc(t,o);s.push(this.ht(e,c))}),A.waitFor(s)}removeOverlaysForBatchId(e,t,r){const s=new Set;t.forEach(o=>s.add(je(o.getCollectionPath())));const i=[];return s.forEach(o=>{const c=IDBKeyRange.bound([this.userId,o,r],[this.userId,o,r+1],!1,!0);i.push(Zr(e).j("collectionPathOverlayIndex",c))}),A.waitFor(i)}getOverlaysForCollection(e,t,r){const s=ft(),i=je(t),o=IDBKeyRange.bound([this.userId,i,r],[this.userId,i,Number.POSITIVE_INFINITY],!0);return Zr(e).U("collectionPathOverlayIndex",o).next(c=>{for(const l of c){const h=_a(this.serializer,l);s.set(h.getKey(),h)}return s})}getOverlaysForCollectionGroup(e,t,r,s){const i=ft();let o;const c=IDBKeyRange.bound([this.userId,t,r],[this.userId,t,Number.POSITIVE_INFINITY],!0);return Zr(e).J({index:"collectionGroupOverlayIndex",range:c},(l,h,f)=>{const m=_a(this.serializer,h);i.size()<s||m.largestBatchId===o?(i.set(m.getKey(),m),o=m.largestBatchId):f.done()}).next(()=>i)}ht(e,t){return Zr(e).put(function(s,i,o){const[c,l,h]=ph(i,o.mutation.key);return{userId:i,collectionPath:l,documentId:h,collectionGroup:o.mutation.key.getCollectionGroup(),largestBatchId:o.largestBatchId,overlayMutation:Wi(s.ct,o.mutation)}}(this.serializer,this.userId,t))}}function Zr(n){return Ce(n,"documentOverlays")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class En{constructor(){}Pt(e,t){this.It(e,t),t.Tt()}It(e,t){if("nullValue"in e)this.Et(t,5);else if("booleanValue"in e)this.Et(t,10),t.dt(e.booleanValue?1:0);else if("integerValue"in e)this.Et(t,15),t.dt(ge(e.integerValue));else if("doubleValue"in e){const r=ge(e.doubleValue);isNaN(r)?this.Et(t,13):(this.Et(t,15),Ss(r)?t.dt(0):t.dt(r))}else if("timestampValue"in e){let r=e.timestampValue;this.Et(t,20),typeof r=="string"&&(r=Ct(r)),t.At(`${r.seconds||""}`),t.dt(r.nanos||0)}else if("stringValue"in e)this.Rt(e.stringValue,t),this.Vt(t);else if("bytesValue"in e)this.Et(t,30),t.ft(tn(e.bytesValue)),this.Vt(t);else if("referenceValue"in e)this.gt(e.referenceValue,t);else if("geoPointValue"in e){const r=e.geoPointValue;this.Et(t,45),t.dt(r.latitude||0),t.dt(r.longitude||0)}else"mapValue"in e?Tf(e)?this.Et(t,Number.MAX_SAFE_INTEGER):(this.yt(e.mapValue,t),this.Vt(t)):"arrayValue"in e?(this.wt(e.arrayValue,t),this.Vt(t)):U()}Rt(e,t){this.Et(t,25),this.St(e,t)}St(e,t){t.At(e)}yt(e,t){const r=e.fields||{};this.Et(t,55);for(const s of Object.keys(r))this.Rt(s,t),this.It(r[s],t)}wt(e,t){const r=e.values||[];this.Et(t,50);for(const s of r)this.It(s,t)}gt(e,t){this.Et(t,37),F.fromName(e).path.forEach(r=>{this.Et(t,60),this.St(r,t)})}Et(e,t){e.dt(t)}Vt(e){e.dt(2)}}En.bt=new En;function NE(n){if(n===0)return 8;let e=0;return!(n>>4)&&(e+=4,n<<=4),!(n>>6)&&(e+=2,n<<=2),!(n>>7)&&(e+=1),e}function yh(n){const e=64-function(r){let s=0;for(let i=0;i<8;++i){const o=NE(255&r[i]);if(s+=o,o!==8)break}return s}(n);return Math.ceil(e/8)}class xE{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Dt(e){const t=e[Symbol.iterator]();let r=t.next();for(;!r.done;)this.Ct(r.value),r=t.next();this.vt()}Ft(e){const t=e[Symbol.iterator]();let r=t.next();for(;!r.done;)this.Mt(r.value),r=t.next();this.xt()}Ot(e){for(const t of e){const r=t.charCodeAt(0);if(r<128)this.Ct(r);else if(r<2048)this.Ct(960|r>>>6),this.Ct(128|63&r);else if(t<"\uD800"||"\uDBFF"<t)this.Ct(480|r>>>12),this.Ct(128|63&r>>>6),this.Ct(128|63&r);else{const s=t.codePointAt(0);this.Ct(240|s>>>18),this.Ct(128|63&s>>>12),this.Ct(128|63&s>>>6),this.Ct(128|63&s)}}this.vt()}Nt(e){for(const t of e){const r=t.charCodeAt(0);if(r<128)this.Mt(r);else if(r<2048)this.Mt(960|r>>>6),this.Mt(128|63&r);else if(t<"\uD800"||"\uDBFF"<t)this.Mt(480|r>>>12),this.Mt(128|63&r>>>6),this.Mt(128|63&r);else{const s=t.codePointAt(0);this.Mt(240|s>>>18),this.Mt(128|63&s>>>12),this.Mt(128|63&s>>>6),this.Mt(128|63&s)}}this.xt()}Lt(e){const t=this.Bt(e),r=yh(t);this.kt(1+r),this.buffer[this.position++]=255&r;for(let s=t.length-r;s<t.length;++s)this.buffer[this.position++]=255&t[s]}qt(e){const t=this.Bt(e),r=yh(t);this.kt(1+r),this.buffer[this.position++]=~(255&r);for(let s=t.length-r;s<t.length;++s)this.buffer[this.position++]=~(255&t[s])}Qt(){this.Kt(255),this.Kt(255)}$t(){this.Ut(255),this.Ut(255)}reset(){this.position=0}seed(e){this.kt(e.length),this.buffer.set(e,this.position),this.position+=e.length}Wt(){return this.buffer.slice(0,this.position)}Bt(e){const t=function(i){const o=new DataView(new ArrayBuffer(8));return o.setFloat64(0,i,!1),new Uint8Array(o.buffer)}(e),r=(128&t[0])!=0;t[0]^=r?255:128;for(let s=1;s<t.length;++s)t[s]^=r?255:0;return t}Ct(e){const t=255&e;t===0?(this.Kt(0),this.Kt(255)):t===255?(this.Kt(255),this.Kt(0)):this.Kt(t)}Mt(e){const t=255&e;t===0?(this.Ut(0),this.Ut(255)):t===255?(this.Ut(255),this.Ut(0)):this.Ut(e)}vt(){this.Kt(0),this.Kt(1)}xt(){this.Ut(0),this.Ut(1)}Kt(e){this.kt(1),this.buffer[this.position++]=e}Ut(e){this.kt(1),this.buffer[this.position++]=~e}kt(e){const t=e+this.position;if(t<=this.buffer.length)return;let r=2*this.buffer.length;r<t&&(r=t);const s=new Uint8Array(r);s.set(this.buffer),this.buffer=s}}class OE{constructor(e){this.Gt=e}ft(e){this.Gt.Dt(e)}At(e){this.Gt.Ot(e)}dt(e){this.Gt.Lt(e)}Tt(){this.Gt.Qt()}}class ME{constructor(e){this.Gt=e}ft(e){this.Gt.Ft(e)}At(e){this.Gt.Nt(e)}dt(e){this.Gt.qt(e)}Tt(){this.Gt.$t()}}class es{constructor(){this.Gt=new xE,this.zt=new OE(this.Gt),this.jt=new ME(this.Gt)}seed(e){this.Gt.seed(e)}Ht(e){return e===0?this.zt:this.jt}Wt(){return this.Gt.Wt()}reset(){this.Gt.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wn{constructor(e,t,r,s){this.indexId=e,this.documentKey=t,this.arrayValue=r,this.directionalValue=s}Jt(){const e=this.directionalValue.length,t=e===0||this.directionalValue[e-1]===255?e+1:e,r=new Uint8Array(t);return r.set(this.directionalValue,0),t!==e?r.set([0],this.directionalValue.length):++r[r.length-1],new wn(this.indexId,this.documentKey,this.arrayValue,r)}}function Lt(n,e){let t=n.indexId-e.indexId;return t!==0?t:(t=vh(n.arrayValue,e.arrayValue),t!==0?t:(t=vh(n.directionalValue,e.directionalValue),t!==0?t:F.comparator(n.documentKey,e.documentKey)))}function vh(n,e){for(let t=0;t<n.length&&t<e.length;++t){const r=n[t]-e[t];if(r!==0)return r}return n.length-e.length}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ih{constructor(e){this.Yt=new le((t,r)=>fe.comparator(t.field,r.field)),this.collectionId=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment(),this.Zt=e.orderBy,this.Xt=[];for(const t of e.filters){const r=t;r.isInequality()?this.Yt=this.Yt.add(r):this.Xt.push(r)}}get en(){return this.Yt.size>1}tn(e){if(j(e.collectionGroup===this.collectionId),this.en)return!1;const t=Ma(e);if(t!==void 0&&!this.nn(t))return!1;const r=yn(e);let s=new Set,i=0,o=0;for(;i<r.length&&this.nn(r[i]);++i)s=s.add(r[i].fieldPath.canonicalString());if(i===r.length)return!0;if(this.Yt.size>0){const c=this.Yt.getIterator().getNext();if(!s.has(c.field.canonicalString())){const l=r[i];if(!this.rn(c,l)||!this.sn(this.Zt[o++],l))return!1}++i}for(;i<r.length;++i){const c=r[i];if(o>=this.Zt.length||!this.sn(this.Zt[o++],c))return!1}return!0}on(){if(this.en)return null;let e=new le(fe.comparator);const t=[];for(const r of this.Xt)if(!r.field.isKeyField())if(r.op==="array-contains"||r.op==="array-contains-any")t.push(new bi(r.field,2));else{if(e.has(r.field))continue;e=e.add(r.field),t.push(new bi(r.field,0))}for(const r of this.Zt)r.field.isKeyField()||e.has(r.field)||(e=e.add(r.field),t.push(new bi(r.field,r.dir==="asc"?0:1)));return new qi(qi.UNKNOWN_ID,this.collectionId,t,As.empty())}nn(e){for(const t of this.Xt)if(this.rn(t,e))return!0;return!1}rn(e,t){if(e===void 0||!e.field.isEqual(t.fieldPath))return!1;const r=e.op==="array-contains"||e.op==="array-contains-any";return t.kind===2===r}sn(e,t){return!!e.field.isEqual(t.fieldPath)&&(t.kind===0&&e.dir==="asc"||t.kind===1&&e.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hp(n){var e,t;if(j(n instanceof re||n instanceof ce),n instanceof re){if(n instanceof Df){const s=((t=(e=n.value.arrayValue)===null||e===void 0?void 0:e.values)===null||t===void 0?void 0:t.map(i=>re.create(n.field,"==",i)))||[];return ce.create(s,"or")}return n}const r=n.filters.map(s=>hp(s));return ce.create(r,n.op)}function LE(n){if(n.getFilters().length===0)return[];const e=Ja(hp(n));return j(dp(e)),Ha(e)||Qa(e)?[e]:e.getFilters()}function Ha(n){return n instanceof re}function Qa(n){return n instanceof ce&&bc(n)}function dp(n){return Ha(n)||Qa(n)||function(t){if(t instanceof ce&&Ua(t)){for(const r of t.getFilters())if(!Ha(r)&&!Qa(r))return!1;return!0}return!1}(n)}function Ja(n){if(j(n instanceof re||n instanceof ce),n instanceof re)return n;if(n.filters.length===1)return Ja(n.filters[0]);const e=n.filters.map(r=>Ja(r));let t=ce.create(e,n.op);return t=Qi(t),dp(t)?t:(j(t instanceof ce),j(mr(t)),j(t.filters.length>1),t.filters.reduce((r,s)=>Dc(r,s)))}function Dc(n,e){let t;return j(n instanceof re||n instanceof ce),j(e instanceof re||e instanceof ce),t=n instanceof re?e instanceof re?function(s,i){return ce.create([s,i],"and")}(n,e):Eh(n,e):e instanceof re?Eh(e,n):function(s,i){if(j(s.filters.length>0&&i.filters.length>0),mr(s)&&mr(i))return Pf(s,i.getFilters());const o=Ua(s)?s:i,c=Ua(s)?i:s,l=o.filters.map(h=>Dc(h,c));return ce.create(l,"or")}(n,e),Qi(t)}function Eh(n,e){if(mr(e))return Pf(e,n.getFilters());{const t=e.filters.map(r=>Dc(n,r));return ce.create(t,"or")}}function Qi(n){if(j(n instanceof re||n instanceof ce),n instanceof re)return n;const e=n.getFilters();if(e.length===1)return Qi(e[0]);if(Sf(n))return n;const t=e.map(s=>Qi(s)),r=[];return t.forEach(s=>{s instanceof re?r.push(s):s instanceof ce&&(s.op===n.op?r.push(...s.filters):r.push(s))}),r.length===1?r[0]:ce.create(r,n.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class FE{constructor(){this._n=new Vc}addToCollectionParentIndex(e,t){return this._n.add(t),A.resolve()}getCollectionParents(e,t){return A.resolve(this._n.getEntries(t))}addFieldIndex(e,t){return A.resolve()}deleteFieldIndex(e,t){return A.resolve()}deleteAllFieldIndexes(e){return A.resolve()}createTargetIndexes(e,t){return A.resolve()}getDocumentsMatchingTarget(e,t){return A.resolve(null)}getIndexType(e,t){return A.resolve(0)}getFieldIndexes(e,t){return A.resolve([])}getNextCollectionGroupToUpdate(e){return A.resolve(null)}getMinOffset(e,t){return A.resolve(rt.min())}getMinOffsetFromCollectionGroup(e,t){return A.resolve(rt.min())}updateCollectionGroup(e,t,r){return A.resolve()}updateIndexEntries(e,t){return A.resolve()}}class Vc{constructor(){this.index={}}add(e){const t=e.lastSegment(),r=e.popLast(),s=this.index[t]||new le(ae.comparator),i=!s.has(r);return this.index[t]=s.add(r),i}has(e){const t=e.lastSegment(),r=e.popLast(),s=this.index[t];return s&&s.has(r)}getEntries(e){return(this.index[e]||new le(ae.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fi=new Uint8Array(0);class $E{constructor(e,t){this.databaseId=t,this.an=new Vc,this.un=new ln(r=>xn(r),(r,s)=>Us(r,s)),this.uid=e.uid||""}addToCollectionParentIndex(e,t){if(!this.an.has(t)){const r=t.lastSegment(),s=t.popLast();e.addOnCommittedListener(()=>{this.an.add(t)});const i={collectionId:r,parent:je(s)};return wh(e).put(i)}return A.resolve()}getCollectionParents(e,t){const r=[],s=IDBKeyRange.bound([t,""],[lf(t),""],!1,!0);return wh(e).U(s).next(i=>{for(const o of i){if(o.collectionId!==t)break;r.push(dt(o.parent))}return r})}addFieldIndex(e,t){const r=ts(e),s=function(c){return{indexId:c.indexId,collectionGroup:c.collectionGroup,fields:c.fields.map(l=>[l.fieldPath.canonicalString(),l.kind])}}(t);delete s.indexId;const i=r.add(s);if(t.indexState){const o=Jn(e);return i.next(c=>{o.put(mh(c,this.uid,t.indexState.sequenceNumber,t.indexState.offset))})}return i.next()}deleteFieldIndex(e,t){const r=ts(e),s=Jn(e),i=Qn(e);return r.delete(t.indexId).next(()=>s.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0))).next(()=>i.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0)))}deleteAllFieldIndexes(e){const t=ts(e),r=Qn(e),s=Jn(e);return t.j().next(()=>r.j()).next(()=>s.j())}createTargetIndexes(e,t){return A.forEach(this.cn(t),r=>this.getIndexType(e,r).next(s=>{if(s===0||s===1){const i=new Ih(r).on();if(i!=null)return this.addFieldIndex(e,i)}}))}getDocumentsMatchingTarget(e,t){const r=Qn(e);let s=!0;const i=new Map;return A.forEach(this.cn(t),o=>this.ln(e,o).next(c=>{s&&(s=!!c),i.set(o,c)})).next(()=>{if(s){let o=ee();const c=[];return A.forEach(i,(l,h)=>{k("IndexedDbIndexManager",`Using index ${function(q){return`id=${q.indexId}|cg=${q.collectionGroup}|f=${q.fields.map(X=>`${X.fieldPath}:${X.kind}`).join(",")}`}(l)} to execute ${xn(t)}`);const f=function(q,X){const V=Ma(X);if(V===void 0)return null;for(const M of zi(q,V.fieldPath))switch(M.op){case"array-contains-any":return M.value.arrayValue.values||[];case"array-contains":return[M.value]}return null}(h,l),m=function(q,X){const V=new Map;for(const M of yn(X))for(const v of zi(q,M.fieldPath))switch(v.op){case"==":case"in":V.set(M.fieldPath.canonicalString(),v.value);break;case"not-in":case"!=":return V.set(M.fieldPath.canonicalString(),v.value),Array.from(V.values())}return null}(h,l),I=function(q,X){const V=[];let M=!0;for(const v of yn(X)){const g=v.kind===0?eh(q,v.fieldPath,q.startAt):th(q,v.fieldPath,q.startAt);V.push(g.value),M&&(M=g.inclusive)}return new pr(V,M)}(h,l),S=function(q,X){const V=[];let M=!0;for(const v of yn(X)){const g=v.kind===0?th(q,v.fieldPath,q.endAt):eh(q,v.fieldPath,q.endAt);V.push(g.value),M&&(M=g.inclusive)}return new pr(V,M)}(h,l),D=this.hn(l,h,I),N=this.hn(l,h,S),P=this.Pn(l,h,m),H=this.In(l.indexId,f,D,I.inclusive,N,S.inclusive,P);return A.forEach(H,K=>r.G(K,t.limit).next(q=>{q.forEach(X=>{const V=F.fromSegments(X.documentKey);o.has(V)||(o=o.add(V),c.push(V))})}))}).next(()=>c)}return A.resolve(null)})}cn(e){let t=this.un.get(e);return t||(e.filters.length===0?t=[e]:t=LE(ce.create(e.filters,"and")).map(r=>qa(e.path,e.collectionGroup,e.orderBy,r.getFilters(),e.limit,e.startAt,e.endAt)),this.un.set(e,t),t)}In(e,t,r,s,i,o,c){const l=(t!=null?t.length:1)*Math.max(r.length,i.length),h=l/(t!=null?t.length:1),f=[];for(let m=0;m<l;++m){const I=t?this.Tn(t[m/h]):fi,S=this.En(e,I,r[m%h],s),D=this.dn(e,I,i[m%h],o),N=c.map(P=>this.En(e,I,P,!0));f.push(...this.createRange(S,D,N))}return f}En(e,t,r,s){const i=new wn(e,F.empty(),t,r);return s?i:i.Jt()}dn(e,t,r,s){const i=new wn(e,F.empty(),t,r);return s?i.Jt():i}ln(e,t){const r=new Ih(t),s=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment();return this.getFieldIndexes(e,s).next(i=>{let o=null;for(const c of i)r.tn(c)&&(!o||c.fields.length>o.fields.length)&&(o=c);return o})}getIndexType(e,t){let r=2;const s=this.cn(t);return A.forEach(s,i=>this.ln(e,i).next(o=>{o?r!==0&&o.fields.length<function(l){let h=new le(fe.comparator),f=!1;for(const m of l.filters)for(const I of m.getFlattenedFilters())I.field.isKeyField()||(I.op==="array-contains"||I.op==="array-contains-any"?f=!0:h=h.add(I.field));for(const m of l.orderBy)m.field.isKeyField()||(h=h.add(m.field));return h.size+(f?1:0)}(i)&&(r=1):r=0})).next(()=>function(o){return o.limit!==null}(t)&&s.length>1&&r===2?1:r)}An(e,t){const r=new es;for(const s of yn(e)){const i=t.data.field(s.fieldPath);if(i==null)return null;const o=r.Ht(s.kind);En.bt.Pt(i,o)}return r.Wt()}Tn(e){const t=new es;return En.bt.Pt(e,t.Ht(0)),t.Wt()}Rn(e,t){const r=new es;return En.bt.Pt(Tc(this.databaseId,t),r.Ht(function(i){const o=yn(i);return o.length===0?0:o[o.length-1].kind}(e))),r.Wt()}Pn(e,t,r){if(r===null)return[];let s=[];s.push(new es);let i=0;for(const o of yn(e)){const c=r[i++];for(const l of s)if(this.Vn(t,o.fieldPath)&&Cs(c))s=this.mn(s,o,c);else{const h=l.Ht(o.kind);En.bt.Pt(c,h)}}return this.fn(s)}hn(e,t,r){return this.Pn(e,t,r.position)}fn(e){const t=[];for(let r=0;r<e.length;++r)t[r]=e[r].Wt();return t}mn(e,t,r){const s=[...e],i=[];for(const o of r.arrayValue.values||[])for(const c of s){const l=new es;l.seed(c.Wt()),En.bt.Pt(o,l.Ht(t.kind)),i.push(l)}return i}Vn(e,t){return!!e.filters.find(r=>r instanceof re&&r.field.isEqual(t)&&(r.op==="in"||r.op==="not-in"))}getFieldIndexes(e,t){const r=ts(e),s=Jn(e);return(t?r.U("collectionGroupIndex",IDBKeyRange.bound(t,t)):r.U()).next(i=>{const o=[];return A.forEach(i,c=>s.get([c.indexId,this.uid]).next(l=>{o.push(function(f,m){const I=m?new As(m.sequenceNumber,new rt(Mn(m.readTime),new F(dt(m.documentKey)),m.largestBatchId)):As.empty(),S=f.fields.map(([D,N])=>new bi(fe.fromServerFormat(D),N));return new qi(f.indexId,f.collectionGroup,S,I)}(c,l))})).next(()=>o)})}getNextCollectionGroupToUpdate(e){return this.getFieldIndexes(e).next(t=>t.length===0?null:(t.sort((r,s)=>{const i=r.indexState.sequenceNumber-s.indexState.sequenceNumber;return i!==0?i:Y(r.collectionGroup,s.collectionGroup)}),t[0].collectionGroup))}updateCollectionGroup(e,t,r){const s=ts(e),i=Jn(e);return this.gn(e).next(o=>s.U("collectionGroupIndex",IDBKeyRange.bound(t,t)).next(c=>A.forEach(c,l=>i.put(mh(l.indexId,this.uid,o,r)))))}updateIndexEntries(e,t){const r=new Map;return A.forEach(t,(s,i)=>{const o=r.get(s.collectionGroup);return(o?A.resolve(o):this.getFieldIndexes(e,s.collectionGroup)).next(c=>(r.set(s.collectionGroup,c),A.forEach(c,l=>this.pn(e,s,l).next(h=>{const f=this.yn(i,l);return h.isEqual(f)?A.resolve():this.wn(e,i,l,h,f)}))))})}Sn(e,t,r,s){return Qn(e).put({indexId:s.indexId,uid:this.uid,arrayValue:s.arrayValue,directionalValue:s.directionalValue,orderedDocumentKey:this.Rn(r,t.key),documentKey:t.key.path.toArray()})}bn(e,t,r,s){return Qn(e).delete([s.indexId,this.uid,s.arrayValue,s.directionalValue,this.Rn(r,t.key),t.key.path.toArray()])}pn(e,t,r){const s=Qn(e);let i=new le(Lt);return s.J({index:"documentKeyIndex",range:IDBKeyRange.only([r.indexId,this.uid,this.Rn(r,t)])},(o,c)=>{i=i.add(new wn(r.indexId,t,c.arrayValue,c.directionalValue))}).next(()=>i)}yn(e,t){let r=new le(Lt);const s=this.An(t,e);if(s==null)return r;const i=Ma(t);if(i!=null){const o=e.data.field(i.fieldPath);if(Cs(o))for(const c of o.arrayValue.values||[])r=r.add(new wn(t.indexId,e.key,this.Tn(c),s))}else r=r.add(new wn(t.indexId,e.key,fi,s));return r}wn(e,t,r,s,i){k("IndexedDbIndexManager","Updating index entries for document '%s'",t.key);const o=[];return function(l,h,f,m,I){const S=l.getIterator(),D=h.getIterator();let N=Hn(S),P=Hn(D);for(;N||P;){let H=!1,K=!1;if(N&&P){const q=f(N,P);q<0?K=!0:q>0&&(H=!0)}else N!=null?K=!0:H=!0;H?(m(P),P=Hn(D)):K?(I(N),N=Hn(S)):(N=Hn(S),P=Hn(D))}}(s,i,Lt,c=>{o.push(this.Sn(e,t,r,c))},c=>{o.push(this.bn(e,t,r,c))}),A.waitFor(o)}gn(e){let t=1;return Jn(e).J({index:"sequenceNumberIndex",reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(r,s,i)=>{i.done(),t=s.sequenceNumber+1}).next(()=>t)}createRange(e,t,r){r=r.sort((o,c)=>Lt(o,c)).filter((o,c,l)=>!c||Lt(o,l[c-1])!==0);const s=[];s.push(e);for(const o of r){const c=Lt(o,e),l=Lt(o,t);if(c===0)s[0]=e.Jt();else if(c>0&&l<0)s.push(o),s.push(o.Jt());else if(l>0)break}s.push(t);const i=[];for(let o=0;o<s.length;o+=2){if(this.Dn(s[o],s[o+1]))return[];const c=[s[o].indexId,this.uid,s[o].arrayValue,s[o].directionalValue,fi,[]],l=[s[o+1].indexId,this.uid,s[o+1].arrayValue,s[o+1].directionalValue,fi,[]];i.push(IDBKeyRange.bound(c,l))}return i}Dn(e,t){return Lt(e,t)>0}getMinOffsetFromCollectionGroup(e,t){return this.getFieldIndexes(e,t).next(Th)}getMinOffset(e,t){return A.mapArray(this.cn(t),r=>this.ln(e,r).next(s=>s||U())).next(Th)}}function wh(n){return Ce(n,"collectionParents")}function Qn(n){return Ce(n,"indexEntries")}function ts(n){return Ce(n,"indexConfiguration")}function Jn(n){return Ce(n,"indexState")}function Th(n){j(n.length!==0);let e=n[0].indexState.offset,t=e.largestBatchId;for(let r=1;r<n.length;r++){const s=n[r].indexState.offset;vc(s,e)<0&&(e=s),t<s.largestBatchId&&(t=s.largestBatchId)}return new rt(e.readTime,e.documentKey,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bh={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0};class Ke{constructor(e,t,r){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=r}static withCacheSize(e){return new Ke(e,Ke.DEFAULT_COLLECTION_PERCENTILE,Ke.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fp(n,e,t){const r=n.store("mutations"),s=n.store("documentMutations"),i=[],o=IDBKeyRange.only(t.batchId);let c=0;const l=r.J({range:o},(f,m,I)=>(c++,I.delete()));i.push(l.next(()=>{j(c===1)}));const h=[];for(const f of t.mutations){const m=gf(e,f.key.path,t.batchId);i.push(s.delete(m)),h.push(f.key)}return A.waitFor(i).next(()=>h)}function Ji(n){if(!n)return 0;let e;if(n.document)e=n.document;else if(n.unknownDocument)e=n.unknownDocument;else{if(!n.noDocument)throw U();e=n.noDocument}return JSON.stringify(e).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ke.DEFAULT_COLLECTION_PERCENTILE=10,Ke.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Ke.DEFAULT=new Ke(41943040,Ke.DEFAULT_COLLECTION_PERCENTILE,Ke.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Ke.DISABLED=new Ke(-1,0,0);class bo{constructor(e,t,r,s){this.userId=e,this.serializer=t,this.indexManager=r,this.referenceDelegate=s,this.Cn={}}static lt(e,t,r,s){j(e.uid!=="");const i=e.isAuthenticated()?e.uid:"";return new bo(i,t,r,s)}checkEmpty(e){let t=!0;const r=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Ft(e).J({index:"userMutationsIndex",range:r},(s,i,o)=>{t=!1,o.done()}).next(()=>t)}addMutationBatch(e,t,r,s){const i=rr(e),o=Ft(e);return o.add({}).next(c=>{j(typeof c=="number");const l=new Sc(c,t,r,s),h=function(S,D,N){const P=N.baseMutations.map(K=>Wi(S.ct,K)),H=N.mutations.map(K=>Wi(S.ct,K));return{userId:D,batchId:N.batchId,localWriteTimeMs:N.localWriteTime.toMillis(),baseMutations:P,mutations:H}}(this.serializer,this.userId,l),f=[];let m=new le((I,S)=>Y(I.canonicalString(),S.canonicalString()));for(const I of s){const S=gf(this.userId,I.key.path,c);m=m.add(I.key.path.popLast()),f.push(o.put(h)),f.push(i.put(S,TI))}return m.forEach(I=>{f.push(this.indexManager.addToCollectionParentIndex(e,I))}),e.addOnCommittedListener(()=>{this.Cn[c]=l.keys()}),A.waitFor(f).next(()=>l)})}lookupMutationBatch(e,t){return Ft(e).get(t).next(r=>r?(j(r.userId===this.userId),In(this.serializer,r)):null)}vn(e,t){return this.Cn[t]?A.resolve(this.Cn[t]):this.lookupMutationBatch(e,t).next(r=>{if(r){const s=r.keys();return this.Cn[t]=s,s}return null})}getNextMutationBatchAfterBatchId(e,t){const r=t+1,s=IDBKeyRange.lowerBound([this.userId,r]);let i=null;return Ft(e).J({index:"userMutationsIndex",range:s},(o,c,l)=>{c.userId===this.userId&&(j(c.batchId>=r),i=In(this.serializer,c)),l.done()}).next(()=>i)}getHighestUnacknowledgedBatchId(e){const t=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let r=-1;return Ft(e).J({index:"userMutationsIndex",range:t,reverse:!0},(s,i,o)=>{r=i.batchId,o.done()}).next(()=>r)}getAllMutationBatches(e){const t=IDBKeyRange.bound([this.userId,-1],[this.userId,Number.POSITIVE_INFINITY]);return Ft(e).U("userMutationsIndex",t).next(r=>r.map(s=>In(this.serializer,s)))}getAllMutationBatchesAffectingDocumentKey(e,t){const r=Ai(this.userId,t.path),s=IDBKeyRange.lowerBound(r),i=[];return rr(e).J({range:s},(o,c,l)=>{const[h,f,m]=o,I=dt(f);if(h===this.userId&&t.path.isEqual(I))return Ft(e).get(m).next(S=>{if(!S)throw U();j(S.userId===this.userId),i.push(In(this.serializer,S))});l.done()}).next(()=>i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let r=new le(Y);const s=[];return t.forEach(i=>{const o=Ai(this.userId,i.path),c=IDBKeyRange.lowerBound(o),l=rr(e).J({range:c},(h,f,m)=>{const[I,S,D]=h,N=dt(S);I===this.userId&&i.path.isEqual(N)?r=r.add(D):m.done()});s.push(l)}),A.waitFor(s).next(()=>this.Fn(e,r))}getAllMutationBatchesAffectingQuery(e,t){const r=t.path,s=r.length+1,i=Ai(this.userId,r),o=IDBKeyRange.lowerBound(i);let c=new le(Y);return rr(e).J({range:o},(l,h,f)=>{const[m,I,S]=l,D=dt(I);m===this.userId&&r.isPrefixOf(D)?D.length===s&&(c=c.add(S)):f.done()}).next(()=>this.Fn(e,c))}Fn(e,t){const r=[],s=[];return t.forEach(i=>{s.push(Ft(e).get(i).next(o=>{if(o===null)throw U();j(o.userId===this.userId),r.push(In(this.serializer,o))}))}),A.waitFor(s).next(()=>r)}removeMutationBatch(e,t){return fp(e._e,this.userId,t).next(r=>(e.addOnCommittedListener(()=>{this.Mn(t.batchId)}),A.forEach(r,s=>this.referenceDelegate.markPotentiallyOrphaned(e,s))))}Mn(e){delete this.Cn[e]}performConsistencyCheck(e){return this.checkEmpty(e).next(t=>{if(!t)return A.resolve();const r=IDBKeyRange.lowerBound(function(o){return[o]}(this.userId)),s=[];return rr(e).J({range:r},(i,o,c)=>{if(i[0]===this.userId){const l=dt(i[1]);s.push(l)}else c.done()}).next(()=>{j(s.length===0)})})}containsKey(e,t){return pp(e,this.userId,t)}xn(e){return mp(e).get(this.userId).next(t=>t||{userId:this.userId,lastAcknowledgedBatchId:-1,lastStreamToken:""})}}function pp(n,e,t){const r=Ai(e,t.path),s=r[1],i=IDBKeyRange.lowerBound(r);let o=!1;return rr(n).J({range:i,H:!0},(c,l,h)=>{const[f,m,I]=c;f===e&&m===s&&(o=!0),h.done()}).next(()=>o)}function Ft(n){return Ce(n,"mutations")}function rr(n){return Ce(n,"documentMutations")}function mp(n){return Ce(n,"mutationQueues")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ln{constructor(e){this.On=e}next(){return this.On+=2,this.On}static Nn(){return new Ln(0)}static Ln(){return new Ln(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UE{constructor(e,t){this.referenceDelegate=e,this.serializer=t}allocateTargetId(e){return this.Bn(e).next(t=>{const r=new Ln(t.highestTargetId);return t.highestTargetId=r.next(),this.kn(e,t).next(()=>t.highestTargetId)})}getLastRemoteSnapshotVersion(e){return this.Bn(e).next(t=>G.fromTimestamp(new pe(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(e){return this.Bn(e).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(e,t,r){return this.Bn(e).next(s=>(s.highestListenSequenceNumber=t,r&&(s.lastRemoteSnapshotVersion=r.toTimestamp()),t>s.highestListenSequenceNumber&&(s.highestListenSequenceNumber=t),this.kn(e,s)))}addTargetData(e,t){return this.qn(e,t).next(()=>this.Bn(e).next(r=>(r.targetCount+=1,this.Qn(t,r),this.kn(e,r))))}updateTargetData(e,t){return this.qn(e,t)}removeTargetData(e,t){return this.removeMatchingKeysForTargetId(e,t.targetId).next(()=>Yn(e).delete(t.targetId)).next(()=>this.Bn(e)).next(r=>(j(r.targetCount>0),r.targetCount-=1,this.kn(e,r)))}removeTargets(e,t,r){let s=0;const i=[];return Yn(e).J((o,c)=>{const l=ls(c);l.sequenceNumber<=t&&r.get(l.targetId)===null&&(s++,i.push(this.removeTargetData(e,l)))}).next(()=>A.waitFor(i)).next(()=>s)}forEachTarget(e,t){return Yn(e).J((r,s)=>{const i=ls(s);t(i)})}Bn(e){return Ah(e).get("targetGlobalKey").next(t=>(j(t!==null),t))}kn(e,t){return Ah(e).put("targetGlobalKey",t)}qn(e,t){return Yn(e).put(lp(this.serializer,t))}Qn(e,t){let r=!1;return e.targetId>t.highestTargetId&&(t.highestTargetId=e.targetId,r=!0),e.sequenceNumber>t.highestListenSequenceNumber&&(t.highestListenSequenceNumber=e.sequenceNumber,r=!0),r}getTargetCount(e){return this.Bn(e).next(t=>t.targetCount)}getTargetData(e,t){const r=xn(t),s=IDBKeyRange.bound([r,Number.NEGATIVE_INFINITY],[r,Number.POSITIVE_INFINITY]);let i=null;return Yn(e).J({range:s,index:"queryTargetsIndex"},(o,c,l)=>{const h=ls(c);Us(t,h.target)&&(i=h,l.done())}).next(()=>i)}addMatchingKeys(e,t,r){const s=[],i=jt(e);return t.forEach(o=>{const c=je(o.path);s.push(i.put({targetId:r,path:c})),s.push(this.referenceDelegate.addReference(e,r,o))}),A.waitFor(s)}removeMatchingKeys(e,t,r){const s=jt(e);return A.forEach(t,i=>{const o=je(i.path);return A.waitFor([s.delete([r,o]),this.referenceDelegate.removeReference(e,r,i)])})}removeMatchingKeysForTargetId(e,t){const r=jt(e),s=IDBKeyRange.bound([t],[t+1],!1,!0);return r.delete(s)}getMatchingKeysForTargetId(e,t){const r=IDBKeyRange.bound([t],[t+1],!1,!0),s=jt(e);let i=ee();return s.J({range:r,H:!0},(o,c,l)=>{const h=dt(o[1]),f=new F(h);i=i.add(f)}).next(()=>i)}containsKey(e,t){const r=je(t.path),s=IDBKeyRange.bound([r],[lf(r)],!1,!0);let i=0;return jt(e).J({index:"documentTargetsIndex",H:!0,range:s},([o,c],l,h)=>{o!==0&&(i++,h.done())}).next(()=>i>0)}ot(e,t){return Yn(e).get(t).next(r=>r?ls(r):null)}}function Yn(n){return Ce(n,"targets")}function Ah(n){return Ce(n,"targetGlobal")}function jt(n){return Ce(n,"targetDocuments")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sh([n,e],[t,r]){const s=Y(n,t);return s===0?Y(e,r):s}class BE{constructor(e){this.Kn=e,this.buffer=new le(Sh),this.$n=0}Un(){return++this.$n}Wn(e){const t=[e,this.Un()];if(this.buffer.size<this.Kn)this.buffer=this.buffer.add(t);else{const r=this.buffer.last();Sh(t,r)<0&&(this.buffer=this.buffer.delete(r).add(t))}}get maxValue(){return this.buffer.last()[0]}}class qE{constructor(e,t,r){this.garbageCollector=e,this.asyncQueue=t,this.localStore=r,this.Gn=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.zn(6e4)}stop(){this.Gn&&(this.Gn.cancel(),this.Gn=null)}get started(){return this.Gn!==null}zn(e){k("LruGarbageCollector",`Garbage collection scheduled in ${e}ms`),this.Gn=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Gn=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){cn(t)?k("LruGarbageCollector","Ignoring IndexedDB error during garbage collection: ",t):await an(t)}await this.zn(3e5)})}}class jE{constructor(e,t){this.jn=e,this.params=t}calculateTargetCount(e,t){return this.jn.Hn(e).next(r=>Math.floor(t/100*r))}nthSequenceNumber(e,t){if(t===0)return A.resolve(We.oe);const r=new BE(t);return this.jn.forEachTarget(e,s=>r.Wn(s.sequenceNumber)).next(()=>this.jn.Jn(e,s=>r.Wn(s))).next(()=>r.maxValue)}removeTargets(e,t,r){return this.jn.removeTargets(e,t,r)}removeOrphanedDocuments(e,t){return this.jn.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(k("LruGarbageCollector","Garbage collection skipped; disabled"),A.resolve(bh)):this.getCacheSize(e).next(r=>r<this.params.cacheSizeCollectionThreshold?(k("LruGarbageCollector",`Garbage collection skipped; Cache size ${r} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),bh):this.Yn(e,t))}getCacheSize(e){return this.jn.getCacheSize(e)}Yn(e,t){let r,s,i,o,c,l,h;const f=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(m=>(m>this.params.maximumSequenceNumbersToCollect?(k("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${m}`),s=this.params.maximumSequenceNumbersToCollect):s=m,o=Date.now(),this.nthSequenceNumber(e,s))).next(m=>(r=m,c=Date.now(),this.removeTargets(e,r,t))).next(m=>(i=m,l=Date.now(),this.removeOrphanedDocuments(e,r))).next(m=>(h=Date.now(),Zn()<=te.DEBUG&&k("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-f}ms
	Determined least recently used ${s} in `+(c-o)+`ms
	Removed ${i} targets in `+(l-c)+`ms
	Removed ${m} documents in `+(h-l)+`ms
Total Duration: ${h-f}ms`),A.resolve({didRun:!0,sequenceNumbersCollected:s,targetsRemoved:i,documentsRemoved:m})))}}function GE(n,e){return new jE(n,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zE{constructor(e,t){this.db=e,this.garbageCollector=GE(this,t)}Hn(e){const t=this.Zn(e);return this.db.getTargetCache().getTargetCount(e).next(r=>t.next(s=>r+s))}Zn(e){let t=0;return this.Jn(e,r=>{t++}).next(()=>t)}forEachTarget(e,t){return this.db.getTargetCache().forEachTarget(e,t)}Jn(e,t){return this.Xn(e,(r,s)=>t(s))}addReference(e,t,r){return pi(e,r)}removeReference(e,t,r){return pi(e,r)}removeTargets(e,t,r){return this.db.getTargetCache().removeTargets(e,t,r)}markPotentiallyOrphaned(e,t){return pi(e,t)}er(e,t){return function(s,i){let o=!1;return mp(s).Y(c=>pp(s,c,i).next(l=>(l&&(o=!0),A.resolve(!l)))).next(()=>o)}(e,t)}removeOrphanedDocuments(e,t){const r=this.db.getRemoteDocumentCache().newChangeBuffer(),s=[];let i=0;return this.Xn(e,(o,c)=>{if(c<=t){const l=this.er(e,o).next(h=>{if(!h)return i++,r.getEntry(e,o).next(()=>(r.removeEntry(o,G.min()),jt(e).delete(function(m){return[0,je(m.path)]}(o))))});s.push(l)}}).next(()=>A.waitFor(s)).next(()=>r.apply(e)).next(()=>i)}removeTarget(e,t){const r=t.withSequenceNumber(e.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(e,r)}updateLimboDocument(e,t){return pi(e,t)}Xn(e,t){const r=jt(e);let s,i=We.oe;return r.J({index:"documentTargetsIndex"},([o,c],{path:l,sequenceNumber:h})=>{o===0?(i!==We.oe&&t(new F(dt(s)),i),i=h,s=l):i=We.oe}).next(()=>{i!==We.oe&&t(new F(dt(s)),i)})}getCacheSize(e){return this.db.getRemoteDocumentCache().getSize(e)}}function pi(n,e){return jt(n).put(function(r,s){return{targetId:0,path:je(r.path),sequenceNumber:s}}(e,n.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gp{constructor(){this.changes=new ln(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,_e.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const r=this.changes.get(t);return r!==void 0?A.resolve(r):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class KE{constructor(e){this.serializer=e}setIndexManager(e){this.indexManager=e}addEntry(e,t,r){return gn(e).put(r)}removeEntry(e,t,r){return gn(e).delete(function(i,o){const c=i.path.toArray();return[c.slice(0,c.length-2),c[c.length-2],Hi(o),c[c.length-1]]}(t,r))}updateMetadata(e,t){return this.getMetadata(e).next(r=>(r.byteSize+=t,this.tr(e,r)))}getEntry(e,t){let r=_e.newInvalidDocument(t);return gn(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(ns(t))},(s,i)=>{r=this.nr(t,i)}).next(()=>r)}rr(e,t){let r={size:0,document:_e.newInvalidDocument(t)};return gn(e).J({index:"documentKeyIndex",range:IDBKeyRange.only(ns(t))},(s,i)=>{r={document:this.nr(t,i),size:Ji(i)}}).next(()=>r)}getEntries(e,t){let r=Xe();return this.ir(e,t,(s,i)=>{const o=this.nr(s,i);r=r.insert(s,o)}).next(()=>r)}sr(e,t){let r=Xe(),s=new he(F.comparator);return this.ir(e,t,(i,o)=>{const c=this.nr(i,o);r=r.insert(i,c),s=s.insert(i,Ji(o))}).next(()=>({documents:r,_r:s}))}ir(e,t,r){if(t.isEmpty())return A.resolve();let s=new le(Ch);t.forEach(l=>s=s.add(l));const i=IDBKeyRange.bound(ns(s.first()),ns(s.last())),o=s.getIterator();let c=o.getNext();return gn(e).J({index:"documentKeyIndex",range:i},(l,h,f)=>{const m=F.fromSegments([...h.prefixPath,h.collectionGroup,h.documentId]);for(;c&&Ch(c,m)<0;)r(c,null),c=o.getNext();c&&c.isEqual(m)&&(r(c,h),c=o.hasNext()?o.getNext():null),c?f.$(ns(c)):f.done()}).next(()=>{for(;c;)r(c,null),c=o.hasNext()?o.getNext():null})}getDocumentsMatchingQuery(e,t,r,s,i){const o=t.path,c=[o.popLast().toArray(),o.lastSegment(),Hi(r.readTime),r.documentKey.path.isEmpty()?"":r.documentKey.path.lastSegment()],l=[o.popLast().toArray(),o.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return gn(e).U(IDBKeyRange.bound(c,l,!0)).next(h=>{i==null||i.incrementDocumentReadCount(h.length);let f=Xe();for(const m of h){const I=this.nr(F.fromSegments(m.prefixPath.concat(m.collectionGroup,m.documentId)),m);I.isFoundDocument()&&(Bs(t,I)||s.has(I.key))&&(f=f.insert(I.key,I))}return f})}getAllFromCollectionGroup(e,t,r,s){let i=Xe();const o=Ph(t,r),c=Ph(t,rt.max());return gn(e).J({index:"collectionGroupIndex",range:IDBKeyRange.bound(o,c,!0)},(l,h,f)=>{const m=this.nr(F.fromSegments(h.prefixPath.concat(h.collectionGroup,h.documentId)),h);i=i.insert(m.key,m),i.size===s&&f.done()}).next(()=>i)}newChangeBuffer(e){return new WE(this,!!e&&e.trackRemovals)}getSize(e){return this.getMetadata(e).next(t=>t.byteSize)}getMetadata(e){return Rh(e).get("remoteDocumentGlobalKey").next(t=>(j(!!t),t))}tr(e,t){return Rh(e).put("remoteDocumentGlobalKey",t)}nr(e,t){if(t){const r=DE(this.serializer,t);if(!(r.isNoDocument()&&r.version.isEqual(G.min())))return r}return _e.newInvalidDocument(e)}}function _p(n){return new KE(n)}class WE extends gp{constructor(e,t){super(),this.ar=e,this.trackRemovals=t,this.ur=new ln(r=>r.toString(),(r,s)=>r.isEqual(s))}applyChanges(e){const t=[];let r=0,s=new le((i,o)=>Y(i.canonicalString(),o.canonicalString()));return this.changes.forEach((i,o)=>{const c=this.ur.get(i);if(t.push(this.ar.removeEntry(e,i,c.readTime)),o.isValidDocument()){const l=fh(this.ar.serializer,o);s=s.add(i.path.popLast());const h=Ji(l);r+=h-c.size,t.push(this.ar.addEntry(e,i,l))}else if(r-=c.size,this.trackRemovals){const l=fh(this.ar.serializer,o.convertToNoDocument(G.min()));t.push(this.ar.addEntry(e,i,l))}}),s.forEach(i=>{t.push(this.ar.indexManager.addToCollectionParentIndex(e,i))}),t.push(this.ar.updateMetadata(e,r)),A.waitFor(t)}getFromCache(e,t){return this.ar.rr(e,t).next(r=>(this.ur.set(t,{size:r.size,readTime:r.document.readTime}),r.document))}getAllFromCache(e,t){return this.ar.sr(e,t).next(({documents:r,_r:s})=>(s.forEach((i,o)=>{this.ur.set(i,{size:o,readTime:r.get(i).readTime})}),r))}}function Rh(n){return Ce(n,"remoteDocumentGlobal")}function gn(n){return Ce(n,"remoteDocumentsV14")}function ns(n){const e=n.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function Ph(n,e){const t=e.documentKey.path.toArray();return[n,Hi(e.readTime),t.slice(0,t.length-2),t.length>0?t[t.length-1]:""]}function Ch(n,e){const t=n.path.toArray(),r=e.path.toArray();let s=0;for(let i=0;i<t.length-2&&i<r.length-2;++i)if(s=Y(t[i],r[i]),s)return s;return s=Y(t.length,r.length),s||(s=Y(t[t.length-2],r[r.length-2]),s||Y(t[t.length-1],r[r.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HE{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yp{constructor(e,t,r,s){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=r,this.indexManager=s}getDocument(e,t){let r=null;return this.documentOverlayCache.getOverlay(e,t).next(s=>(r=s,this.remoteDocumentCache.getEntry(e,t))).next(s=>(r!==null&&gs(r.mutation,s,He.empty(),pe.now()),s))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.getLocalViewOfDocuments(e,r,ee()).next(()=>r))}getLocalViewOfDocuments(e,t,r=ee()){const s=ft();return this.populateOverlays(e,s,t).next(()=>this.computeViews(e,t,s,r).next(i=>{let o=as();return i.forEach((c,l)=>{o=o.insert(c,l.overlayedDocument)}),o}))}getOverlayedDocuments(e,t){const r=ft();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,ee()))}populateOverlays(e,t,r){const s=[];return r.forEach(i=>{t.has(i)||s.push(i)}),this.documentOverlayCache.getOverlays(e,s).next(i=>{i.forEach((o,c)=>{t.set(o,c)})})}computeViews(e,t,r,s){let i=Xe();const o=ms(),c=function(){return ms()}();return t.forEach((l,h)=>{const f=r.get(h.key);s.has(h.key)&&(f===void 0||f.mutation instanceof Dt)?i=i.insert(h.key,h):f!==void 0?(o.set(h.key,f.mutation.getFieldMask()),gs(f.mutation,h,f.mutation.getFieldMask(),pe.now())):o.set(h.key,He.empty())}),this.recalculateAndSaveOverlays(e,i).next(l=>(l.forEach((h,f)=>o.set(h,f)),t.forEach((h,f)=>{var m;return c.set(h,new HE(f,(m=o.get(h))!==null&&m!==void 0?m:null))}),c))}recalculateAndSaveOverlays(e,t){const r=ms();let s=new he((o,c)=>o-c),i=ee();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(o=>{for(const c of o)c.keys().forEach(l=>{const h=t.get(l);if(h===null)return;let f=r.get(l)||He.empty();f=c.applyToLocalView(h,f),r.set(l,f);const m=(s.get(c.batchId)||ee()).add(l);s=s.insert(c.batchId,m)})}).next(()=>{const o=[],c=s.getReverseIterator();for(;c.hasNext();){const l=c.getNext(),h=l.key,f=l.value,m=Ff();f.forEach(I=>{if(!i.has(I)){const S=zf(t.get(I),r.get(I));S!==null&&m.set(I,S),i=i.add(I)}}),o.push(this.documentOverlayCache.saveOverlays(e,h,m))}return A.waitFor(o)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.recalculateAndSaveOverlays(e,r))}getDocumentsMatchingQuery(e,t,r,s){return function(o){return F.isDocumentKey(o.path)&&o.collectionGroup===null&&o.filters.length===0}(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):XI(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,r,s):this.getDocumentsMatchingCollectionQuery(e,t,r,s)}getNextDocuments(e,t,r,s){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,r,s).next(i=>{const o=s-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,r.largestBatchId,s-i.size):A.resolve(ft());let c=-1,l=i;return o.next(h=>A.forEach(h,(f,m)=>(c<m.largestBatchId&&(c=m.largestBatchId),i.get(f)?A.resolve():this.remoteDocumentCache.getEntry(e,f).next(I=>{l=l.insert(f,I)}))).next(()=>this.populateOverlays(e,h,i)).next(()=>this.computeViews(e,l,h,ee())).next(f=>({batchId:c,changes:Lf(f)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new F(t)).next(r=>{let s=as();return r.isFoundDocument()&&(s=s.insert(r.key,r)),s})}getDocumentsMatchingCollectionGroupQuery(e,t,r,s){const i=t.collectionGroup;let o=as();return this.indexManager.getCollectionParents(e,i).next(c=>A.forEach(c,l=>{const h=function(m,I){return new _o(I,null,m.explicitOrderBy.slice(),m.filters.slice(),m.limit,m.limitType,m.startAt,m.endAt)}(t,l.child(i));return this.getDocumentsMatchingCollectionQuery(e,h,r,s).next(f=>{f.forEach((m,I)=>{o=o.insert(m,I)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(e,t,r,s){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,r.largestBatchId).next(o=>(i=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,r,i,s))).next(o=>{i.forEach((l,h)=>{const f=h.getKey();o.get(f)===null&&(o=o.insert(f,_e.newInvalidDocument(f)))});let c=as();return o.forEach((l,h)=>{const f=i.get(l);f!==void 0&&gs(f.mutation,h,He.empty(),pe.now()),Bs(t,h)&&(c=c.insert(l,h))}),c})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class QE{constructor(e){this.serializer=e,this.cr=new Map,this.lr=new Map}getBundleMetadata(e,t){return A.resolve(this.cr.get(t))}saveBundleMetadata(e,t){return this.cr.set(t.id,function(s){return{id:s.id,version:s.version,createTime:Ge(s.createTime)}}(t)),A.resolve()}getNamedQuery(e,t){return A.resolve(this.lr.get(t))}saveNamedQuery(e,t){return this.lr.set(t.name,function(s){return{name:s.name,query:up(s.bundledQuery),readTime:Ge(s.readTime)}}(t)),A.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class JE{constructor(){this.overlays=new he(F.comparator),this.hr=new Map}getOverlay(e,t){return A.resolve(this.overlays.get(t))}getOverlays(e,t){const r=ft();return A.forEach(t,s=>this.getOverlay(e,s).next(i=>{i!==null&&r.set(s,i)})).next(()=>r)}saveOverlays(e,t,r){return r.forEach((s,i)=>{this.ht(e,t,i)}),A.resolve()}removeOverlaysForBatchId(e,t,r){const s=this.hr.get(r);return s!==void 0&&(s.forEach(i=>this.overlays=this.overlays.remove(i)),this.hr.delete(r)),A.resolve()}getOverlaysForCollection(e,t,r){const s=ft(),i=t.length+1,o=new F(t.child("")),c=this.overlays.getIteratorFrom(o);for(;c.hasNext();){const l=c.getNext().value,h=l.getKey();if(!t.isPrefixOf(h.path))break;h.path.length===i&&l.largestBatchId>r&&s.set(l.getKey(),l)}return A.resolve(s)}getOverlaysForCollectionGroup(e,t,r,s){let i=new he((h,f)=>h-f);const o=this.overlays.getIterator();for(;o.hasNext();){const h=o.getNext().value;if(h.getKey().getCollectionGroup()===t&&h.largestBatchId>r){let f=i.get(h.largestBatchId);f===null&&(f=ft(),i=i.insert(h.largestBatchId,f)),f.set(h.getKey(),h)}}const c=ft(),l=i.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((h,f)=>c.set(h,f)),!(c.size()>=s)););return A.resolve(c)}ht(e,t,r){const s=this.overlays.get(r.key);if(s!==null){const o=this.hr.get(s.largestBatchId).delete(r.key);this.hr.set(s.largestBatchId,o)}this.overlays=this.overlays.insert(r.key,new Pc(t,r));let i=this.hr.get(t);i===void 0&&(i=ee(),this.hr.set(t,i)),this.hr.set(t,i.add(r.key))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nc{constructor(){this.Pr=new le(Se.Ir),this.Tr=new le(Se.Er)}isEmpty(){return this.Pr.isEmpty()}addReference(e,t){const r=new Se(e,t);this.Pr=this.Pr.add(r),this.Tr=this.Tr.add(r)}dr(e,t){e.forEach(r=>this.addReference(r,t))}removeReference(e,t){this.Ar(new Se(e,t))}Rr(e,t){e.forEach(r=>this.removeReference(r,t))}Vr(e){const t=new F(new ae([])),r=new Se(t,e),s=new Se(t,e+1),i=[];return this.Tr.forEachInRange([r,s],o=>{this.Ar(o),i.push(o.key)}),i}mr(){this.Pr.forEach(e=>this.Ar(e))}Ar(e){this.Pr=this.Pr.delete(e),this.Tr=this.Tr.delete(e)}gr(e){const t=new F(new ae([])),r=new Se(t,e),s=new Se(t,e+1);let i=ee();return this.Tr.forEachInRange([r,s],o=>{i=i.add(o.key)}),i}containsKey(e){const t=new Se(e,0),r=this.Pr.firstAfterOrEqual(t);return r!==null&&e.isEqual(r.key)}}class Se{constructor(e,t){this.key=e,this.pr=t}static Ir(e,t){return F.comparator(e.key,t.key)||Y(e.pr,t.pr)}static Er(e,t){return Y(e.pr,t.pr)||F.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class YE{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.yr=1,this.wr=new le(Se.Ir)}checkEmpty(e){return A.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,r,s){const i=this.yr;this.yr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new Sc(i,t,r,s);this.mutationQueue.push(o);for(const c of s)this.wr=this.wr.add(new Se(c.key,i)),this.indexManager.addToCollectionParentIndex(e,c.key.path.popLast());return A.resolve(o)}lookupMutationBatch(e,t){return A.resolve(this.Sr(t))}getNextMutationBatchAfterBatchId(e,t){const r=t+1,s=this.br(r),i=s<0?0:s;return A.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return A.resolve(this.mutationQueue.length===0?-1:this.yr-1)}getAllMutationBatches(e){return A.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const r=new Se(t,0),s=new Se(t,Number.POSITIVE_INFINITY),i=[];return this.wr.forEachInRange([r,s],o=>{const c=this.Sr(o.pr);i.push(c)}),A.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let r=new le(Y);return t.forEach(s=>{const i=new Se(s,0),o=new Se(s,Number.POSITIVE_INFINITY);this.wr.forEachInRange([i,o],c=>{r=r.add(c.pr)})}),A.resolve(this.Dr(r))}getAllMutationBatchesAffectingQuery(e,t){const r=t.path,s=r.length+1;let i=r;F.isDocumentKey(i)||(i=i.child(""));const o=new Se(new F(i),0);let c=new le(Y);return this.wr.forEachWhile(l=>{const h=l.key.path;return!!r.isPrefixOf(h)&&(h.length===s&&(c=c.add(l.pr)),!0)},o),A.resolve(this.Dr(c))}Dr(e){const t=[];return e.forEach(r=>{const s=this.Sr(r);s!==null&&t.push(s)}),t}removeMutationBatch(e,t){j(this.Cr(t.batchId,"removed")===0),this.mutationQueue.shift();let r=this.wr;return A.forEach(t.mutations,s=>{const i=new Se(s.key,t.batchId);return r=r.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,s.key)}).next(()=>{this.wr=r})}Mn(e){}containsKey(e,t){const r=new Se(t,0),s=this.wr.firstAfterOrEqual(r);return A.resolve(t.isEqual(s&&s.key))}performConsistencyCheck(e){return this.mutationQueue.length,A.resolve()}Cr(e,t){return this.br(e)}br(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Sr(e){const t=this.br(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XE{constructor(e){this.vr=e,this.docs=function(){return new he(F.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const r=t.key,s=this.docs.get(r),i=s?s.size:0,o=this.vr(t);return this.docs=this.docs.insert(r,{document:t.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,r.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const r=this.docs.get(t);return A.resolve(r?r.document.mutableCopy():_e.newInvalidDocument(t))}getEntries(e,t){let r=Xe();return t.forEach(s=>{const i=this.docs.get(s);r=r.insert(s,i?i.document.mutableCopy():_e.newInvalidDocument(s))}),A.resolve(r)}getDocumentsMatchingQuery(e,t,r,s){let i=Xe();const o=t.path,c=new F(o.child("")),l=this.docs.getIteratorFrom(c);for(;l.hasNext();){const{key:h,value:{document:f}}=l.getNext();if(!o.isPrefixOf(h.path))break;h.path.length>o.length+1||vc(hf(f),r)<=0||(s.has(f.key)||Bs(t,f))&&(i=i.insert(f.key,f.mutableCopy()))}return A.resolve(i)}getAllFromCollectionGroup(e,t,r,s){U()}Fr(e,t){return A.forEach(this.docs,r=>t(r))}newChangeBuffer(e){return new ZE(this)}getSize(e){return A.resolve(this.size)}}class ZE extends gp{constructor(e){super(),this.ar=e}applyChanges(e){const t=[];return this.changes.forEach((r,s)=>{s.isValidDocument()?t.push(this.ar.addEntry(e,s)):this.ar.removeEntry(r)}),A.waitFor(t)}getFromCache(e,t){return this.ar.getEntry(e,t)}getAllFromCache(e,t){return this.ar.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ew{constructor(e){this.persistence=e,this.Mr=new ln(t=>xn(t),Us),this.lastRemoteSnapshotVersion=G.min(),this.highestTargetId=0,this.Or=0,this.Nr=new Nc,this.targetCount=0,this.Lr=Ln.Nn()}forEachTarget(e,t){return this.Mr.forEach((r,s)=>t(s)),A.resolve()}getLastRemoteSnapshotVersion(e){return A.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return A.resolve(this.Or)}allocateTargetId(e){return this.highestTargetId=this.Lr.next(),A.resolve(this.highestTargetId)}setTargetsMetadata(e,t,r){return r&&(this.lastRemoteSnapshotVersion=r),t>this.Or&&(this.Or=t),A.resolve()}qn(e){this.Mr.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Lr=new Ln(t),this.highestTargetId=t),e.sequenceNumber>this.Or&&(this.Or=e.sequenceNumber)}addTargetData(e,t){return this.qn(t),this.targetCount+=1,A.resolve()}updateTargetData(e,t){return this.qn(t),A.resolve()}removeTargetData(e,t){return this.Mr.delete(t.target),this.Nr.Vr(t.targetId),this.targetCount-=1,A.resolve()}removeTargets(e,t,r){let s=0;const i=[];return this.Mr.forEach((o,c)=>{c.sequenceNumber<=t&&r.get(c.targetId)===null&&(this.Mr.delete(o),i.push(this.removeMatchingKeysForTargetId(e,c.targetId)),s++)}),A.waitFor(i).next(()=>s)}getTargetCount(e){return A.resolve(this.targetCount)}getTargetData(e,t){const r=this.Mr.get(t)||null;return A.resolve(r)}addMatchingKeys(e,t,r){return this.Nr.dr(t,r),A.resolve()}removeMatchingKeys(e,t,r){this.Nr.Rr(t,r);const s=this.persistence.referenceDelegate,i=[];return s&&t.forEach(o=>{i.push(s.markPotentiallyOrphaned(e,o))}),A.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.Nr.Vr(t),A.resolve()}getMatchingKeysForTargetId(e,t){const r=this.Nr.gr(t);return A.resolve(r)}containsKey(e,t){return A.resolve(this.Nr.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vp{constructor(e,t){this.Br={},this.overlays={},this.kr=new We(0),this.qr=!1,this.qr=!0,this.referenceDelegate=e(this),this.Qr=new ew(this),this.indexManager=new FE,this.remoteDocumentCache=function(s){return new XE(s)}(r=>this.referenceDelegate.Kr(r)),this.serializer=new cp(t),this.$r=new QE(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.qr=!1,Promise.resolve()}get started(){return this.qr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new JE,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let r=this.Br[e.toKey()];return r||(r=new YE(t,this.referenceDelegate),this.Br[e.toKey()]=r),r}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.$r}runTransaction(e,t,r){k("MemoryPersistence","Starting transaction:",e);const s=new tw(this.kr.next());return this.referenceDelegate.Ur(),r(s).next(i=>this.referenceDelegate.Wr(s).next(()=>i)).toPromise().then(i=>(s.raiseOnCommittedEvent(),i))}Gr(e,t){return A.or(Object.values(this.Br).map(r=>()=>r.containsKey(e,t)))}}class tw extends ff{constructor(e){super(),this.currentSequenceNumber=e}}class Ao{constructor(e){this.persistence=e,this.zr=new Nc,this.jr=null}static Hr(e){return new Ao(e)}get Jr(){if(this.jr)return this.jr;throw U()}addReference(e,t,r){return this.zr.addReference(r,t),this.Jr.delete(r.toString()),A.resolve()}removeReference(e,t,r){return this.zr.removeReference(r,t),this.Jr.add(r.toString()),A.resolve()}markPotentiallyOrphaned(e,t){return this.Jr.add(t.toString()),A.resolve()}removeTarget(e,t){this.zr.Vr(t.targetId).forEach(s=>this.Jr.add(s.toString()));const r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(e,t.targetId).next(s=>{s.forEach(i=>this.Jr.add(i.toString()))}).next(()=>r.removeTargetData(e,t))}Ur(){this.jr=new Set}Wr(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return A.forEach(this.Jr,r=>{const s=F.fromPath(r);return this.Yr(e,s).next(i=>{i||t.removeEntry(s,G.min())})}).next(()=>(this.jr=null,t.apply(e)))}updateLimboDocument(e,t){return this.Yr(e,t).next(r=>{r?this.Jr.delete(t.toString()):this.Jr.add(t.toString())})}Kr(e){return 0}Yr(e,t){return A.or([()=>A.resolve(this.zr.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Gr(e,t)])}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nw{constructor(e){this.serializer=e}O(e,t,r,s){const i=new mo("createOrUpgrade",t);r<1&&s>=1&&(function(l){l.createObjectStore("owner")}(e),function(l){l.createObjectStore("mutationQueues",{keyPath:"userId"}),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",Gu,{unique:!0}),l.createObjectStore("documentMutations")}(e),kh(e),function(l){l.createObjectStore("remoteDocuments")}(e));let o=A.resolve();return r<3&&s>=3&&(r!==0&&(function(l){l.deleteObjectStore("targetDocuments"),l.deleteObjectStore("targets"),l.deleteObjectStore("targetGlobal")}(e),kh(e)),o=o.next(()=>function(l){const h=l.store("targetGlobal"),f={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:G.min().toTimestamp(),targetCount:0};return h.put("targetGlobalKey",f)}(i))),r<4&&s>=4&&(r!==0&&(o=o.next(()=>function(l,h){return h.store("mutations").U().next(f=>{l.deleteObjectStore("mutations"),l.createObjectStore("mutations",{keyPath:"batchId",autoIncrement:!0}).createIndex("userMutationsIndex",Gu,{unique:!0});const m=h.store("mutations"),I=f.map(S=>m.put(S));return A.waitFor(I)})}(e,i))),o=o.next(()=>{(function(l){l.createObjectStore("clientMetadata",{keyPath:"clientId"})})(e)})),r<5&&s>=5&&(o=o.next(()=>this.Xr(i))),r<6&&s>=6&&(o=o.next(()=>(function(l){l.createObjectStore("remoteDocumentGlobal")}(e),this.ei(i)))),r<7&&s>=7&&(o=o.next(()=>this.ti(i))),r<8&&s>=8&&(o=o.next(()=>this.ni(e,i))),r<9&&s>=9&&(o=o.next(()=>{(function(l){l.objectStoreNames.contains("remoteDocumentChanges")&&l.deleteObjectStore("remoteDocumentChanges")})(e)})),r<10&&s>=10&&(o=o.next(()=>this.ri(i))),r<11&&s>=11&&(o=o.next(()=>{(function(l){l.createObjectStore("bundles",{keyPath:"bundleId"})})(e),function(l){l.createObjectStore("namedQueries",{keyPath:"name"})}(e)})),r<12&&s>=12&&(o=o.next(()=>{(function(l){const h=l.createObjectStore("documentOverlays",{keyPath:OI});h.createIndex("collectionPathOverlayIndex",MI,{unique:!1}),h.createIndex("collectionGroupOverlayIndex",LI,{unique:!1})})(e)})),r<13&&s>=13&&(o=o.next(()=>function(l){const h=l.createObjectStore("remoteDocumentsV14",{keyPath:bI});h.createIndex("documentKeyIndex",AI),h.createIndex("collectionGroupIndex",SI)}(e)).next(()=>this.ii(e,i)).next(()=>e.deleteObjectStore("remoteDocuments"))),r<14&&s>=14&&(o=o.next(()=>this.si(e,i))),r<15&&s>=15&&(o=o.next(()=>function(l){l.createObjectStore("indexConfiguration",{keyPath:"indexId",autoIncrement:!0}).createIndex("collectionGroupIndex","collectionGroup",{unique:!1}),l.createObjectStore("indexState",{keyPath:DI}).createIndex("sequenceNumberIndex",VI,{unique:!1}),l.createObjectStore("indexEntries",{keyPath:NI}).createIndex("documentKeyIndex",xI,{unique:!1})}(e))),r<16&&s>=16&&(o=o.next(()=>{t.objectStore("indexState").clear()}).next(()=>{t.objectStore("indexEntries").clear()})),o}ei(e){let t=0;return e.store("remoteDocuments").J((r,s)=>{t+=Ji(s)}).next(()=>{const r={byteSize:t};return e.store("remoteDocumentGlobal").put("remoteDocumentGlobalKey",r)})}Xr(e){const t=e.store("mutationQueues"),r=e.store("mutations");return t.U().next(s=>A.forEach(s,i=>{const o=IDBKeyRange.bound([i.userId,-1],[i.userId,i.lastAcknowledgedBatchId]);return r.U("userMutationsIndex",o).next(c=>A.forEach(c,l=>{j(l.userId===i.userId);const h=In(this.serializer,l);return fp(e,i.userId,h).next(()=>{})}))}))}ti(e){const t=e.store("targetDocuments"),r=e.store("remoteDocuments");return e.store("targetGlobal").get("targetGlobalKey").next(s=>{const i=[];return r.J((o,c)=>{const l=new ae(o),h=function(m){return[0,je(m)]}(l);i.push(t.get(h).next(f=>f?A.resolve():(m=>t.put({targetId:0,path:je(m),sequenceNumber:s.highestListenSequenceNumber}))(l)))}).next(()=>A.waitFor(i))})}ni(e,t){e.createObjectStore("collectionParents",{keyPath:kI});const r=t.store("collectionParents"),s=new Vc,i=o=>{if(s.add(o)){const c=o.lastSegment(),l=o.popLast();return r.put({collectionId:c,parent:je(l)})}};return t.store("remoteDocuments").J({H:!0},(o,c)=>{const l=new ae(o);return i(l.popLast())}).next(()=>t.store("documentMutations").J({H:!0},([o,c,l],h)=>{const f=dt(c);return i(f.popLast())}))}ri(e){const t=e.store("targets");return t.J((r,s)=>{const i=ls(s),o=lp(this.serializer,i);return t.put(o)})}ii(e,t){const r=t.store("remoteDocuments"),s=[];return r.J((i,o)=>{const c=t.store("remoteDocumentsV14"),l=function(m){return m.document?new F(ae.fromString(m.document.name).popFirst(5)):m.noDocument?F.fromSegments(m.noDocument.path):m.unknownDocument?F.fromSegments(m.unknownDocument.path):U()}(o).path.toArray(),h={prefixPath:l.slice(0,l.length-2),collectionGroup:l[l.length-2],documentId:l[l.length-1],readTime:o.readTime||[0,0],unknownDocument:o.unknownDocument,noDocument:o.noDocument,document:o.document,hasCommittedMutations:!!o.hasCommittedMutations};s.push(c.put(h))}).next(()=>A.waitFor(s))}si(e,t){const r=t.store("mutations"),s=_p(this.serializer),i=new vp(Ao.Hr,this.serializer.ct);return r.U().next(o=>{const c=new Map;return o.forEach(l=>{var h;let f=(h=c.get(l.userId))!==null&&h!==void 0?h:ee();In(this.serializer,l).keys().forEach(m=>f=f.add(m)),c.set(l.userId,f)}),A.forEach(c,(l,h)=>{const f=new Le(h),m=To.lt(this.serializer,f),I=i.getIndexManager(f),S=bo.lt(f,this.serializer,I,i.referenceDelegate);return new yp(s,S,m,I).recalculateAndSaveOverlaysForDocumentKeys(new La(t,We.oe),l).next()})})}}function kh(n){n.createObjectStore("targetDocuments",{keyPath:PI}).createIndex("documentTargetsIndex",CI,{unique:!0}),n.createObjectStore("targets",{keyPath:"targetId"}).createIndex("queryTargetsIndex",RI,{unique:!0}),n.createObjectStore("targetGlobal")}const ya="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class xc{constructor(e,t,r,s,i,o,c,l,h,f,m=16){if(this.allowTabSynchronization=e,this.persistenceKey=t,this.clientId=r,this.oi=i,this.window=o,this.document=c,this._i=h,this.ai=f,this.ui=m,this.kr=null,this.qr=!1,this.isPrimary=!1,this.networkEnabled=!0,this.ci=null,this.inForeground=!1,this.li=null,this.hi=null,this.Pi=Number.NEGATIVE_INFINITY,this.Ii=I=>Promise.resolve(),!xc.D())throw new $(C.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new zE(this,s),this.Ti=t+"main",this.serializer=new cp(l),this.Ei=new Yt(this.Ti,this.ui,new nw(this.serializer)),this.Qr=new UE(this.referenceDelegate,this.serializer),this.remoteDocumentCache=_p(this.serializer),this.$r=new VE,this.window&&this.window.localStorage?this.di=this.window.localStorage:(this.di=null,f===!1&&ve("IndexedDbPersistence","LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Ai().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new $(C.FAILED_PRECONDITION,ya);return this.Ri(),this.Vi(),this.mi(),this.runTransaction("getHighestListenSequenceNumber","readonly",e=>this.Qr.getHighestSequenceNumber(e))}).then(e=>{this.kr=new We(e,this._i)}).then(()=>{this.qr=!0}).catch(e=>(this.Ei&&this.Ei.close(),Promise.reject(e)))}fi(e){return this.Ii=async t=>{if(this.started)return e(t)},e(this.isPrimary)}setDatabaseDeletedListener(e){this.Ei.L(async t=>{t.newVersion===null&&await e()})}setNetworkEnabled(e){this.networkEnabled!==e&&(this.networkEnabled=e,this.oi.enqueueAndForget(async()=>{this.started&&await this.Ai()}))}Ai(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",e=>mi(e).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.gi(e).next(t=>{t||(this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)))})}).next(()=>this.pi(e)).next(t=>this.isPrimary&&!t?this.yi(e).next(()=>!1):!!t&&this.wi(e).next(()=>!0))).catch(e=>{if(cn(e))return k("IndexedDbPersistence","Failed to extend owner lease: ",e),this.isPrimary;if(!this.allowTabSynchronization)throw e;return k("IndexedDbPersistence","Releasing owner lease after error during lease refresh",e),!1}).then(e=>{this.isPrimary!==e&&this.oi.enqueueRetryable(()=>this.Ii(e)),this.isPrimary=e})}gi(e){return rs(e).get("owner").next(t=>A.resolve(this.Si(t)))}bi(e){return mi(e).delete(this.clientId)}async Di(){if(this.isPrimary&&!this.Ci(this.Pi,18e5)){this.Pi=Date.now();const e=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const r=Ce(t,"clientMetadata");return r.U().next(s=>{const i=this.vi(s,18e5),o=s.filter(c=>i.indexOf(c)===-1);return A.forEach(o,c=>r.delete(c.clientId)).next(()=>o)})}).catch(()=>[]);if(this.di)for(const t of e)this.di.removeItem(this.Fi(t.clientId))}}mi(){this.hi=this.oi.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Ai().then(()=>this.Di()).then(()=>this.mi()))}Si(e){return!!e&&e.ownerId===this.clientId}pi(e){return this.ai?A.resolve(!0):rs(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)){if(this.Si(t)&&this.networkEnabled)return!0;if(!this.Si(t)){if(!t.allowTabSynchronization)throw new $(C.FAILED_PRECONDITION,ya);return!1}}return!(!this.networkEnabled||!this.inForeground)||mi(e).U().next(r=>this.vi(r,5e3).find(s=>{if(this.clientId!==s.clientId){const i=!this.networkEnabled&&s.networkEnabled,o=!this.inForeground&&s.inForeground,c=this.networkEnabled===s.networkEnabled;if(i||o&&c)return!0}return!1})===void 0)}).next(t=>(this.isPrimary!==t&&k("IndexedDbPersistence",`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.qr=!1,this.xi(),this.hi&&(this.hi.cancel(),this.hi=null),this.Oi(),this.Ni(),await this.Ei.runTransaction("shutdown","readwrite",["owner","clientMetadata"],e=>{const t=new La(e,We.oe);return this.yi(t).next(()=>this.bi(t))}),this.Ei.close(),this.Li()}vi(e,t){return e.filter(r=>this.Ci(r.updateTimeMs,t)&&!this.Mi(r.clientId))}Bi(){return this.runTransaction("getActiveClients","readonly",e=>mi(e).U().next(t=>this.vi(t,18e5).map(r=>r.clientId)))}get started(){return this.qr}getMutationQueue(e,t){return bo.lt(e,this.serializer,t,this.referenceDelegate)}getTargetCache(){return this.Qr}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(e){return new $E(e,this.serializer.ct.databaseId)}getDocumentOverlayCache(e){return To.lt(this.serializer,e)}getBundleCache(){return this.$r}runTransaction(e,t,r){k("IndexedDbPersistence","Starting transaction:",e);const s=t==="readonly"?"readonly":"readwrite",i=function(l){return l===16?$I:l===15?If:l===14?vf:l===13?yf:l===12?FI:l===11?_f:void U()}(this.ui);let o;return this.Ei.runTransaction(e,s,i,c=>(o=new La(c,this.kr?this.kr.next():We.oe),t==="readwrite-primary"?this.gi(o).next(l=>!!l||this.pi(o)).next(l=>{if(!l)throw ve(`Failed to obtain primary lease for action '${e}'.`),this.isPrimary=!1,this.oi.enqueueRetryable(()=>this.Ii(!1)),new $(C.FAILED_PRECONDITION,df);return r(o)}).next(l=>this.wi(o).next(()=>l)):this.ki(o).next(()=>r(o)))).then(c=>(o.raiseOnCommittedEvent(),c))}ki(e){return rs(e).get("owner").next(t=>{if(t!==null&&this.Ci(t.leaseTimestampMs,5e3)&&!this.Mi(t.ownerId)&&!this.Si(t)&&!(this.ai||this.allowTabSynchronization&&t.allowTabSynchronization))throw new $(C.FAILED_PRECONDITION,ya)})}wi(e){const t={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return rs(e).put("owner",t)}static D(){return Yt.D()}yi(e){const t=rs(e);return t.get("owner").next(r=>this.Si(r)?(k("IndexedDbPersistence","Releasing primary lease."),t.delete("owner")):A.resolve())}Ci(e,t){const r=Date.now();return!(e<r-t)&&(!(e>r)||(ve(`Detected an update time that is in the future: ${e} > ${r}`),!1))}Ri(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.li=()=>{this.oi.enqueueAndForget(()=>(this.inForeground=this.document.visibilityState==="visible",this.Ai()))},this.document.addEventListener("visibilitychange",this.li),this.inForeground=this.document.visibilityState==="visible")}Oi(){this.li&&(this.document.removeEventListener("visibilitychange",this.li),this.li=null)}Vi(){var e;typeof((e=this.window)===null||e===void 0?void 0:e.addEventListener)=="function"&&(this.ci=()=>{this.xi();const t=/(?:Version|Mobile)\/1[456]/;md()&&(navigator.appVersion.match(t)||navigator.userAgent.match(t))&&this.oi.enterRestrictedMode(!0),this.oi.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.ci))}Ni(){this.ci&&(this.window.removeEventListener("pagehide",this.ci),this.ci=null)}Mi(e){var t;try{const r=((t=this.di)===null||t===void 0?void 0:t.getItem(this.Fi(e)))!==null;return k("IndexedDbPersistence",`Client '${e}' ${r?"is":"is not"} zombied in LocalStorage`),r}catch(r){return ve("IndexedDbPersistence","Failed to get zombied client id.",r),!1}}xi(){if(this.di)try{this.di.setItem(this.Fi(this.clientId),String(Date.now()))}catch(e){ve("Failed to set zombie client id.",e)}}Li(){if(this.di)try{this.di.removeItem(this.Fi(this.clientId))}catch{}}Fi(e){return`firestore_zombie_${this.persistenceKey}_${e}`}}function rs(n){return Ce(n,"owner")}function mi(n){return Ce(n,"clientMetadata")}function Ip(n,e){let t=n.projectId;return n.isDefaultDatabase||(t+="."+n.database),"firestore/"+e+"/"+t+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oc{constructor(e,t,r,s){this.targetId=e,this.fromCache=t,this.qi=r,this.Qi=s}static Ki(e,t){let r=ee(),s=ee();for(const i of t.docChanges)switch(i.type){case 0:r=r.add(i.doc.key);break;case 1:s=s.add(i.doc.key)}return new Oc(e,t.fromCache,r,s)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rw{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ep{constructor(){this.$i=!1,this.Ui=!1,this.Wi=100,this.Gi=function(){return md()?8:pf(be())>0?6:4}()}initialize(e,t){this.zi=e,this.indexManager=t,this.$i=!0}getDocumentsMatchingQuery(e,t,r,s){const i={result:null};return this.ji(e,t).next(o=>{i.result=o}).next(()=>{if(!i.result)return this.Hi(e,t,s,r).next(o=>{i.result=o})}).next(()=>{if(i.result)return;const o=new rw;return this.Ji(e,t,o).next(c=>{if(i.result=c,this.Ui)return this.Yi(e,t,o,c.size)})}).next(()=>i.result)}Yi(e,t,r,s){return r.documentReadCount<this.Wi?(Zn()<=te.DEBUG&&k("QueryEngine","SDK will not create cache indexes for query:",er(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Wi,"documents"),A.resolve()):(Zn()<=te.DEBUG&&k("QueryEngine","Query:",er(t),"scans",r.documentReadCount,"local documents and returns",s,"documents as results."),r.documentReadCount>this.Gi*s?(Zn()<=te.DEBUG&&k("QueryEngine","The SDK decides to create cache indexes for query:",er(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,et(t))):A.resolve())}ji(e,t){if(nh(t))return A.resolve(null);let r=et(t);return this.indexManager.getIndexType(e,r).next(s=>s===0?null:(t.limit!==null&&s===1&&(t=ja(t,null,"F"),r=et(t)),this.indexManager.getDocumentsMatchingTarget(e,r).next(i=>{const o=ee(...i);return this.zi.getDocuments(e,o).next(c=>this.indexManager.getMinOffset(e,r).next(l=>{const h=this.Zi(t,c);return this.Xi(t,h,o,l.readTime)?this.ji(e,ja(t,null,"F")):this.es(e,h,t,l)}))})))}Hi(e,t,r,s){return nh(t)||s.isEqual(G.min())?A.resolve(null):this.zi.getDocuments(e,r).next(i=>{const o=this.Zi(t,i);return this.Xi(t,o,r,s)?A.resolve(null):(Zn()<=te.DEBUG&&k("QueryEngine","Re-using previous result from %s to execute query: %s",s.toString(),er(t)),this.es(e,o,t,uf(s,-1)).next(c=>c))})}Zi(e,t){let r=new le(Of(e));return t.forEach((s,i)=>{Bs(e,i)&&(r=r.add(i))}),r}Xi(e,t,r,s){if(e.limit===null)return!1;if(r.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(s)>0)}Ji(e,t,r){return Zn()<=te.DEBUG&&k("QueryEngine","Using full collection scan to execute query:",er(t)),this.zi.getDocumentsMatchingQuery(e,t,rt.min(),r)}es(e,t,r,s){return this.zi.getDocumentsMatchingQuery(e,r,s).next(i=>(t.forEach(o=>{i=i.insert(o.key,o)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sw{constructor(e,t,r,s){this.persistence=e,this.ts=t,this.serializer=s,this.ns=new he(Y),this.rs=new ln(i=>xn(i),Us),this.ss=new Map,this.os=e.getRemoteDocumentCache(),this.Qr=e.getTargetCache(),this.$r=e.getBundleCache(),this._s(r)}_s(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new yp(this.os,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.os.setIndexManager(this.indexManager),this.ts.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.ns))}}function wp(n,e,t,r){return new sw(n,e,t,r)}async function Tp(n,e){const t=B(n);return await t.persistence.runTransaction("Handle user change","readonly",r=>{let s;return t.mutationQueue.getAllMutationBatches(r).next(i=>(s=i,t._s(e),t.mutationQueue.getAllMutationBatches(r))).next(i=>{const o=[],c=[];let l=ee();for(const h of s){o.push(h.batchId);for(const f of h.mutations)l=l.add(f.key)}for(const h of i){c.push(h.batchId);for(const f of h.mutations)l=l.add(f.key)}return t.localDocuments.getDocuments(r,l).next(h=>({us:h,removedBatchIds:o,addedBatchIds:c}))})})}function iw(n,e){const t=B(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",r=>{const s=e.batch.keys(),i=t.os.newChangeBuffer({trackRemovals:!0});return function(c,l,h,f){const m=h.batch,I=m.keys();let S=A.resolve();return I.forEach(D=>{S=S.next(()=>f.getEntry(l,D)).next(N=>{const P=h.docVersions.get(D);j(P!==null),N.version.compareTo(P)<0&&(m.applyToRemoteDocument(N,h),N.isValidDocument()&&(N.setReadTime(h.commitVersion),f.addEntry(N)))})}),S.next(()=>c.mutationQueue.removeMutationBatch(l,m))}(t,r,e,i).next(()=>i.apply(r)).next(()=>t.mutationQueue.performConsistencyCheck(r)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(r,s,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(r,function(c){let l=ee();for(let h=0;h<c.mutationResults.length;++h)c.mutationResults[h].transformResults.length>0&&(l=l.add(c.batch.mutations[h].key));return l}(e))).next(()=>t.localDocuments.getDocuments(r,s))})}function bp(n){const e=B(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Qr.getLastRemoteSnapshotVersion(t))}function ow(n,e){const t=B(n),r=e.snapshotVersion;let s=t.ns;return t.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const o=t.os.newChangeBuffer({trackRemovals:!0});s=t.ns;const c=[];e.targetChanges.forEach((f,m)=>{const I=s.get(m);if(!I)return;c.push(t.Qr.removeMatchingKeys(i,f.removedDocuments,m).next(()=>t.Qr.addMatchingKeys(i,f.addedDocuments,m)));let S=I.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(m)!==null?S=S.withResumeToken(Pe.EMPTY_BYTE_STRING,G.min()).withLastLimboFreeSnapshotVersion(G.min()):f.resumeToken.approximateByteSize()>0&&(S=S.withResumeToken(f.resumeToken,r)),s=s.insert(m,S),function(N,P,H){return N.resumeToken.approximateByteSize()===0||P.snapshotVersion.toMicroseconds()-N.snapshotVersion.toMicroseconds()>=3e8?!0:H.addedDocuments.size+H.modifiedDocuments.size+H.removedDocuments.size>0}(I,S,f)&&c.push(t.Qr.updateTargetData(i,S))});let l=Xe(),h=ee();if(e.documentUpdates.forEach(f=>{e.resolvedLimboDocuments.has(f)&&c.push(t.persistence.referenceDelegate.updateLimboDocument(i,f))}),c.push(aw(i,o,e.documentUpdates).next(f=>{l=f.cs,h=f.ls})),!r.isEqual(G.min())){const f=t.Qr.getLastRemoteSnapshotVersion(i).next(m=>t.Qr.setTargetsMetadata(i,i.currentSequenceNumber,r));c.push(f)}return A.waitFor(c).next(()=>o.apply(i)).next(()=>t.localDocuments.getLocalViewOfDocuments(i,l,h)).next(()=>l)}).then(i=>(t.ns=s,i))}function aw(n,e,t){let r=ee(),s=ee();return t.forEach(i=>r=r.add(i)),e.getEntries(n,r).next(i=>{let o=Xe();return t.forEach((c,l)=>{const h=i.get(c);l.isFoundDocument()!==h.isFoundDocument()&&(s=s.add(c)),l.isNoDocument()&&l.version.isEqual(G.min())?(e.removeEntry(c,l.readTime),o=o.insert(c,l)):!h.isValidDocument()||l.version.compareTo(h.version)>0||l.version.compareTo(h.version)===0&&h.hasPendingWrites?(e.addEntry(l),o=o.insert(c,l)):k("LocalStore","Ignoring outdated watch update for ",c,". Current version:",h.version," Watch version:",l.version)}),{cs:o,ls:s}})}function cw(n,e){const t=B(n);return t.persistence.runTransaction("Get next mutation batch","readonly",r=>(e===void 0&&(e=-1),t.mutationQueue.getNextMutationBatchAfterBatchId(r,e)))}function Yi(n,e){const t=B(n);return t.persistence.runTransaction("Allocate target","readwrite",r=>{let s;return t.Qr.getTargetData(r,e).next(i=>i?(s=i,A.resolve(s)):t.Qr.allocateTargetId(r).next(o=>(s=new Rt(e,o,"TargetPurposeListen",r.currentSequenceNumber),t.Qr.addTargetData(r,s).next(()=>s))))}).then(r=>{const s=t.ns.get(r.targetId);return(s===null||r.snapshotVersion.compareTo(s.snapshotVersion)>0)&&(t.ns=t.ns.insert(r.targetId,r),t.rs.set(e,r.targetId)),r})}async function vr(n,e,t){const r=B(n),s=r.ns.get(e),i=t?"readwrite":"readwrite-primary";try{t||await r.persistence.runTransaction("Release target",i,o=>r.persistence.referenceDelegate.removeTarget(o,s))}catch(o){if(!cn(o))throw o;k("LocalStore",`Failed to update sequence numbers for target ${e}: ${o}`)}r.ns=r.ns.remove(e),r.rs.delete(s.target)}function Ya(n,e,t){const r=B(n);let s=G.min(),i=ee();return r.persistence.runTransaction("Execute query","readwrite",o=>function(l,h,f){const m=B(l),I=m.rs.get(f);return I!==void 0?A.resolve(m.ns.get(I)):m.Qr.getTargetData(h,f)}(r,o,et(e)).next(c=>{if(c)return s=c.lastLimboFreeSnapshotVersion,r.Qr.getMatchingKeysForTargetId(o,c.targetId).next(l=>{i=l})}).next(()=>r.ts.getDocumentsMatchingQuery(o,e,t?s:G.min(),t?i:ee())).next(c=>(Rp(r,xf(e),c),{documents:c,hs:i})))}function Ap(n,e){const t=B(n),r=B(t.Qr),s=t.ns.get(e);return s?Promise.resolve(s.target):t.persistence.runTransaction("Get target data","readonly",i=>r.ot(i,e).next(o=>o?o.target:null))}function Sp(n,e){const t=B(n),r=t.ss.get(e)||G.min();return t.persistence.runTransaction("Get new document changes","readonly",s=>t.os.getAllFromCollectionGroup(s,e,uf(r,-1),Number.MAX_SAFE_INTEGER)).then(s=>(Rp(t,e,s),s))}function Rp(n,e,t){let r=n.ss.get(e)||G.min();t.forEach((s,i)=>{i.readTime.compareTo(r)>0&&(r=i.readTime)}),n.ss.set(e,r)}function Dh(n,e){return`firestore_clients_${n}_${e}`}function Vh(n,e,t){let r=`firestore_mutations_${n}_${t}`;return e.isAuthenticated()&&(r+=`_${e.uid}`),r}function va(n,e){return`firestore_targets_${n}_${e}`}class Xi{constructor(e,t,r,s){this.user=e,this.batchId=t,this.state=r,this.error=s}static Es(e,t,r){const s=JSON.parse(r);let i,o=typeof s=="object"&&["pending","acknowledged","rejected"].indexOf(s.state)!==-1&&(s.error===void 0||typeof s.error=="object");return o&&s.error&&(o=typeof s.error.message=="string"&&typeof s.error.code=="string",o&&(i=new $(s.error.code,s.error.message))),o?new Xi(e,t,s.state,i):(ve("SharedClientState",`Failed to parse mutation state for ID '${t}': ${r}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class _s{constructor(e,t,r){this.targetId=e,this.state=t,this.error=r}static Es(e,t){const r=JSON.parse(t);let s,i=typeof r=="object"&&["not-current","current","rejected"].indexOf(r.state)!==-1&&(r.error===void 0||typeof r.error=="object");return i&&r.error&&(i=typeof r.error.message=="string"&&typeof r.error.code=="string",i&&(s=new $(r.error.code,r.error.message))),i?new _s(e,r.state,s):(ve("SharedClientState",`Failed to parse target state for ID '${e}': ${t}`),null)}ds(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class Zi{constructor(e,t){this.clientId=e,this.activeTargetIds=t}static Es(e,t){const r=JSON.parse(t);let s=typeof r=="object"&&r.activeTargetIds instanceof Array,i=Ac();for(let o=0;s&&o<r.activeTargetIds.length;++o)s=mf(r.activeTargetIds[o]),i=i.add(r.activeTargetIds[o]);return s?new Zi(e,i):(ve("SharedClientState",`Failed to parse client data for instance '${e}': ${t}`),null)}}class Mc{constructor(e,t){this.clientId=e,this.onlineState=t}static Es(e){const t=JSON.parse(e);return typeof t=="object"&&["Unknown","Online","Offline"].indexOf(t.onlineState)!==-1&&typeof t.clientId=="string"?new Mc(t.clientId,t.onlineState):(ve("SharedClientState",`Failed to parse online state: ${e}`),null)}}class Xa{constructor(){this.activeTargetIds=Ac()}As(e){this.activeTargetIds=this.activeTargetIds.add(e)}Rs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}ds(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class Ia{constructor(e,t,r,s,i){this.window=e,this.oi=t,this.persistenceKey=r,this.Vs=s,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.fs=this.gs.bind(this),this.ps=new he(Y),this.started=!1,this.ys=[];const o=r.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=i,this.ws=Dh(this.persistenceKey,this.Vs),this.Ss=function(l){return`firestore_sequence_number_${l}`}(this.persistenceKey),this.ps=this.ps.insert(this.Vs,new Xa),this.bs=new RegExp(`^firestore_clients_${o}_([^_]*)$`),this.Ds=new RegExp(`^firestore_mutations_${o}_(\\d+)(?:_(.*))?$`),this.Cs=new RegExp(`^firestore_targets_${o}_(\\d+)$`),this.vs=function(l){return`firestore_online_state_${l}`}(this.persistenceKey),this.Fs=function(l){return`firestore_bundle_loaded_v2_${l}`}(this.persistenceKey),this.window.addEventListener("storage",this.fs)}static D(e){return!(!e||!e.localStorage)}async start(){const e=await this.syncEngine.Bi();for(const r of e){if(r===this.Vs)continue;const s=this.getItem(Dh(this.persistenceKey,r));if(s){const i=Zi.Es(r,s);i&&(this.ps=this.ps.insert(i.clientId,i))}}this.Ms();const t=this.storage.getItem(this.vs);if(t){const r=this.xs(t);r&&this.Os(r)}for(const r of this.ys)this.gs(r);this.ys=[],this.window.addEventListener("pagehide",()=>this.shutdown()),this.started=!0}writeSequenceNumber(e){this.setItem(this.Ss,JSON.stringify(e))}getAllActiveQueryTargets(){return this.Ns(this.ps)}isActiveQueryTarget(e){let t=!1;return this.ps.forEach((r,s)=>{s.activeTargetIds.has(e)&&(t=!0)}),t}addPendingMutation(e){this.Ls(e,"pending")}updateMutationState(e,t,r){this.Ls(e,t,r),this.Bs(e)}addLocalQueryTarget(e){let t="not-current";if(this.isActiveQueryTarget(e)){const r=this.storage.getItem(va(this.persistenceKey,e));if(r){const s=_s.Es(e,r);s&&(t=s.state)}}return this.ks.As(e),this.Ms(),t}removeLocalQueryTarget(e){this.ks.Rs(e),this.Ms()}isLocalQueryTarget(e){return this.ks.activeTargetIds.has(e)}clearQueryState(e){this.removeItem(va(this.persistenceKey,e))}updateQueryState(e,t,r){this.qs(e,t,r)}handleUserChange(e,t,r){t.forEach(s=>{this.Bs(s)}),this.currentUser=e,r.forEach(s=>{this.addPendingMutation(s)})}setOnlineState(e){this.Qs(e)}notifyBundleLoaded(e){this.Ks(e)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.fs),this.removeItem(this.ws),this.started=!1)}getItem(e){const t=this.storage.getItem(e);return k("SharedClientState","READ",e,t),t}setItem(e,t){k("SharedClientState","SET",e,t),this.storage.setItem(e,t)}removeItem(e){k("SharedClientState","REMOVE",e),this.storage.removeItem(e)}gs(e){const t=e;if(t.storageArea===this.storage){if(k("SharedClientState","EVENT",t.key,t.newValue),t.key===this.ws)return void ve("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.oi.enqueueRetryable(async()=>{if(this.started){if(t.key!==null){if(this.bs.test(t.key)){if(t.newValue==null){const r=this.$s(t.key);return this.Us(r,null)}{const r=this.Ws(t.key,t.newValue);if(r)return this.Us(r.clientId,r)}}else if(this.Ds.test(t.key)){if(t.newValue!==null){const r=this.Gs(t.key,t.newValue);if(r)return this.zs(r)}}else if(this.Cs.test(t.key)){if(t.newValue!==null){const r=this.js(t.key,t.newValue);if(r)return this.Hs(r)}}else if(t.key===this.vs){if(t.newValue!==null){const r=this.xs(t.newValue);if(r)return this.Os(r)}}else if(t.key===this.Ss){const r=function(i){let o=We.oe;if(i!=null)try{const c=JSON.parse(i);j(typeof c=="number"),o=c}catch(c){ve("SharedClientState","Failed to read sequence number from WebStorage",c)}return o}(t.newValue);r!==We.oe&&this.sequenceNumberHandler(r)}else if(t.key===this.Fs){const r=this.Js(t.newValue);await Promise.all(r.map(s=>this.syncEngine.Ys(s)))}}}else this.ys.push(t)})}}get ks(){return this.ps.get(this.Vs)}Ms(){this.setItem(this.ws,this.ks.ds())}Ls(e,t,r){const s=new Xi(this.currentUser,e,t,r),i=Vh(this.persistenceKey,this.currentUser,e);this.setItem(i,s.ds())}Bs(e){const t=Vh(this.persistenceKey,this.currentUser,e);this.removeItem(t)}Qs(e){const t={clientId:this.Vs,onlineState:e};this.storage.setItem(this.vs,JSON.stringify(t))}qs(e,t,r){const s=va(this.persistenceKey,e),i=new _s(e,t,r);this.setItem(s,i.ds())}Ks(e){const t=JSON.stringify(Array.from(e));this.setItem(this.Fs,t)}$s(e){const t=this.bs.exec(e);return t?t[1]:null}Ws(e,t){const r=this.$s(e);return Zi.Es(r,t)}Gs(e,t){const r=this.Ds.exec(e),s=Number(r[1]),i=r[2]!==void 0?r[2]:null;return Xi.Es(new Le(i),s,t)}js(e,t){const r=this.Cs.exec(e),s=Number(r[1]);return _s.Es(s,t)}xs(e){return Mc.Es(e)}Js(e){return JSON.parse(e)}async zs(e){if(e.user.uid===this.currentUser.uid)return this.syncEngine.Zs(e.batchId,e.state,e.error);k("SharedClientState",`Ignoring mutation for non-active user ${e.user.uid}`)}Hs(e){return this.syncEngine.Xs(e.targetId,e.state,e.error)}Us(e,t){const r=t?this.ps.insert(e,t):this.ps.remove(e),s=this.Ns(this.ps),i=this.Ns(r),o=[],c=[];return i.forEach(l=>{s.has(l)||o.push(l)}),s.forEach(l=>{i.has(l)||c.push(l)}),this.syncEngine.eo(o,c).then(()=>{this.ps=r})}Os(e){this.ps.get(e.clientId)&&this.onlineStateHandler(e.onlineState)}Ns(e){let t=Ac();return e.forEach((r,s)=>{t=t.unionWith(s.activeTargetIds)}),t}}class Pp{constructor(){this.no=new Xa,this.ro={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,r){}addLocalQueryTarget(e){return this.no.As(e),this.ro[e]||"not-current"}updateQueryState(e,t,r){this.ro[e]=t}removeLocalQueryTarget(e){this.no.Rs(e)}isLocalQueryTarget(e){return this.no.activeTargetIds.has(e)}clearQueryState(e){delete this.ro[e]}getAllActiveQueryTargets(){return this.no.activeTargetIds}isActiveQueryTarget(e){return this.no.activeTargetIds.has(e)}start(){return this.no=new Xa,Promise.resolve()}handleUserChange(e,t,r){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lw{io(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nh{constructor(){this.so=()=>this.oo(),this._o=()=>this.ao(),this.uo=[],this.co()}io(e){this.uo.push(e)}shutdown(){window.removeEventListener("online",this.so),window.removeEventListener("offline",this._o)}co(){window.addEventListener("online",this.so),window.addEventListener("offline",this._o)}oo(){k("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const e of this.uo)e(0)}ao(){k("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const e of this.uo)e(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let gi=null;function Ea(){return gi===null?gi=function(){return 268435456+Math.round(2147483648*Math.random())}():gi++,"0x"+gi.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uw={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hw{constructor(e){this.lo=e.lo,this.ho=e.ho}Po(e){this.Io=e}To(e){this.Eo=e}Ao(e){this.Ro=e}onMessage(e){this.Vo=e}close(){this.ho()}send(e){this.lo(e)}mo(){this.Io()}fo(){this.Eo()}po(e){this.Ro(e)}yo(e){this.Vo(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Me="WebChannelConnection";class dw extends class{constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const r=t.ssl?"https":"http",s=encodeURIComponent(this.databaseId.projectId),i=encodeURIComponent(this.databaseId.database);this.wo=r+"://"+t.host,this.So=`projects/${s}/databases/${i}`,this.bo=this.databaseId.database==="(default)"?`project_id=${s}`:`project_id=${s}&database_id=${i}`}get Do(){return!1}Co(t,r,s,i,o){const c=Ea(),l=this.vo(t,r.toUriEncodedString());k("RestConnection",`Sending RPC '${t}' ${c}:`,l,s);const h={"google-cloud-resource-prefix":this.So,"x-goog-request-params":this.bo};return this.Fo(h,i,o),this.Mo(t,l,h,s).then(f=>(k("RestConnection",`Received RPC '${t}' ${c}: `,f),f),f=>{throw Ts("RestConnection",`RPC '${t}' ${c} failed with error: `,f,"url: ",l,"request:",s),f})}xo(t,r,s,i,o,c){return this.Co(t,r,s,i,o)}Fo(t,r,s){t["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Vr}(),t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),r&&r.headers.forEach((i,o)=>t[o]=i),s&&s.headers.forEach((i,o)=>t[o]=i)}vo(t,r){const s=uw[t];return`${this.wo}/v1/${r}:${s}`}terminate(){}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}Mo(e,t,r,s){const i=Ea();return new Promise((o,c)=>{const l=new tf;l.setWithCredentials(!0),l.listenOnce(rf.COMPLETE,()=>{try{switch(l.getLastErrorCode()){case Ti.NO_ERROR:const f=l.getResponseJson();k(Me,`XHR for RPC '${e}' ${i} received:`,JSON.stringify(f)),o(f);break;case Ti.TIMEOUT:k(Me,`RPC '${e}' ${i} timed out`),c(new $(C.DEADLINE_EXCEEDED,"Request time out"));break;case Ti.HTTP_ERROR:const m=l.getStatus();if(k(Me,`RPC '${e}' ${i} failed with status:`,m,"response text:",l.getResponseText()),m>0){let I=l.getResponseJson();Array.isArray(I)&&(I=I[0]);const S=I==null?void 0:I.error;if(S&&S.status&&S.message){const D=function(P){const H=P.toLowerCase().replace(/_/g,"-");return Object.values(C).indexOf(H)>=0?H:C.UNKNOWN}(S.status);c(new $(D,S.message))}else c(new $(C.UNKNOWN,"Server responded with status "+l.getStatus()))}else c(new $(C.UNAVAILABLE,"Connection failed."));break;default:U()}}finally{k(Me,`RPC '${e}' ${i} completed.`)}});const h=JSON.stringify(s);k(Me,`RPC '${e}' ${i} sending request:`,s),l.send(t,"POST",h,r,15)})}Oo(e,t,r){const s=Ea(),i=[this.wo,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=af(),c=of(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},h=this.longPollingOptions.timeoutSeconds;h!==void 0&&(l.longPollingTimeout=Math.round(1e3*h)),this.useFetchStreams&&(l.xmlHttpFactory=new nf({})),this.Fo(l.initMessageHeaders,t,r),l.encodeInitMessageHeaders=!0;const f=i.join("");k(Me,`Creating RPC '${e}' stream ${s}: ${f}`,l);const m=o.createWebChannel(f,l);let I=!1,S=!1;const D=new hw({lo:P=>{S?k(Me,`Not sending because RPC '${e}' stream ${s} is closed:`,P):(I||(k(Me,`Opening RPC '${e}' stream ${s} transport.`),m.open(),I=!0),k(Me,`RPC '${e}' stream ${s} sending:`,P),m.send(P))},ho:()=>m.close()}),N=(P,H,K)=>{P.listen(H,q=>{try{K(q)}catch(X){setTimeout(()=>{throw X},0)}})};return N(m,os.EventType.OPEN,()=>{S||(k(Me,`RPC '${e}' stream ${s} transport opened.`),D.mo())}),N(m,os.EventType.CLOSE,()=>{S||(S=!0,k(Me,`RPC '${e}' stream ${s} transport closed`),D.po())}),N(m,os.EventType.ERROR,P=>{S||(S=!0,Ts(Me,`RPC '${e}' stream ${s} transport errored:`,P),D.po(new $(C.UNAVAILABLE,"The operation could not be completed")))}),N(m,os.EventType.MESSAGE,P=>{var H;if(!S){const K=P.data[0];j(!!K);const q=K,X=q.error||((H=q[0])===null||H===void 0?void 0:H.error);if(X){k(Me,`RPC '${e}' stream ${s} received error:`,X);const V=X.status;let M=function(_){const E=Ie[_];if(E!==void 0)return Hf(E)}(V),v=X.message;M===void 0&&(M=C.INTERNAL,v="Unknown error status: "+V+" with message "+X.message),S=!0,D.po(new $(M,v)),m.close()}else k(Me,`RPC '${e}' stream ${s} received:`,K),D.yo(K)}}),N(c,sf.STAT_EVENT,P=>{P.stat===Oa.PROXY?k(Me,`RPC '${e}' stream ${s} detected buffering proxy`):P.stat===Oa.NOPROXY&&k(Me,`RPC '${e}' stream ${s} detected no buffering proxy`)}),setTimeout(()=>{D.fo()},0),D}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cp(){return typeof window<"u"?window:null}function ki(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function So(n){return new EE(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kp{constructor(e,t,r=1e3,s=1.5,i=6e4){this.oi=e,this.timerId=t,this.No=r,this.Lo=s,this.Bo=i,this.ko=0,this.qo=null,this.Qo=Date.now(),this.reset()}reset(){this.ko=0}Ko(){this.ko=this.Bo}$o(e){this.cancel();const t=Math.floor(this.ko+this.Uo()),r=Math.max(0,Date.now()-this.Qo),s=Math.max(0,t-r);s>0&&k("ExponentialBackoff",`Backing off for ${s} ms (base delay: ${this.ko} ms, delay with jitter: ${t} ms, last attempt: ${r} ms ago)`),this.qo=this.oi.enqueueAfterDelay(this.timerId,s,()=>(this.Qo=Date.now(),e())),this.ko*=this.Lo,this.ko<this.No&&(this.ko=this.No),this.ko>this.Bo&&(this.ko=this.Bo)}Wo(){this.qo!==null&&(this.qo.skipDelay(),this.qo=null)}cancel(){this.qo!==null&&(this.qo.cancel(),this.qo=null)}Uo(){return(Math.random()-.5)*this.ko}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dp{constructor(e,t,r,s,i,o,c,l){this.oi=e,this.Go=r,this.zo=s,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=c,this.listener=l,this.state=0,this.jo=0,this.Ho=null,this.Jo=null,this.stream=null,this.Yo=new kp(e,t)}Zo(){return this.state===1||this.state===5||this.Xo()}Xo(){return this.state===2||this.state===3}start(){this.state!==4?this.auth():this.e_()}async stop(){this.Zo()&&await this.close(0)}t_(){this.state=0,this.Yo.reset()}n_(){this.Xo()&&this.Ho===null&&(this.Ho=this.oi.enqueueAfterDelay(this.Go,6e4,()=>this.r_()))}i_(e){this.s_(),this.stream.send(e)}async r_(){if(this.Xo())return this.close(0)}s_(){this.Ho&&(this.Ho.cancel(),this.Ho=null)}o_(){this.Jo&&(this.Jo.cancel(),this.Jo=null)}async close(e,t){this.s_(),this.o_(),this.Yo.cancel(),this.jo++,e!==4?this.Yo.reset():t&&t.code===C.RESOURCE_EXHAUSTED?(ve(t.toString()),ve("Using maximum backoff delay to prevent overloading the backend."),this.Yo.Ko()):t&&t.code===C.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.__(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Ao(t)}__(){}auth(){this.state=1;const e=this.a_(this.jo),t=this.jo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,s])=>{this.jo===t&&this.u_(r,s)},r=>{e(()=>{const s=new $(C.UNKNOWN,"Fetching auth token failed: "+r.message);return this.c_(s)})})}u_(e,t){const r=this.a_(this.jo);this.stream=this.l_(e,t),this.stream.Po(()=>{r(()=>this.listener.Po())}),this.stream.To(()=>{r(()=>(this.state=2,this.Jo=this.oi.enqueueAfterDelay(this.zo,1e4,()=>(this.Xo()&&(this.state=3),Promise.resolve())),this.listener.To()))}),this.stream.Ao(s=>{r(()=>this.c_(s))}),this.stream.onMessage(s=>{r(()=>this.onMessage(s))})}e_(){this.state=5,this.Yo.$o(async()=>{this.state=0,this.start()})}c_(e){return k("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}a_(e){return t=>{this.oi.enqueueAndForget(()=>this.jo===e?t():(k("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class fw extends Dp{constructor(e,t,r,s,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,r,s,o),this.serializer=i}l_(e,t){return this.connection.Oo("Listen",e,t)}onMessage(e){this.Yo.reset();const t=bE(this.serializer,e),r=function(i){if(!("targetChange"in i))return G.min();const o=i.targetChange;return o.targetIds&&o.targetIds.length?G.min():o.readTime?Ge(o.readTime):G.min()}(e);return this.listener.h_(t,r)}P_(e){const t={};t.database=Ka(this.serializer),t.addTarget=function(i,o){let c;const l=o.target;if(c=Gi(l)?{documents:np(i,l)}:{query:rp(i,l)._t},c.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){c.resumeToken=Yf(i,o.resumeToken);const h=Ga(i,o.expectedCount);h!==null&&(c.expectedCount=h)}else if(o.snapshotVersion.compareTo(G.min())>0){c.readTime=yr(i,o.snapshotVersion.toTimestamp());const h=Ga(i,o.expectedCount);h!==null&&(c.expectedCount=h)}return c}(this.serializer,e);const r=SE(this.serializer,e);r&&(t.labels=r),this.i_(t)}I_(e){const t={};t.database=Ka(this.serializer),t.removeTarget=e,this.i_(t)}}class pw extends Dp{constructor(e,t,r,s,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,r,s,o),this.serializer=i,this.T_=!1}get E_(){return this.T_}start(){this.T_=!1,this.lastStreamToken=void 0,super.start()}__(){this.T_&&this.d_([])}l_(e,t){return this.connection.Oo("Write",e,t)}onMessage(e){if(j(!!e.streamToken),this.lastStreamToken=e.streamToken,this.T_){this.Yo.reset();const t=AE(e.writeResults,e.commitTime),r=Ge(e.commitTime);return this.listener.A_(r,t)}return j(!e.writeResults||e.writeResults.length===0),this.T_=!0,this.listener.R_()}V_(){const e={};e.database=Ka(this.serializer),this.i_(e)}d_(e){const t={streamToken:this.lastStreamToken,writes:e.map(r=>Wi(this.serializer,r))};this.i_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mw extends class{}{constructor(e,t,r,s){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=r,this.serializer=s,this.m_=!1}f_(){if(this.m_)throw new $(C.FAILED_PRECONDITION,"The client has already been terminated.")}Co(e,t,r,s){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,o])=>this.connection.Co(e,za(t,r),s,i,o)).catch(i=>{throw i.name==="FirebaseError"?(i.code===C.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new $(C.UNKNOWN,i.toString())})}xo(e,t,r,s,i){return this.f_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,c])=>this.connection.xo(e,za(t,r),s,o,c,i)).catch(o=>{throw o.name==="FirebaseError"?(o.code===C.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new $(C.UNKNOWN,o.toString())})}terminate(){this.m_=!0,this.connection.terminate()}}class gw{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.g_=0,this.p_=null,this.y_=!0}w_(){this.g_===0&&(this.S_("Unknown"),this.p_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.p_=null,this.b_("Backend didn't respond within 10 seconds."),this.S_("Offline"),Promise.resolve())))}D_(e){this.state==="Online"?this.S_("Unknown"):(this.g_++,this.g_>=1&&(this.C_(),this.b_(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.S_("Offline")))}set(e){this.C_(),this.g_=0,e==="Online"&&(this.y_=!1),this.S_(e)}S_(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}b_(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.y_?(ve(t),this.y_=!1):k("OnlineStateTracker",t)}C_(){this.p_!==null&&(this.p_.cancel(),this.p_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _w{constructor(e,t,r,s,i){this.localStore=e,this.datastore=t,this.asyncQueue=r,this.remoteSyncer={},this.v_=[],this.F_=new Map,this.M_=new Set,this.x_=[],this.O_=i,this.O_.io(o=>{r.enqueueAndForget(async()=>{jn(this)&&(k("RemoteStore","Restarting streams for network reachability change."),await async function(l){const h=B(l);h.M_.add(4),await Gs(h),h.N_.set("Unknown"),h.M_.delete(4),await Ro(h)}(this))})}),this.N_=new gw(r,s)}}async function Ro(n){if(jn(n))for(const e of n.x_)await e(!0)}async function Gs(n){for(const e of n.x_)await e(!1)}function Po(n,e){const t=B(n);t.F_.has(e.targetId)||(t.F_.set(e.targetId,e),$c(t)?Fc(t):Or(t).Xo()&&Lc(t,e))}function Ir(n,e){const t=B(n),r=Or(t);t.F_.delete(e),r.Xo()&&Vp(t,e),t.F_.size===0&&(r.Xo()?r.n_():jn(t)&&t.N_.set("Unknown"))}function Lc(n,e){if(n.L_.xe(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(G.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}Or(n).P_(e)}function Vp(n,e){n.L_.xe(e),Or(n).I_(e)}function Fc(n){n.L_=new _E({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),ot:e=>n.F_.get(e)||null,tt:()=>n.datastore.serializer.databaseId}),Or(n).start(),n.N_.w_()}function $c(n){return jn(n)&&!Or(n).Zo()&&n.F_.size>0}function jn(n){return B(n).M_.size===0}function Np(n){n.L_=void 0}async function yw(n){n.N_.set("Online")}async function vw(n){n.F_.forEach((e,t)=>{Lc(n,e)})}async function Iw(n,e){Np(n),$c(n)?(n.N_.D_(e),Fc(n)):n.N_.set("Unknown")}async function Ew(n,e,t){if(n.N_.set("Online"),e instanceof Jf&&e.state===2&&e.cause)try{await async function(s,i){const o=i.cause;for(const c of i.targetIds)s.F_.has(c)&&(await s.remoteSyncer.rejectListen(c,o),s.F_.delete(c),s.L_.removeTarget(c))}(n,e)}catch(r){k("RemoteStore","Failed to remove targets %s: %s ",e.targetIds.join(","),r),await eo(n,r)}else if(e instanceof Ci?n.L_.Ke(e):e instanceof Qf?n.L_.He(e):n.L_.We(e),!t.isEqual(G.min()))try{const r=await bp(n.localStore);t.compareTo(r)>=0&&await function(i,o){const c=i.L_.rt(o);return c.targetChanges.forEach((l,h)=>{if(l.resumeToken.approximateByteSize()>0){const f=i.F_.get(h);f&&i.F_.set(h,f.withResumeToken(l.resumeToken,o))}}),c.targetMismatches.forEach((l,h)=>{const f=i.F_.get(l);if(!f)return;i.F_.set(l,f.withResumeToken(Pe.EMPTY_BYTE_STRING,f.snapshotVersion)),Vp(i,l);const m=new Rt(f.target,l,h,f.sequenceNumber);Lc(i,m)}),i.remoteSyncer.applyRemoteEvent(c)}(n,t)}catch(r){k("RemoteStore","Failed to raise snapshot:",r),await eo(n,r)}}async function eo(n,e,t){if(!cn(e))throw e;n.M_.add(1),await Gs(n),n.N_.set("Offline"),t||(t=()=>bp(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{k("RemoteStore","Retrying IndexedDB access"),await t(),n.M_.delete(1),await Ro(n)})}function xp(n,e){return e().catch(t=>eo(n,t,e))}async function xr(n){const e=B(n),t=rn(e);let r=e.v_.length>0?e.v_[e.v_.length-1].batchId:-1;for(;ww(e);)try{const s=await cw(e.localStore,r);if(s===null){e.v_.length===0&&t.n_();break}r=s.batchId,Tw(e,s)}catch(s){await eo(e,s)}Op(e)&&Mp(e)}function ww(n){return jn(n)&&n.v_.length<10}function Tw(n,e){n.v_.push(e);const t=rn(n);t.Xo()&&t.E_&&t.d_(e.mutations)}function Op(n){return jn(n)&&!rn(n).Zo()&&n.v_.length>0}function Mp(n){rn(n).start()}async function bw(n){rn(n).V_()}async function Aw(n){const e=rn(n);for(const t of n.v_)e.d_(t.mutations)}async function Sw(n,e,t){const r=n.v_.shift(),s=Rc.from(r,e,t);await xp(n,()=>n.remoteSyncer.applySuccessfulWrite(s)),await xr(n)}async function Rw(n,e){e&&rn(n).E_&&await async function(r,s){if(function(o){return pE(o)&&o!==C.ABORTED}(s.code)){const i=r.v_.shift();rn(r).t_(),await xp(r,()=>r.remoteSyncer.rejectFailedWrite(i.batchId,s)),await xr(r)}}(n,e),Op(n)&&Mp(n)}async function xh(n,e){const t=B(n);t.asyncQueue.verifyOperationInProgress(),k("RemoteStore","RemoteStore received new credentials");const r=jn(t);t.M_.add(3),await Gs(t),r&&t.N_.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.M_.delete(3),await Ro(t)}async function Za(n,e){const t=B(n);e?(t.M_.delete(2),await Ro(t)):e||(t.M_.add(2),await Gs(t),t.N_.set("Unknown"))}function Or(n){return n.B_||(n.B_=function(t,r,s){const i=B(t);return i.f_(),new fw(r,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)}(n.datastore,n.asyncQueue,{Po:yw.bind(null,n),To:vw.bind(null,n),Ao:Iw.bind(null,n),h_:Ew.bind(null,n)}),n.x_.push(async e=>{e?(n.B_.t_(),$c(n)?Fc(n):n.N_.set("Unknown")):(await n.B_.stop(),Np(n))})),n.B_}function rn(n){return n.k_||(n.k_=function(t,r,s){const i=B(t);return i.f_(),new pw(r,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)}(n.datastore,n.asyncQueue,{Po:()=>Promise.resolve(),To:bw.bind(null,n),Ao:Rw.bind(null,n),R_:Aw.bind(null,n),A_:Sw.bind(null,n)}),n.x_.push(async e=>{e?(n.k_.t_(),await xr(n)):(await n.k_.stop(),n.v_.length>0&&(k("RemoteStore",`Stopping write stream with ${n.v_.length} pending writes`),n.v_=[]))})),n.k_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uc{constructor(e,t,r,s,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=r,this.op=s,this.removalCallback=i,this.deferred=new Jt,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,r,s,i){const o=Date.now()+r,c=new Uc(e,t,o,s,i);return c.start(r),c}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new $(C.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Bc(n,e){if(ve("AsyncQueue",`${e}: ${n}`),cn(n))return new $(C.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cr{constructor(e){this.comparator=e?(t,r)=>e(t,r)||F.comparator(t.key,r.key):(t,r)=>F.comparator(t.key,r.key),this.keyedMap=as(),this.sortedSet=new he(this.comparator)}static emptySet(e){return new cr(e.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,r)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof cr)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),r=e.sortedSet.getIterator();for(;t.hasNext();){const s=t.getNext().key,i=r.getNext().key;if(!s.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const r=new cr;return r.comparator=this.comparator,r.keyedMap=e,r.sortedSet=t,r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oh{constructor(){this.q_=new he(F.comparator)}track(e){const t=e.doc.key,r=this.q_.get(t);r?e.type!==0&&r.type===3?this.q_=this.q_.insert(t,e):e.type===3&&r.type!==1?this.q_=this.q_.insert(t,{type:r.type,doc:e.doc}):e.type===2&&r.type===2?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):e.type===2&&r.type===0?this.q_=this.q_.insert(t,{type:0,doc:e.doc}):e.type===1&&r.type===0?this.q_=this.q_.remove(t):e.type===1&&r.type===2?this.q_=this.q_.insert(t,{type:1,doc:r.doc}):e.type===0&&r.type===1?this.q_=this.q_.insert(t,{type:2,doc:e.doc}):U():this.q_=this.q_.insert(t,e)}Q_(){const e=[];return this.q_.inorderTraversal((t,r)=>{e.push(r)}),e}}class Er{constructor(e,t,r,s,i,o,c,l,h){this.query=e,this.docs=t,this.oldDocs=r,this.docChanges=s,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=c,this.excludesMetadataChanges=l,this.hasCachedResults=h}static fromInitialDocuments(e,t,r,s,i){const o=[];return t.forEach(c=>{o.push({type:0,doc:c})}),new Er(e,t,cr.emptySet(t),o,r,s,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&vo(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,r=e.docChanges;if(t.length!==r.length)return!1;for(let s=0;s<t.length;s++)if(t[s].type!==r[s].type||!t[s].doc.isEqual(r[s].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pw{constructor(){this.K_=void 0,this.U_=[]}W_(){return this.U_.some(e=>e.G_())}}class Cw{constructor(){this.queries=new ln(e=>Nf(e),vo),this.onlineState="Unknown",this.z_=new Set}}async function kw(n,e){const t=B(n);let r=3;const s=e.query;let i=t.queries.get(s);i?!i.W_()&&e.G_()&&(r=2):(i=new Pw,r=e.G_()?0:1);try{switch(r){case 0:i.K_=await t.onListen(s,!0);break;case 1:i.K_=await t.onListen(s,!1);break;case 2:await t.onFirstRemoteStoreListen(s)}}catch(o){const c=Bc(o,`Initialization of query '${er(e.query)}' failed`);return void e.onError(c)}t.queries.set(s,i),i.U_.push(e),e.j_(t.onlineState),i.K_&&e.H_(i.K_)&&qc(t)}async function Dw(n,e){const t=B(n),r=e.query;let s=3;const i=t.queries.get(r);if(i){const o=i.U_.indexOf(e);o>=0&&(i.U_.splice(o,1),i.U_.length===0?s=e.G_()?0:1:!i.W_()&&e.G_()&&(s=2))}switch(s){case 0:return t.queries.delete(r),t.onUnlisten(r,!0);case 1:return t.queries.delete(r),t.onUnlisten(r,!1);case 2:return t.onLastRemoteStoreUnlisten(r);default:return}}function Vw(n,e){const t=B(n);let r=!1;for(const s of e){const i=s.query,o=t.queries.get(i);if(o){for(const c of o.U_)c.H_(s)&&(r=!0);o.K_=s}}r&&qc(t)}function Nw(n,e,t){const r=B(n),s=r.queries.get(e);if(s)for(const i of s.U_)i.onError(t);r.queries.delete(e)}function qc(n){n.z_.forEach(e=>{e.next()})}var ec,Mh;(Mh=ec||(ec={})).J_="default",Mh.Cache="cache";class xw{constructor(e,t,r){this.query=e,this.Y_=t,this.Z_=!1,this.X_=null,this.onlineState="Unknown",this.options=r||{}}H_(e){if(!this.options.includeMetadataChanges){const r=[];for(const s of e.docChanges)s.type!==3&&r.push(s);e=new Er(e.query,e.docs,e.oldDocs,r,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Z_?this.ea(e)&&(this.Y_.next(e),t=!0):this.ta(e,this.onlineState)&&(this.na(e),t=!0),this.X_=e,t}onError(e){this.Y_.error(e)}j_(e){this.onlineState=e;let t=!1;return this.X_&&!this.Z_&&this.ta(this.X_,e)&&(this.na(this.X_),t=!0),t}ta(e,t){if(!e.fromCache||!this.G_())return!0;const r=t!=="Offline";return(!this.options.ra||!r)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}ea(e){if(e.docChanges.length>0)return!0;const t=this.X_&&this.X_.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}na(e){e=Er.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Z_=!0,this.Y_.next(e)}G_(){return this.options.source!==ec.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lp{constructor(e){this.key=e}}class Fp{constructor(e){this.key=e}}class Ow{constructor(e,t){this.query=e,this.la=t,this.ha=null,this.hasCachedResults=!1,this.current=!1,this.Pa=ee(),this.mutatedKeys=ee(),this.Ia=Of(e),this.Ta=new cr(this.Ia)}get Ea(){return this.la}da(e,t){const r=t?t.Aa:new Oh,s=t?t.Ta:this.Ta;let i=t?t.mutatedKeys:this.mutatedKeys,o=s,c=!1;const l=this.query.limitType==="F"&&s.size===this.query.limit?s.last():null,h=this.query.limitType==="L"&&s.size===this.query.limit?s.first():null;if(e.inorderTraversal((f,m)=>{const I=s.get(f),S=Bs(this.query,m)?m:null,D=!!I&&this.mutatedKeys.has(I.key),N=!!S&&(S.hasLocalMutations||this.mutatedKeys.has(S.key)&&S.hasCommittedMutations);let P=!1;I&&S?I.data.isEqual(S.data)?D!==N&&(r.track({type:3,doc:S}),P=!0):this.Ra(I,S)||(r.track({type:2,doc:S}),P=!0,(l&&this.Ia(S,l)>0||h&&this.Ia(S,h)<0)&&(c=!0)):!I&&S?(r.track({type:0,doc:S}),P=!0):I&&!S&&(r.track({type:1,doc:I}),P=!0,(l||h)&&(c=!0)),P&&(S?(o=o.add(S),i=N?i.add(f):i.delete(f)):(o=o.delete(f),i=i.delete(f)))}),this.query.limit!==null)for(;o.size>this.query.limit;){const f=this.query.limitType==="F"?o.last():o.first();o=o.delete(f.key),i=i.delete(f.key),r.track({type:1,doc:f})}return{Ta:o,Aa:r,Xi:c,mutatedKeys:i}}Ra(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,r,s){const i=this.Ta;this.Ta=e.Ta,this.mutatedKeys=e.mutatedKeys;const o=e.Aa.Q_();o.sort((f,m)=>function(S,D){const N=P=>{switch(P){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return U()}};return N(S)-N(D)}(f.type,m.type)||this.Ia(f.doc,m.doc)),this.Va(r),s=s!=null&&s;const c=t&&!s?this.ma():[],l=this.Pa.size===0&&this.current&&!s?1:0,h=l!==this.ha;return this.ha=l,o.length!==0||h?{snapshot:new Er(this.query,e.Ta,i,o,e.mutatedKeys,l===0,h,!1,!!r&&r.resumeToken.approximateByteSize()>0),fa:c}:{fa:c}}j_(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Ta:this.Ta,Aa:new Oh,mutatedKeys:this.mutatedKeys,Xi:!1},!1)):{fa:[]}}ga(e){return!this.la.has(e)&&!!this.Ta.has(e)&&!this.Ta.get(e).hasLocalMutations}Va(e){e&&(e.addedDocuments.forEach(t=>this.la=this.la.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.la=this.la.delete(t)),this.current=e.current)}ma(){if(!this.current)return[];const e=this.Pa;this.Pa=ee(),this.Ta.forEach(r=>{this.ga(r.key)&&(this.Pa=this.Pa.add(r.key))});const t=[];return e.forEach(r=>{this.Pa.has(r)||t.push(new Fp(r))}),this.Pa.forEach(r=>{e.has(r)||t.push(new Lp(r))}),t}pa(e){this.la=e.hs,this.Pa=ee();const t=this.da(e.documents);return this.applyChanges(t,!0)}ya(){return Er.fromInitialDocuments(this.query,this.Ta,this.mutatedKeys,this.ha===0,this.hasCachedResults)}}class Mw{constructor(e,t,r){this.query=e,this.targetId=t,this.view=r}}class Lw{constructor(e){this.key=e,this.wa=!1}}class Fw{constructor(e,t,r,s,i,o){this.localStore=e,this.remoteStore=t,this.eventManager=r,this.sharedClientState=s,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.Sa={},this.ba=new ln(c=>Nf(c),vo),this.Da=new Map,this.Ca=new Set,this.va=new he(F.comparator),this.Fa=new Map,this.Ma=new Nc,this.xa={},this.Oa=new Map,this.Na=Ln.Ln(),this.onlineState="Unknown",this.La=void 0}get isPrimaryClient(){return this.La===!0}}async function $w(n,e,t=!0){const r=Co(n);let s;const i=r.ba.get(e);return i?(r.sharedClientState.addLocalQueryTarget(i.targetId),s=i.view.ya()):s=await $p(r,e,t,!0),s}async function Uw(n,e){const t=Co(n);await $p(t,e,!0,!1)}async function $p(n,e,t,r){const s=await Yi(n.localStore,et(e)),i=s.targetId,o=t?n.sharedClientState.addLocalQueryTarget(i):"not-current";let c;return r&&(c=await jc(n,e,i,o==="current",s.resumeToken)),n.isPrimaryClient&&t&&Po(n.remoteStore,s),c}async function jc(n,e,t,r,s){n.Ba=(m,I,S)=>async function(N,P,H,K){let q=P.view.da(H);q.Xi&&(q=await Ya(N.localStore,P.query,!1).then(({documents:v})=>P.view.da(v,q)));const X=K&&K.targetChanges.get(P.targetId),V=K&&K.targetMismatches.get(P.targetId)!=null,M=P.view.applyChanges(q,N.isPrimaryClient,X,V);return tc(N,P.targetId,M.fa),M.snapshot}(n,m,I,S);const i=await Ya(n.localStore,e,!0),o=new Ow(e,i.hs),c=o.da(i.documents),l=js.createSynthesizedTargetChangeForCurrentChange(t,r&&n.onlineState!=="Offline",s),h=o.applyChanges(c,n.isPrimaryClient,l);tc(n,t,h.fa);const f=new Mw(e,t,o);return n.ba.set(e,f),n.Da.has(t)?n.Da.get(t).push(e):n.Da.set(t,[e]),h.snapshot}async function Bw(n,e,t){const r=B(n),s=r.ba.get(e),i=r.Da.get(s.targetId);if(i.length>1)return r.Da.set(s.targetId,i.filter(o=>!vo(o,e))),void r.ba.delete(e);r.isPrimaryClient?(r.sharedClientState.removeLocalQueryTarget(s.targetId),r.sharedClientState.isActiveQueryTarget(s.targetId)||await vr(r.localStore,s.targetId,!1).then(()=>{r.sharedClientState.clearQueryState(s.targetId),t&&Ir(r.remoteStore,s.targetId),wr(r,s.targetId)}).catch(an)):(wr(r,s.targetId),await vr(r.localStore,s.targetId,!0))}async function qw(n,e){const t=B(n),r=t.ba.get(e),s=t.Da.get(r.targetId);t.isPrimaryClient&&s.length===1&&(t.sharedClientState.removeLocalQueryTarget(r.targetId),Ir(t.remoteStore,r.targetId))}async function jw(n,e,t){const r=Wc(n);try{const s=await function(o,c){const l=B(o),h=pe.now(),f=c.reduce((S,D)=>S.add(D.key),ee());let m,I;return l.persistence.runTransaction("Locally write mutations","readwrite",S=>{let D=Xe(),N=ee();return l.os.getEntries(S,f).next(P=>{D=P,D.forEach((H,K)=>{K.isValidDocument()||(N=N.add(H))})}).next(()=>l.localDocuments.getOverlayedDocuments(S,D)).next(P=>{m=P;const H=[];for(const K of c){const q=dE(K,m.get(K.key).overlayedDocument);q!=null&&H.push(new Dt(K.key,q,bf(q.value.mapValue),qe.exists(!0)))}return l.mutationQueue.addMutationBatch(S,h,H,c)}).next(P=>{I=P;const H=P.applyToLocalDocumentSet(m,N);return l.documentOverlayCache.saveOverlays(S,P.batchId,H)})}).then(()=>({batchId:I.batchId,changes:Lf(m)}))}(r.localStore,e);r.sharedClientState.addPendingMutation(s.batchId),function(o,c,l){let h=o.xa[o.currentUser.toKey()];h||(h=new he(Y)),h=h.insert(c,l),o.xa[o.currentUser.toKey()]=h}(r,s.batchId,t),await un(r,s.changes),await xr(r.remoteStore)}catch(s){const i=Bc(s,"Failed to persist write");t.reject(i)}}async function Up(n,e){const t=B(n);try{const r=await ow(t.localStore,e);e.targetChanges.forEach((s,i)=>{const o=t.Fa.get(i);o&&(j(s.addedDocuments.size+s.modifiedDocuments.size+s.removedDocuments.size<=1),s.addedDocuments.size>0?o.wa=!0:s.modifiedDocuments.size>0?j(o.wa):s.removedDocuments.size>0&&(j(o.wa),o.wa=!1))}),await un(t,r,e)}catch(r){await an(r)}}function Lh(n,e,t){const r=B(n);if(r.isPrimaryClient&&t===0||!r.isPrimaryClient&&t===1){const s=[];r.ba.forEach((i,o)=>{const c=o.view.j_(e);c.snapshot&&s.push(c.snapshot)}),function(o,c){const l=B(o);l.onlineState=c;let h=!1;l.queries.forEach((f,m)=>{for(const I of m.U_)I.j_(c)&&(h=!0)}),h&&qc(l)}(r.eventManager,e),s.length&&r.Sa.h_(s),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function Gw(n,e,t){const r=B(n);r.sharedClientState.updateQueryState(e,"rejected",t);const s=r.Fa.get(e),i=s&&s.key;if(i){let o=new he(F.comparator);o=o.insert(i,_e.newNoDocument(i,G.min()));const c=ee().add(i),l=new qs(G.min(),new Map,new he(Y),o,c);await Up(r,l),r.va=r.va.remove(i),r.Fa.delete(e),Kc(r)}else await vr(r.localStore,e,!1).then(()=>wr(r,e,t)).catch(an)}async function zw(n,e){const t=B(n),r=e.batch.batchId;try{const s=await iw(t.localStore,e);zc(t,r,null),Gc(t,r),t.sharedClientState.updateMutationState(r,"acknowledged"),await un(t,s)}catch(s){await an(s)}}async function Kw(n,e,t){const r=B(n);try{const s=await function(o,c){const l=B(o);return l.persistence.runTransaction("Reject batch","readwrite-primary",h=>{let f;return l.mutationQueue.lookupMutationBatch(h,c).next(m=>(j(m!==null),f=m.keys(),l.mutationQueue.removeMutationBatch(h,m))).next(()=>l.mutationQueue.performConsistencyCheck(h)).next(()=>l.documentOverlayCache.removeOverlaysForBatchId(h,f,c)).next(()=>l.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(h,f)).next(()=>l.localDocuments.getDocuments(h,f))})}(r.localStore,e);zc(r,e,t),Gc(r,e),r.sharedClientState.updateMutationState(e,"rejected",t),await un(r,s)}catch(s){await an(s)}}function Gc(n,e){(n.Oa.get(e)||[]).forEach(t=>{t.resolve()}),n.Oa.delete(e)}function zc(n,e,t){const r=B(n);let s=r.xa[r.currentUser.toKey()];if(s){const i=s.get(e);i&&(t?i.reject(t):i.resolve(),s=s.remove(e)),r.xa[r.currentUser.toKey()]=s}}function wr(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const r of n.Da.get(e))n.ba.delete(r),t&&n.Sa.ka(r,t);n.Da.delete(e),n.isPrimaryClient&&n.Ma.Vr(e).forEach(r=>{n.Ma.containsKey(r)||Bp(n,r)})}function Bp(n,e){n.Ca.delete(e.path.canonicalString());const t=n.va.get(e);t!==null&&(Ir(n.remoteStore,t),n.va=n.va.remove(e),n.Fa.delete(t),Kc(n))}function tc(n,e,t){for(const r of t)r instanceof Lp?(n.Ma.addReference(r.key,e),Ww(n,r)):r instanceof Fp?(k("SyncEngine","Document no longer in limbo: "+r.key),n.Ma.removeReference(r.key,e),n.Ma.containsKey(r.key)||Bp(n,r.key)):U()}function Ww(n,e){const t=e.key,r=t.path.canonicalString();n.va.get(t)||n.Ca.has(r)||(k("SyncEngine","New document in limbo: "+t),n.Ca.add(r),Kc(n))}function Kc(n){for(;n.Ca.size>0&&n.va.size<n.maxConcurrentLimboResolutions;){const e=n.Ca.values().next().value;n.Ca.delete(e);const t=new F(ae.fromString(e)),r=n.Na.next();n.Fa.set(r,new Lw(t)),n.va=n.va.insert(t,r),Po(n.remoteStore,new Rt(et(yo(t.path)),r,"TargetPurposeLimboResolution",We.oe))}}async function un(n,e,t){const r=B(n),s=[],i=[],o=[];r.ba.isEmpty()||(r.ba.forEach((c,l)=>{o.push(r.Ba(l,e,t).then(h=>{if((h||t)&&r.isPrimaryClient){const f=h&&!h.fromCache;r.sharedClientState.updateQueryState(l.targetId,f?"current":"not-current")}if(h){s.push(h);const f=Oc.Ki(l.targetId,h);i.push(f)}}))}),await Promise.all(o),r.Sa.h_(s),await async function(l,h){const f=B(l);try{await f.persistence.runTransaction("notifyLocalViewChanges","readwrite",m=>A.forEach(h,I=>A.forEach(I.qi,S=>f.persistence.referenceDelegate.addReference(m,I.targetId,S)).next(()=>A.forEach(I.Qi,S=>f.persistence.referenceDelegate.removeReference(m,I.targetId,S)))))}catch(m){if(!cn(m))throw m;k("LocalStore","Failed to update sequence numbers: "+m)}for(const m of h){const I=m.targetId;if(!m.fromCache){const S=f.ns.get(I),D=S.snapshotVersion,N=S.withLastLimboFreeSnapshotVersion(D);f.ns=f.ns.insert(I,N)}}}(r.localStore,i))}async function Hw(n,e){const t=B(n);if(!t.currentUser.isEqual(e)){k("SyncEngine","User change. New user:",e.toKey());const r=await Tp(t.localStore,e);t.currentUser=e,function(i,o){i.Oa.forEach(c=>{c.forEach(l=>{l.reject(new $(C.CANCELLED,o))})}),i.Oa.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,r.removedBatchIds,r.addedBatchIds),await un(t,r.us)}}function Qw(n,e){const t=B(n),r=t.Fa.get(e);if(r&&r.wa)return ee().add(r.key);{let s=ee();const i=t.Da.get(e);if(!i)return s;for(const o of i){const c=t.ba.get(o);s=s.unionWith(c.view.Ea)}return s}}async function Jw(n,e){const t=B(n),r=await Ya(t.localStore,e.query,!0),s=e.view.pa(r);return t.isPrimaryClient&&tc(t,e.targetId,s.fa),s}async function Yw(n,e){const t=B(n);return Sp(t.localStore,e).then(r=>un(t,r))}async function Xw(n,e,t,r){const s=B(n),i=await function(c,l){const h=B(c),f=B(h.mutationQueue);return h.persistence.runTransaction("Lookup mutation documents","readonly",m=>f.vn(m,l).next(I=>I?h.localDocuments.getDocuments(m,I):A.resolve(null)))}(s.localStore,e);i!==null?(t==="pending"?await xr(s.remoteStore):t==="acknowledged"||t==="rejected"?(zc(s,e,r||null),Gc(s,e),function(c,l){B(B(c).mutationQueue).Mn(l)}(s.localStore,e)):U(),await un(s,i)):k("SyncEngine","Cannot apply mutation batch with id: "+e)}async function Zw(n,e){const t=B(n);if(Co(t),Wc(t),e===!0&&t.La!==!0){const r=t.sharedClientState.getAllActiveQueryTargets(),s=await Fh(t,r.toArray());t.La=!0,await Za(t.remoteStore,!0);for(const i of s)Po(t.remoteStore,i)}else if(e===!1&&t.La!==!1){const r=[];let s=Promise.resolve();t.Da.forEach((i,o)=>{t.sharedClientState.isLocalQueryTarget(o)?r.push(o):s=s.then(()=>(wr(t,o),vr(t.localStore,o,!0))),Ir(t.remoteStore,o)}),await s,await Fh(t,r),function(o){const c=B(o);c.Fa.forEach((l,h)=>{Ir(c.remoteStore,h)}),c.Ma.mr(),c.Fa=new Map,c.va=new he(F.comparator)}(t),t.La=!1,await Za(t.remoteStore,!1)}}async function Fh(n,e,t){const r=B(n),s=[],i=[];for(const o of e){let c;const l=r.Da.get(o);if(l&&l.length!==0){c=await Yi(r.localStore,et(l[0]));for(const h of l){const f=r.ba.get(h),m=await Jw(r,f);m.snapshot&&i.push(m.snapshot)}}else{const h=await Ap(r.localStore,o);c=await Yi(r.localStore,h),await jc(r,qp(h),o,!1,c.resumeToken)}s.push(c)}return r.Sa.h_(i),s}function qp(n){return Vf(n.path,n.collectionGroup,n.orderBy,n.filters,n.limit,"F",n.startAt,n.endAt)}function eT(n){return function(t){return B(B(t).persistence).Bi()}(B(n).localStore)}async function tT(n,e,t,r){const s=B(n);if(s.La)return void k("SyncEngine","Ignoring unexpected query state notification.");const i=s.Da.get(e);if(i&&i.length>0)switch(t){case"current":case"not-current":{const o=await Sp(s.localStore,xf(i[0])),c=qs.createSynthesizedRemoteEventForCurrentChange(e,t==="current",Pe.EMPTY_BYTE_STRING);await un(s,o,c);break}case"rejected":await vr(s.localStore,e,!0),wr(s,e,r);break;default:U()}}async function nT(n,e,t){const r=Co(n);if(r.La){for(const s of e){if(r.Da.has(s)&&r.sharedClientState.isActiveQueryTarget(s)){k("SyncEngine","Adding an already active target "+s);continue}const i=await Ap(r.localStore,s),o=await Yi(r.localStore,i);await jc(r,qp(i),o.targetId,!1,o.resumeToken),Po(r.remoteStore,o)}for(const s of t)r.Da.has(s)&&await vr(r.localStore,s,!1).then(()=>{Ir(r.remoteStore,s),wr(r,s)}).catch(an)}}function Co(n){const e=B(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=Up.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=Qw.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=Gw.bind(null,e),e.Sa.h_=Vw.bind(null,e.eventManager),e.Sa.ka=Nw.bind(null,e.eventManager),e}function Wc(n){const e=B(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=zw.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=Kw.bind(null,e),e}class nc{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=So(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,t){return null}createIndexBackfillerScheduler(e,t){return null}createLocalStore(e){return wp(this.persistence,new Ep,e.initialUser,this.serializer)}createPersistence(e){return new vp(Ao.Hr,this.serializer)}createSharedClientState(e){return new Pp}async terminate(){var e,t;(e=this.gcScheduler)===null||e===void 0||e.stop(),(t=this.indexBackfillerScheduler)===null||t===void 0||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class jp extends nc{constructor(e,t,r){super(),this.Qa=e,this.cacheSizeBytes=t,this.forceOwnership=r,this.synchronizeTabs=!1}async initialize(e){await super.initialize(e),await this.Qa.initialize(this,e),await Wc(this.Qa.syncEngine),await xr(this.Qa.remoteStore),await this.persistence.fi(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}createLocalStore(e){return wp(this.persistence,new Ep,e.initialUser,this.serializer)}createGarbageCollectionScheduler(e,t){const r=this.persistence.referenceDelegate.garbageCollector;return new qE(r,e.asyncQueue,t)}createIndexBackfillerScheduler(e,t){const r=new EI(t,this.persistence);return new II(e.asyncQueue,r)}createPersistence(e){const t=Ip(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey),r=this.cacheSizeBytes!==void 0?Ke.withCacheSize(this.cacheSizeBytes):Ke.DEFAULT;return new xc(this.synchronizeTabs,t,e.clientId,r,e.asyncQueue,Cp(),ki(),this.serializer,this.sharedClientState,!!this.forceOwnership)}createSharedClientState(e){return new Pp}}class rT extends jp{constructor(e,t){super(e,t,!1),this.Qa=e,this.cacheSizeBytes=t,this.synchronizeTabs=!0}async initialize(e){await super.initialize(e);const t=this.Qa.syncEngine;this.sharedClientState instanceof Ia&&(this.sharedClientState.syncEngine={Zs:Xw.bind(null,t),Xs:tT.bind(null,t),eo:nT.bind(null,t),Bi:eT.bind(null,t),Ys:Yw.bind(null,t)},await this.sharedClientState.start()),await this.persistence.fi(async r=>{await Zw(this.Qa.syncEngine,r),this.gcScheduler&&(r&&!this.gcScheduler.started?this.gcScheduler.start():r||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(r&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():r||this.indexBackfillerScheduler.stop())})}createSharedClientState(e){const t=Cp();if(!Ia.D(t))throw new $(C.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const r=Ip(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey);return new Ia(t,e.asyncQueue,r,e.clientId,e.initialUser)}}class Hc{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>Lh(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=Hw.bind(null,this.syncEngine),await Za(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new Cw}()}createDatastore(e){const t=So(e.databaseInfo.databaseId),r=function(i){return new dw(i)}(e.databaseInfo);return function(i,o,c,l){return new mw(i,o,c,l)}(e.authCredentials,e.appCheckCredentials,r,t)}createRemoteStore(e){return function(r,s,i,o,c){return new _w(r,s,i,o,c)}(this.localStore,this.datastore,e.asyncQueue,t=>Lh(this.syncEngine,t,0),function(){return Nh.D()?new Nh:new lw}())}createSyncEngine(e,t){return function(s,i,o,c,l,h,f){const m=new Fw(s,i,o,c,l,h);return f&&(m.La=!0),m}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e;await async function(r){const s=B(r);k("RemoteStore","RemoteStore shutting down."),s.M_.add(5),await Gs(s),s.O_.shutdown(),s.N_.set("Unknown")}(this.remoteStore),(e=this.datastore)===null||e===void 0||e.terminate()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sT{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Ka(this.observer.next,e)}error(e){this.observer.error?this.Ka(this.observer.error,e):ve("Uncaught Error in snapshot listener:",e.toString())}$a(){this.muted=!0}Ka(e,t){this.muted||setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iT{constructor(e,t,r,s){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=r,this.databaseInfo=s,this.user=Le.UNAUTHENTICATED,this.clientId=cf.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(r,async i=>{k("FirestoreClient","Received user=",i.uid),await this.authCredentialListener(i),this.user=i}),this.appCheckCredentials.start(r,i=>(k("FirestoreClient","Received new app check token=",i),this.appCheckCredentialListener(i,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new $(C.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const e=new Jt;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const r=Bc(t,"Failed to shutdown persistence");e.reject(r)}}),e.promise}}async function wa(n,e){n.asyncQueue.verifyOperationInProgress(),k("FirestoreClient","Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let r=t.initialUser;n.setCredentialChangeListener(async s=>{r.isEqual(s)||(await Tp(e.localStore,s),r=s)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function $h(n,e){n.asyncQueue.verifyOperationInProgress();const t=await aT(n);k("FirestoreClient","Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(r=>xh(e.remoteStore,r)),n.setAppCheckTokenChangeListener((r,s)=>xh(e.remoteStore,s)),n._onlineComponents=e}function oT(n){return n.name==="FirebaseError"?n.code===C.FAILED_PRECONDITION||n.code===C.UNIMPLEMENTED:!(typeof DOMException<"u"&&n instanceof DOMException)||n.code===22||n.code===20||n.code===11}async function aT(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){k("FirestoreClient","Using user provided OfflineComponentProvider");try{await wa(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!oT(t))throw t;Ts("Error using user provided cache. Falling back to memory cache: "+t),await wa(n,new nc)}}else k("FirestoreClient","Using default OfflineComponentProvider"),await wa(n,new nc);return n._offlineComponents}async function Gp(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(k("FirestoreClient","Using user provided OnlineComponentProvider"),await $h(n,n._uninitializedComponentsProvider._online)):(k("FirestoreClient","Using default OnlineComponentProvider"),await $h(n,new Hc))),n._onlineComponents}function cT(n){return Gp(n).then(e=>e.syncEngine)}async function Uh(n){const e=await Gp(n),t=e.eventManager;return t.onListen=$w.bind(null,e.syncEngine),t.onUnlisten=Bw.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=Uw.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=qw.bind(null,e.syncEngine),t}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zp(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bh=new Map;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kp(n,e,t){if(!t)throw new $(C.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function lT(n,e,t,r){if(e===!0&&r===!0)throw new $(C.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function qh(n){if(!F.isDocumentKey(n))throw new $(C.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function jh(n){if(F.isDocumentKey(n))throw new $(C.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Qc(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(r){return r.constructor?r.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":U()}function Xt(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new $(C.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=Qc(n);throw new $(C.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gh{constructor(e){var t,r;if(e.host===void 0){if(e.ssl!==void 0)throw new $(C.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=(t=e.ssl)===null||t===void 0||t;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new $(C.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}lT("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=zp((r=e.experimentalLongPollingOptions)!==null&&r!==void 0?r:{}),function(i){if(i.timeoutSeconds!==void 0){if(isNaN(i.timeoutSeconds))throw new $(C.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (must not be NaN)`);if(i.timeoutSeconds<5)throw new $(C.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (minimum allowed value is 5)`);if(i.timeoutSeconds>30)throw new $(C.INVALID_ARGUMENT,`invalid long polling timeout: ${i.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(r,s){return r.timeoutSeconds===s.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class Jc{constructor(e,t,r,s){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=r,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Gh({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new $(C.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!==void 0}_setSettings(e){if(this._settingsFrozen)throw new $(C.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Gh(e),e.credentials!==void 0&&(this._authCredentials=function(r){if(!r)return new uI;switch(r.type){case"firstParty":return new fI(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new $(C.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const r=Bh.get(t);r&&(k("ComponentProvider","Removing Datastore"),Bh.delete(t),r.terminate())}(this),Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ko{constructor(e,t,r){this.converter=t,this._query=r,this.type="query",this.firestore=e}withConverter(e){return new ko(this.firestore,e,this._query)}}class Qe{constructor(e,t,r){this.converter=t,this._key=r,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Zt(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Qe(this.firestore,e,this._key)}}class Zt extends ko{constructor(e,t,r){super(e,t,yo(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Qe(this.firestore,null,new F(e))}withConverter(e){return new Zt(this.firestore,e,this._path)}}function zh(n,e,...t){if(n=Re(n),Kp("collection","path",e),n instanceof Jc){const r=ae.fromString(e,...t);return jh(r),new Zt(n,null,r)}{if(!(n instanceof Qe||n instanceof Zt))throw new $(C.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(ae.fromString(e,...t));return jh(r),new Zt(n.firestore,null,r)}}function Do(n,e,...t){if(n=Re(n),arguments.length===1&&(e=cf.newId()),Kp("doc","path",e),n instanceof Jc){const r=ae.fromString(e,...t);return qh(r),new Qe(n,null,new F(r))}{if(!(n instanceof Qe||n instanceof Zt))throw new $(C.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(ae.fromString(e,...t));return qh(r),new Qe(n.firestore,n instanceof Zt?n.converter:null,new F(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uT{constructor(){this.iu=Promise.resolve(),this.su=[],this.ou=!1,this._u=[],this.au=null,this.uu=!1,this.cu=!1,this.lu=[],this.Yo=new kp(this,"async_queue_retry"),this.hu=()=>{const t=ki();t&&k("AsyncQueue","Visibility state changed to "+t.visibilityState),this.Yo.Wo()};const e=ki();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.hu)}get isShuttingDown(){return this.ou}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Pu(),this.Iu(e)}enterRestrictedMode(e){if(!this.ou){this.ou=!0,this.cu=e||!1;const t=ki();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.hu)}}enqueue(e){if(this.Pu(),this.ou)return new Promise(()=>{});const t=new Jt;return this.Iu(()=>this.ou&&this.cu?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.su.push(e),this.Tu()))}async Tu(){if(this.su.length!==0){try{await this.su[0](),this.su.shift(),this.Yo.reset()}catch(e){if(!cn(e))throw e;k("AsyncQueue","Operation failed with retryable error: "+e)}this.su.length>0&&this.Yo.$o(()=>this.Tu())}}Iu(e){const t=this.iu.then(()=>(this.uu=!0,e().catch(r=>{this.au=r,this.uu=!1;const s=function(o){let c=o.message||"";return o.stack&&(c=o.stack.includes(o.message)?o.stack:o.message+`
`+o.stack),c}(r);throw ve("INTERNAL UNHANDLED ERROR: ",s),r}).then(r=>(this.uu=!1,r))));return this.iu=t,t}enqueueAfterDelay(e,t,r){this.Pu(),this.lu.indexOf(e)>-1&&(t=0);const s=Uc.createAndSchedule(this,e,t,r,i=>this.Eu(i));return this._u.push(s),s}Pu(){this.au&&U()}verifyOperationInProgress(){}async du(){let e;do e=this.iu,await e;while(e!==this.iu)}Au(e){for(const t of this._u)if(t.timerId===e)return!0;return!1}Ru(e){return this.du().then(()=>{this._u.sort((t,r)=>t.targetTimeMs-r.targetTimeMs);for(const t of this._u)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.du()})}Vu(e){this.lu.push(e)}Eu(e){const t=this._u.indexOf(e);this._u.splice(t,1)}}function Kh(n){return function(t,r){if(typeof t!="object"||t===null)return!1;const s=t;for(const i of r)if(i in s&&typeof s[i]=="function")return!0;return!1}(n,["next","error","complete"])}class Tr extends Jc{constructor(e,t,r,s){super(e,t,r,s),this.type="firestore",this._queue=function(){return new uT}(),this._persistenceKey=(s==null?void 0:s.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||Hp(this),this._firestoreClient.terminate()}}function hT(n,e,t){t||(t="(default)");const r=cc(n,"firestore");if(r.isInitialized(t)){const s=r.getImmediate({identifier:t}),i=r.getOptions(t);if(vs(i,e))return s;throw new $(C.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(e.cacheSizeBytes!==void 0&&e.localCache!==void 0)throw new $(C.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(e.cacheSizeBytes!==void 0&&e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new $(C.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return r.initialize({options:e,instanceIdentifier:t})}function Wp(n){return n._firestoreClient||Hp(n),n._firestoreClient.verifyNotTerminated(),n._firestoreClient}function Hp(n){var e,t,r;const s=n._freezeSettings(),i=function(c,l,h,f){return new BI(c,l,h,f.host,f.ssl,f.experimentalForceLongPolling,f.experimentalAutoDetectLongPolling,zp(f.experimentalLongPollingOptions),f.useFetchStreams)}(n._databaseId,((e=n._app)===null||e===void 0?void 0:e.options.appId)||"",n._persistenceKey,s);n._firestoreClient=new iT(n._authCredentials,n._appCheckCredentials,n._queue,i),!((t=s.localCache)===null||t===void 0)&&t._offlineComponentProvider&&(!((r=s.localCache)===null||r===void 0)&&r._onlineComponentProvider)&&(n._firestoreClient._uninitializedComponentsProvider={_offlineKind:s.localCache.kind,_offline:s.localCache._offlineComponentProvider,_online:s.localCache._onlineComponentProvider})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class br{constructor(e){this._byteString=e}static fromBase64String(e){try{return new br(Pe.fromBase64String(e))}catch(t){throw new $(C.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new br(Pe.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vo{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new $(C.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new fe(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yc{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xc{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new $(C.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new $(C.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return Y(this._lat,e._lat)||Y(this._long,e._long)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dT=/^__.*__$/;class fT{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return this.fieldMask!==null?new Dt(e,this.data,this.fieldMask,t,this.fieldTransforms):new Nr(e,this.data,t,this.fieldTransforms)}}class Qp{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return new Dt(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function Jp(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw U()}}class Zc{constructor(e,t,r,s,i,o){this.settings=e,this.databaseId=t,this.serializer=r,this.ignoreUndefinedProperties=s,i===void 0&&this.mu(),this.fieldTransforms=i||[],this.fieldMask=o||[]}get path(){return this.settings.path}get fu(){return this.settings.fu}gu(e){return new Zc(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}pu(e){var t;const r=(t=this.path)===null||t===void 0?void 0:t.child(e),s=this.gu({path:r,yu:!1});return s.wu(e),s}Su(e){var t;const r=(t=this.path)===null||t===void 0?void 0:t.child(e),s=this.gu({path:r,yu:!1});return s.mu(),s}bu(e){return this.gu({path:void 0,yu:!0})}Du(e){return to(e,this.settings.methodName,this.settings.Cu||!1,this.path,this.settings.vu)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}mu(){if(this.path)for(let e=0;e<this.path.length;e++)this.wu(this.path.get(e))}wu(e){if(e.length===0)throw this.Du("Document fields must not be empty");if(Jp(this.fu)&&dT.test(e))throw this.Du('Document fields cannot begin and end with "__"')}}class pT{constructor(e,t,r){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=r||So(e)}Fu(e,t,r,s=!1){return new Zc({fu:e,methodName:t,vu:r,path:fe.emptyPath(),yu:!1,Cu:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Yp(n){const e=n._freezeSettings(),t=So(n._databaseId);return new pT(n._databaseId,!!e.ignoreUndefinedProperties,t)}function mT(n,e,t,r,s,i={}){const o=n.Fu(i.merge||i.mergeFields?2:0,e,t,s);el("Data must be an object, but it was:",o,r);const c=Xp(r,o);let l,h;if(i.merge)l=new He(o.fieldMask),h=o.fieldTransforms;else if(i.mergeFields){const f=[];for(const m of i.mergeFields){const I=rc(e,m,t);if(!o.contains(I))throw new $(C.INVALID_ARGUMENT,`Field '${I}' is specified in your field mask but missing from your input data.`);em(f,I)||f.push(I)}l=new He(f),h=o.fieldTransforms.filter(m=>l.covers(m.field))}else l=null,h=o.fieldTransforms;return new fT(new Fe(c),l,h)}class No extends Yc{_toFieldTransform(e){if(e.fu!==2)throw e.fu===1?e.Du(`${this._methodName}() can only appear at the top level of your update data`):e.Du(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof No}}function gT(n,e,t,r){const s=n.Fu(1,e,t);el("Data must be an object, but it was:",s,r);const i=[],o=Fe.empty();qn(r,(l,h)=>{const f=tl(e,l,t);h=Re(h);const m=s.Su(f);if(h instanceof No)i.push(f);else{const I=xo(h,m);I!=null&&(i.push(f),o.set(f,I))}});const c=new He(i);return new Qp(o,c,s.fieldTransforms)}function _T(n,e,t,r,s,i){const o=n.Fu(1,e,t),c=[rc(e,r,t)],l=[s];if(i.length%2!=0)throw new $(C.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let I=0;I<i.length;I+=2)c.push(rc(e,i[I])),l.push(i[I+1]);const h=[],f=Fe.empty();for(let I=c.length-1;I>=0;--I)if(!em(h,c[I])){const S=c[I];let D=l[I];D=Re(D);const N=o.Su(S);if(D instanceof No)h.push(S);else{const P=xo(D,N);P!=null&&(h.push(S),f.set(S,P))}}const m=new He(h);return new Qp(f,m,o.fieldTransforms)}function xo(n,e){if(Zp(n=Re(n)))return el("Unsupported field value:",e,n),Xp(n,e);if(n instanceof Yc)return function(r,s){if(!Jp(s.fu))throw s.Du(`${r._methodName}() can only be used with update() and set()`);if(!s.path)throw s.Du(`${r._methodName}() is not currently supported inside arrays`);const i=r._toFieldTransform(s);i&&s.fieldTransforms.push(i)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.yu&&e.fu!==4)throw e.Du("Nested arrays are not supported");return function(r,s){const i=[];let o=0;for(const c of r){let l=xo(c,s.bu(o));l==null&&(l={nullValue:"NULL_VALUE"}),i.push(l),o++}return{arrayValue:{values:i}}}(n,e)}return function(r,s){if((r=Re(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return iE(s.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const i=pe.fromDate(r);return{timestampValue:yr(s.serializer,i)}}if(r instanceof pe){const i=new pe(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:yr(s.serializer,i)}}if(r instanceof Xc)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof br)return{bytesValue:Yf(s.serializer,r._byteString)};if(r instanceof Qe){const i=s.databaseId,o=r.firestore._databaseId;if(!o.isEqual(i))throw s.Du(`Document reference is for database ${o.projectId}/${o.database} but should be for database ${i.projectId}/${i.database}`);return{referenceValue:kc(r.firestore._databaseId||s.databaseId,r._key.path)}}throw s.Du(`Unsupported field value: ${Qc(r)}`)}(n,e)}function Xp(n,e){const t={};return Ef(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):qn(n,(r,s)=>{const i=xo(s,e.pu(r));i!=null&&(t[r]=i)}),{mapValue:{fields:t}}}function Zp(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof pe||n instanceof Xc||n instanceof br||n instanceof Qe||n instanceof Yc)}function el(n,e,t){if(!Zp(t)||!function(s){return typeof s=="object"&&s!==null&&(Object.getPrototypeOf(s)===Object.prototype||Object.getPrototypeOf(s)===null)}(t)){const r=Qc(t);throw r==="an object"?e.Du(n+" a custom object"):e.Du(n+" "+r)}}function rc(n,e,t){if((e=Re(e))instanceof Vo)return e._internalPath;if(typeof e=="string")return tl(n,e);throw to("Field path arguments must be of type string or ",n,!1,void 0,t)}const yT=new RegExp("[~\\*/\\[\\]]");function tl(n,e,t){if(e.search(yT)>=0)throw to(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Vo(...e.split("."))._internalPath}catch{throw to(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function to(n,e,t,r,s){const i=r&&!r.isEmpty(),o=s!==void 0;let c=`Function ${e}() called with invalid data`;t&&(c+=" (via `toFirestore()`)"),c+=". ";let l="";return(i||o)&&(l+=" (found",i&&(l+=` in field ${r}`),o&&(l+=` in document ${s}`),l+=")"),new $(C.INVALID_ARGUMENT,c+n+l)}function em(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tm{constructor(e,t,r,s,i){this._firestore=e,this._userDataWriter=t,this._key=r,this._document=s,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new Qe(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new vT(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){const t=this._document.data.field(nm("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class vT extends tm{data(){return super.data()}}function nm(n,e){return typeof e=="string"?tl(n,e):e instanceof Vo?e._internalPath:e._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function IT(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new $(C.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class ET{convertValue(e,t="none"){switch(Nn(e)){case 0:return null;case 1:return e.booleanValue;case 2:return ge(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(tn(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 10:return this.convertObject(e.mapValue,t);default:throw U()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const r={};return qn(e,(s,i)=>{r[s]=this.convertValue(i,t)}),r}convertGeoPoint(e){return new Xc(ge(e.latitude),ge(e.longitude))}convertArray(e,t){return(e.values||[]).map(r=>this.convertValue(r,t))}convertServerTimestamp(e,t){switch(t){case"previous":const r=wc(e);return r==null?null:this.convertValue(r,t);case"estimate":return this.convertTimestamp(Rs(e));default:return null}}convertTimestamp(e){const t=Ct(e);return new pe(t.seconds,t.nanos)}convertDocumentKey(e,t){const r=ae.fromString(e);j(ap(r));const s=new Vn(r.get(1),r.get(3)),i=new F(r.popFirst(5));return s.isEqual(t)||ve(`Document ${i} contains a document reference within a different database (${s.projectId}/${s.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wT(n,e,t){let r;return r=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class us{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class rm extends tm{constructor(e,t,r,s,i,o){super(e,t,r,s,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new Di(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const r=this._document.data.field(nm("DocumentSnapshot.get",e));if(r!==null)return this._userDataWriter.convertValue(r,t.serverTimestamps)}}}class Di extends rm{data(e={}){return super.data(e)}}class TT{constructor(e,t,r,s){this._firestore=e,this._userDataWriter=t,this._snapshot=s,this.metadata=new us(s.hasPendingWrites,s.fromCache),this.query=r}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(r=>{e.call(t,new Di(this._firestore,this._userDataWriter,r.key,r,new us(this._snapshot.mutatedKeys.has(r.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new $(C.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(s,i){if(s._snapshot.oldDocs.isEmpty()){let o=0;return s._snapshot.docChanges.map(c=>{const l=new Di(s._firestore,s._userDataWriter,c.doc.key,c.doc,new us(s._snapshot.mutatedKeys.has(c.doc.key),s._snapshot.fromCache),s.query.converter);return c.doc,{type:"added",doc:l,oldIndex:-1,newIndex:o++}})}{let o=s._snapshot.oldDocs;return s._snapshot.docChanges.filter(c=>i||c.type!==3).map(c=>{const l=new Di(s._firestore,s._userDataWriter,c.doc.key,c.doc,new us(s._snapshot.mutatedKeys.has(c.doc.key),s._snapshot.fromCache),s.query.converter);let h=-1,f=-1;return c.type!==0&&(h=o.indexOf(c.doc.key),o=o.delete(c.doc.key)),c.type!==1&&(o=o.add(c.doc),f=o.indexOf(c.doc.key)),{type:bT(c.type),doc:l,oldIndex:h,newIndex:f}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}}function bT(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return U()}}class sm extends ET{constructor(e){super(),this.firestore=e}convertBytes(e){return new br(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Qe(this.firestore,null,t)}}function im(n,e,t){n=Xt(n,Qe);const r=Xt(n.firestore,Tr),s=wT(n.converter,e,t);return nl(r,[mT(Yp(r),"setDoc",n._key,s,n.converter!==null,t).toMutation(n._key,qe.none())])}function AT(n,e,t,...r){n=Xt(n,Qe);const s=Xt(n.firestore,Tr),i=Yp(s);let o;return o=typeof(e=Re(e))=="string"||e instanceof Vo?_T(i,"updateDoc",n._key,e,t,r):gT(i,"updateDoc",n._key,e),nl(s,[o.toMutation(n._key,qe.exists(!0))])}function ST(n){return nl(Xt(n.firestore,Tr),[new wo(n._key,qe.none())])}function Wh(n,...e){var t,r,s;n=Re(n);let i={includeMetadataChanges:!1,source:"default"},o=0;typeof e[o]!="object"||Kh(e[o])||(i=e[o],o++);const c={includeMetadataChanges:i.includeMetadataChanges,source:i.source};if(Kh(e[o])){const m=e[o];e[o]=(t=m.next)===null||t===void 0?void 0:t.bind(m),e[o+1]=(r=m.error)===null||r===void 0?void 0:r.bind(m),e[o+2]=(s=m.complete)===null||s===void 0?void 0:s.bind(m)}let l,h,f;if(n instanceof Qe)h=Xt(n.firestore,Tr),f=yo(n._key.path),l={next:m=>{e[o]&&e[o](RT(h,n,m))},error:e[o+1],complete:e[o+2]};else{const m=Xt(n,ko);h=Xt(m.firestore,Tr),f=m._query;const I=new sm(h);l={next:S=>{e[o]&&e[o](new TT(h,I,m,S))},error:e[o+1],complete:e[o+2]},IT(n._query)}return function(I,S,D,N){const P=new sT(N),H=new xw(S,P,D);return I.asyncQueue.enqueueAndForget(async()=>kw(await Uh(I),H)),()=>{P.$a(),I.asyncQueue.enqueueAndForget(async()=>Dw(await Uh(I),H))}}(Wp(h),f,c,l)}function nl(n,e){return function(r,s){const i=new Jt;return r.asyncQueue.enqueueAndForget(async()=>jw(await cT(r),s,i)),i.promise}(Wp(n),e)}function RT(n,e,t){const r=t.docs.get(e._key),s=new sm(n);return new rm(n,s,e._key,r,new us(t.hasPendingWrites,t.fromCache),e.converter)}class PT{constructor(e){let t;this.kind="persistent",e!=null&&e.tabManager?(e.tabManager._initialize(e),t=e.tabManager):(t=VT(),t._initialize(e)),this._onlineComponentProvider=t._onlineComponentProvider,this._offlineComponentProvider=t._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function CT(n){return new PT(n)}class kT{constructor(e){this.forceOwnership=e,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Hc,this._offlineComponentProvider=new jp(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes,this.forceOwnership)}}class DT{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=new Hc,this._offlineComponentProvider=new rT(this._onlineComponentProvider,e==null?void 0:e.cacheSizeBytes)}}function VT(n){return new kT(void 0)}function NT(){return new DT}(function(e,t=!0){(function(s){Vr=s})(Cr),ur(new Pn("firestore",(r,{instanceIdentifier:s,options:i})=>{const o=r.getProvider("app").getImmediate(),c=new Tr(new hI(r.getProvider("auth-internal")),new mI(r.getProvider("app-check-internal")),function(h,f){if(!Object.prototype.hasOwnProperty.apply(h.options,["projectId"]))throw new $(C.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Vn(h.options.projectId,f)}(o,s),o);return i=Object.assign({useFetchStreams:t},i),c._setSettings(i),c},"PUBLIC").setMultipleInstances(!0)),Ht(Bu,"4.6.3",e),Ht(Bu,"4.6.3","esm2017")})();const xT={apiKey:"AIzaSyC9Um4cxmF3LT_f9Ade5gYSj4ZjMbPHZU4",authDomain:"cursing-offers.firebaseapp.com",projectId:"cursing-offers",storageBucket:"cursing-offers.firebasestorage.app",messagingSenderId:"782347533500",appId:"1:782347533500:web:5da31b9357632fc055a4b9"};function OT(){const n=Date.now(),e=864e5,t=new Date().toISOString().slice(0,10),r=(i,o,c)=>({desc:i,qty:o,price:c,disc:0}),s=(i,o,c,l,h,f,m,I,S,D)=>({id:i,number:o,ts:n-S*e,date:new Date(n-S*e).toISOString().slice(0,10),customer:{name:c,phone:l,email:"",afm:"",address:h},subject:f,status:m,total:I,vatMode:"on",lines:D});return{quotes:[s("q1","2311","Γιώργος Παπαδόπουλος","6900000001","Πρέβεζα","Εγκατάσταση CCTV και WiFi","accepted",1437.16,3,[r("Hikvision IP 4MP Bullet",4,89),r("NVR 8 καναλιών + 2TB",1,245),r("UniFi U6 Lite",2,119),r("Εργασία εγκατάστασης",1,320)]),s("q2","2310","Hotel Aktaion","6900000002","Βόνιτσα","WiFi ξενοδοχείου 40 δωμάτια","pending",6920,5,[r("UniFi U6+",20,159),r("Switch PoE 24 θυρών",1,420),r("Εργασία",1,1700)]),s("q3","2309","Μαρία Νικολάου","6900000003","Λευκάδα","Συναγερμός Paradox","done",780,40,[r("Paradox MG5050 set",1,480),r("Εργασία",1,149)]),s("q4","2307","Κώστας Δήμου","6900000004","Πρέβεζα","Κάμερες καταστήματος","rejected",1150,12,[r("Dahua 4MP Dome",6,95),r("Εργασία",1,357)]),s("q5","2306","Σταύρος Σταύρου","6900000005","Πάλαιρος","Θυροτηλέφωνο + κάμερα","pending",540,1,[r("Θυροτηλέφωνο IP",1,290),r("Εργασία",1,145)])],products:[{id:"p1",cat:"Κάμερες",model:"Hikvision IP 4MP Bullet",desc:"DS-2CD2043",cost:71.2},{id:"p2",cat:"Κάμερες",model:"Dahua 4MP Dome",desc:"",cost:76},{id:"p3",cat:"Καταγραφικά",model:"NVR 8 καναλιών",desc:"με δίσκο 2TB",cost:196},{id:"p4",cat:"WiFi",model:"UniFi U6 Lite",desc:"Access Point",cost:95.2},{id:"p5",cat:"WiFi",model:"UniFi U6+",desc:"",cost:127.2},{id:"p6",cat:"Συναγερμοί",model:"Paradox MG5050",desc:"set",cost:384}],smoves:[{id:"m1",pid:"p1",qty:6}],custs:[{id:"c1",name:"Γιώργος Παπαδόπουλος",phone:"6900000001",address:"Πρέβεζα",ts:n-30*e}],tasks:[{id:"t1",title:"Εγκατάσταση CCTV",date:t,time:"09:00",cust:"Γιώργος Παπαδόπουλος",addr:"Πρέβεζα",done:!1},{id:"t2",title:"Αυτοψία WiFi ξενοδοχείου",date:t,time:"13:30",cust:"Hotel Aktaion",addr:"Βόνιτσα",done:!1},{id:"t3",title:"Service συναγερμού",date:t,time:"17:00",cust:"Μαρία Νικολάου",addr:"Λευκάδα",done:!0}],ldocs:[{id:"d3",kind:"purchase",party:"Xpatit",number:"ΤΔΑ 1182",cat:"Εμπορεύματα",net:820,vat:196.8,rate:24,gross:1016.8,date:t,ts:n-e,items:[]},{id:"d4",kind:"purchase",party:"Cosmote",number:"",cat:"Τηλεπικοινωνίες",net:45,vat:10.8,rate:24,gross:55.8,date:t,ts:n-3*e,items:[]},{id:"d1",kind:"sale",qid:"q1",number:"2311",party:"Γιώργος Παπαδόπουλος",net:1159,vat:278.16,rate:24,gross:1437.16,date:t,ts:n-2*e},{id:"d2",kind:"sale",party:"Μαρία Νικολάου",gross:780,date:t,ts:n-30*e}],wdays:[{id:"w1",empId:"e1",date:t,days:1,amount:60},{id:"w2",empId:"e1",date:t,days:1,amount:60}],wpays:[{id:"wp1",empId:"e1",date:t,amount:50,method:"cash"}],lpays:[{id:"p3",dir:"out",date:t,party:"Xpatit",docId:"d3",amount:400,method:"bank",note:""},{id:"p1",docId:"d1",amount:500,dir:"in",date:t,party:"Γιώργος Παπαδόπουλος",method:"bank",note:"Προκαταβολή"},{id:"p2",docId:"d2",amount:780,dir:"in",date:t,party:"Μαρία Νικολάου",method:"cash",note:""}],emps:[{id:"e1",name:"Νίκος Τεχνικός",rate:60}],st:{main:{vat:24,margin:25,next:2312},books:{opening:1500,costCats:["Εμπορεύματα","Υλικά","Καύσιμα","Τηλεπικοινωνίες","Λοιπά έξοδα"]}}}}const om={quotes:"quotes",custs:"customers",tasks:"tasks",ldocs:"ledger_docs",lpays:"ledger_pays",emps:"employees",products:"products",smoves:"stock_moves",wdays:"workdays",wpays:"wagepays"},rl={...om,qlog:"quote_log"},L={quotes:[],custs:[],tasks:[],ldocs:[],lpays:[],emps:[],products:[],smoves:[],wdays:[],wpays:[],st:{}},am=new Set;function MT(n){am.add(n)}function Rn(){am.forEach(n=>n())}const hn=new URLSearchParams(location.search).has("demo"),LT=hn;let Ar=null,Fn=null,no=[];function FT(n){if(hn){Object.assign(L,OT()),n({email:"demo@techmate"}),setTimeout(Rn,0);return}const e=vd(xT);Ar=aI(e),Fn=hT(e,{localCache:CT({tabManager:NT()})}),Hy(Ar,t=>{no.forEach(r=>r()),no=[],t&&$T(),n(t)})}function $T(){no.push(Wh(zh(Fn,"settings"),n=>{const e={};n.docs.forEach(t=>e[t.id]=t.data()),L.st=e,Rn()},()=>{})),Object.entries(om).forEach(([n,e])=>{no.push(Wh(zh(Fn,e),t=>{L[n]=t.docs.map(r=>({...r.data(),id:r.id})),Rn()},()=>{L[n]=[],Rn()}))})}function UT(n,e){return zy(Ar,n,e)}function BT(){return hn?location.assign(location.pathname):Qy(Ar)}const Te=n=>String(n||"").trim().toLowerCase(),x=(n,e=0)=>{const t=parseFloat(n);return isNaN(t)?e:t},J=n=>Math.round(n*100)/100,tt=n=>n.status||"pending",Oo=n=>!!(n&&n.kind==="install"),Vi={pending:"Σε αναμονή",accepted:"Δεκτή",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"};function Mo(n){let e=0;return L.lpays.forEach(t=>{t.docId===n&&(e+=x(t.amount))}),J(e)}function cm(n){return Math.max(0,J(x(n.gross)-Mo(n.id)))}function vt(){const n={},e=t=>{const r=Te(t)||"_none";return n[r]||(n[r]={k:r,name:t||"(χωρίς όνομα)",quotes:[],mins:[],last:0})};return L.custs.forEach(t=>{const r=e(t.name);r.name=t.name,r.rec=t,r.last=Math.max(r.last,t.upd||t.ts||0)}),L.quotes.forEach(t=>{const r=e(t.customer&&t.customer.name);(Oo(t)?r.mins:r.quotes).push(t),r.last=Math.max(r.last,t.ts||0)}),L.ldocs.forEach(t=>{t.kind==="sale"&&e(t.party)}),Object.values(n).map(t=>{t.won=0,t.owed=0,t.docs=L.ldocs.filter(i=>i.kind==="sale"&&Te(i.party)===t.k),t.quotes.forEach(i=>{const o=tt(i);(o==="accepted"||o==="done")&&(t.won+=x(i.total))}),t.docs.forEach(i=>{t.owed+=cm(i),t.last=Math.max(t.last,i.ts||0)}),t.owed=J(t.owed),t.won=J(t.won);const r=t.quotes.slice().sort((i,o)=>(o.ts||0)-(i.ts||0))[0],s=r&&r.customer||{};return t.info={},["phone","email","afm","address"].forEach(i=>t.info[i]=t.rec&&t.rec[i]||s[i]||""),t})}const sn=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),it=n=>JSON.parse(JSON.stringify(n)),st=()=>L.st.main;let lm=()=>{};function qT(n){lm=n}const Lo=n=>{n.catch(e=>lm(e))};function nt(n,e){const t=it(e);delete t.id;const r=L[n];if(r){const s=r.findIndex(i=>i.id===e.id);s>=0?r[s]=it(e):r.push(it(e))}hn||Lo(im(Do(Fn,rl[n],e.id),t)),Rn()}function um(n,e){L[n]&&(L[n]=L[n].filter(t=>t.id!==e)),hn||Lo(ST(Do(Fn,rl[n],e))),Rn()}const ro=()=>hn?{uid:"demo",email:"demo@techmate"}:Ar&&Ar.currentUser;function so(n,e,t){const r=(L[n]||[]).find(s=>s.id===e);r&&Object.assign(r,t),hn||Lo(AT(Do(Fn,rl[n],e),t)),Rn()}function jT(n){L.st.main&&(L.st.main.next=n),hn||Lo(im(Do(Fn,"settings","main"),{next:n},{merge:!0}))}const sl=n=>x(n.qty)*x(n.price)*(1-x(n.disc)/100),il=n=>J((n.lines||[]).reduce((e,t)=>e+sl(t),0));function hm(n){const e=il(n),t=n.vatMode==="off",r=x(st()&&st().vat,24),s=t?0:J(e*r/100);return{sub:e,vat:s,vp:r,off:t,total:J(e+s)}}function dm(n){const e=x(n.cost,0);if(n.marginEur!=null&&n.marginEur!=="")return J(e+x(n.marginEur));const t=n.margin==null||n.margin===""?x(st()&&st().margin,25):x(n.margin);return J(e*(1+t/100))}function fm(n,e){let t=0,r=0,s=0;return L.ldocs.forEach(i=>{i.kind==="purchase"&&i.items&&i.items.forEach(o=>{o.pid===n&&(t+=x(o.qty))})}),L.smoves.forEach(i=>{i.pid===n&&(t+=x(i.qty))}),L.quotes.forEach(i=>{if(i.id===e)return;const o=tt(i);(i.lines||[]).forEach(c=>{if(c.pid!==n||c.src!=="stock")return;const l=x(c.qty);o==="done"?i.noStock||(r+=l):o==="accepted"&&(s+=l)})}),J(t-r-s)}/*! Capacitor: https://capacitorjs.com/ - MIT License */var Sr;(function(n){n.Unimplemented="UNIMPLEMENTED",n.Unavailable="UNAVAILABLE"})(Sr||(Sr={}));class Ta extends Error{constructor(e,t,r){super(e),this.message=e,this.code=t,this.data=r}}const GT=n=>{var e,t;return n!=null&&n.androidBridge?"android":!((t=(e=n==null?void 0:n.webkit)===null||e===void 0?void 0:e.messageHandlers)===null||t===void 0)&&t.bridge?"ios":"web"},zT=n=>{const e=n.CapacitorCustomPlatform||null,t=n.Capacitor||{},r=t.Plugins=t.Plugins||{},s=()=>e!==null?e.name:GT(n),i=()=>s()!=="web",o=m=>{const I=h.get(m);return!!(I!=null&&I.platforms.has(s())||c(m))},c=m=>{var I;return(I=t.PluginHeaders)===null||I===void 0?void 0:I.find(S=>S.name===m)},l=m=>n.console.error(m),h=new Map,f=(m,I={})=>{const S=h.get(m);if(S)return console.warn(`Capacitor plugin "${m}" already registered. Cannot register plugins twice.`),S.proxy;const D=s(),N=c(m);let P;const H=async()=>(!P&&D in I?P=typeof I[D]=="function"?P=await I[D]():P=I[D]:e!==null&&!P&&"web"in I&&(P=typeof I.web=="function"?P=await I.web():P=I.web),P),K=(g,_)=>{var E,w;if(N){const T=N==null?void 0:N.methods.find(y=>_===y.name);if(T)return T.rtype==="promise"?y=>t.nativePromise(m,_.toString(),y):(y,ze)=>t.nativeCallback(m,_.toString(),y,ze);if(g)return(E=g[_])===null||E===void 0?void 0:E.bind(g)}else{if(g)return(w=g[_])===null||w===void 0?void 0:w.bind(g);throw new Ta(`"${m}" plugin is not implemented on ${D}`,Sr.Unimplemented)}},q=g=>{let _;const E=(...w)=>{const T=H().then(y=>{const ze=K(y,g);if(ze){const lt=ze(...w);return _=lt==null?void 0:lt.remove,lt}else throw new Ta(`"${m}.${g}()" is not implemented on ${D}`,Sr.Unimplemented)});return g==="addListener"&&(T.remove=async()=>_()),T};return E.toString=()=>`${g.toString()}() { [capacitor code] }`,Object.defineProperty(E,"name",{value:g,writable:!1,configurable:!1}),E},X=q("addListener"),V=q("removeListener"),M=(g,_)=>{const E=X({eventName:g},_).then(y=>y),w=async()=>{const y=await E;await V({eventName:g,callbackId:y})},T=new Promise(y=>E.then(()=>y({remove:w})));return T.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await w()},T},v=new Proxy({},{get(g,_){switch(_){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return N?M:X;case"removeListener":return V;default:return q(_)}}});return r[m]=v,h.set(m,{name:m,proxy:v,platforms:new Set([...Object.keys(I),...N?[D]:[]])}),v};return t.convertFileSrc||(t.convertFileSrc=m=>m),t.getPlatform=s,t.handleError=l,t.isNativePlatform=i,t.isPluginAvailable=o,t.registerPlugin=f,t.Exception=Ta,t.DEBUG=!!t.DEBUG,t.isLoggingEnabled=!!t.isLoggingEnabled,t},KT=n=>n.Capacitor=zT(n),io=KT(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),Fo=io.registerPlugin;class ol{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let r=!1;this.listeners[e]||(this.listeners[e]=[],r=!0),this.listeners[e].push(t);const i=this.windowListeners[e];i&&!i.registered&&this.addWindowListener(i),r&&this.sendRetainedArgumentsForEvent(e);const o=async()=>this.removeListener(e,t);return Promise.resolve({remove:o})}async removeAllListeners(){this.listeners={};for(const e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,r){const s=this.listeners[e];if(!s){if(r){let i=this.retainedEventArguments[e];i||(i=[]),i.push(t),this.retainedEventArguments[e]=i}return}s.forEach(i=>i(t))}hasListeners(e){var t;return!!(!((t=this.listeners[e])===null||t===void 0)&&t.length)}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:r=>{this.notifyListeners(t,r)}}}unimplemented(e="not implemented"){return new io.Exception(e,Sr.Unimplemented)}unavailable(e="not available"){return new io.Exception(e,Sr.Unavailable)}async removeListener(e,t){const r=this.listeners[e];if(!r)return;const s=r.indexOf(t);s!==-1&&this.listeners[e].splice(s,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){const t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(r=>{this.notifyListeners(e,r)}))}}const Hh=n=>encodeURIComponent(n).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Qh=n=>n.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class WT extends ol{async getCookies(){const e=document.cookie,t={};return e.split(";").forEach(r=>{if(r.length<=0)return;let[s,i]=r.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");s=Qh(s).trim(),i=Qh(i).trim(),t[s]=i}),t}async setCookie(e){try{const t=Hh(e.key),r=Hh(e.value),s=e.expires?`; expires=${e.expires.replace("expires=","")}`:"",i=(e.path||"/").replace("path=",""),o=e.url!=null&&e.url.length>0?`domain=${e.url}`:"";document.cookie=`${t}=${r||""}${s}; path=${i}; ${o};`}catch(t){return Promise.reject(t)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(t){return Promise.reject(t)}}async clearCookies(){try{const e=document.cookie.split(";")||[];for(const t of e)document.cookie=t.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}}Fo("CapacitorCookies",{web:()=>new WT});const HT=async n=>new Promise((e,t)=>{const r=new FileReader;r.onload=()=>{const s=r.result;e(s.indexOf(",")>=0?s.split(",")[1]:s)},r.onerror=s=>t(s),r.readAsDataURL(n)}),QT=(n={})=>{const e=Object.keys(n);return Object.keys(n).map(s=>s.toLocaleLowerCase()).reduce((s,i,o)=>(s[i]=n[e[o]],s),{})},JT=(n,e=!0)=>n?Object.entries(n).reduce((r,s)=>{const[i,o]=s;let c,l;return Array.isArray(o)?(l="",o.forEach(h=>{c=e?encodeURIComponent(h):h,l+=`${i}=${c}&`}),l.slice(0,-1)):(c=e?encodeURIComponent(o):o,l=`${i}=${c}`),`${r}&${l}`},"").substr(1):null,YT=(n,e={})=>{const t=Object.assign({method:n.method||"GET",headers:n.headers},e),s=QT(n.headers)["content-type"]||"";if(typeof n.data=="string")t.body=n.data;else if(s.includes("application/x-www-form-urlencoded")){const i=new URLSearchParams;for(const[o,c]of Object.entries(n.data||{}))i.set(o,c);t.body=i.toString()}else if(s.includes("multipart/form-data")||n.data instanceof FormData){const i=new FormData;if(n.data instanceof FormData)n.data.forEach((c,l)=>{i.append(l,c)});else for(const c of Object.keys(n.data))i.append(c,n.data[c]);t.body=i;const o=new Headers(t.headers);o.delete("content-type"),t.headers=o}else(s.includes("application/json")||typeof n.data=="object")&&(t.body=JSON.stringify(n.data));return t};class XT extends ol{async request(e){const t=YT(e,e.webFetchExtra),r=JT(e.params,e.shouldEncodeUrlParams),s=r?`${e.url}?${r}`:e.url,i=await fetch(s,t),o=i.headers.get("content-type")||"";let{responseType:c="text"}=i.ok?e:{};o.includes("application/json")&&(c="json");let l,h;switch(c){case"arraybuffer":case"blob":h=await i.blob(),l=await HT(h);break;case"json":l=await i.json();break;case"document":case"text":default:l=await i.text()}const f={};return i.headers.forEach((m,I)=>{f[I]=m}),{data:l,headers:f,status:i.status,url:i.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:"GET"}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:"POST"}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:"PUT"}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:"PATCH"}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:"DELETE"}))}}Fo("CapacitorHttp",{web:()=>new XT});var Jh;(function(n){n.Dark="DARK",n.Light="LIGHT",n.Default="DEFAULT"})(Jh||(Jh={}));var Yh;(function(n){n.StatusBar="StatusBar",n.NavigationBar="NavigationBar"})(Yh||(Yh={}));class ZT extends ol{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}Fo("SystemBars",{web:()=>new ZT});const eb="modulepreload",tb=function(n){return"/"+n},Xh={},nb=function(e,t,r){let s=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const o=document.querySelector("meta[property=csp-nonce]"),c=(o==null?void 0:o.nonce)||(o==null?void 0:o.getAttribute("nonce"));s=Promise.allSettled(t.map(l=>{if(l=tb(l),l in Xh)return;Xh[l]=!0;const h=l.endsWith(".css"),f=h?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${f}`))return;const m=document.createElement("link");if(m.rel=h?"stylesheet":eb,h||(m.as="script"),m.crossOrigin="",m.href=l,c&&m.setAttribute("nonce",c),document.head.appendChild(m),h)return new Promise((I,S)=>{m.addEventListener("load",I),m.addEventListener("error",()=>S(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(o){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=o,window.dispatchEvent(c),!c.defaultPrevented)throw o}return s.then(o=>{for(const c of o||[])c.status==="rejected"&&i(c.reason);return e().catch(i)})},rb="__capgo_keep_url_path_after_reload",ba="__capgo_history_stack__",Zh=100,sb=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(sb){const n=window;if(!n.__capgoHistoryPatched){n.__capgoHistoryPatched=!0;const e=()=>{try{if(n.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(rb)==="1"}catch{return!1}},t=()=>{try{const V=window.sessionStorage.getItem(ba);if(!V)return{stack:[],index:-1};const M=JSON.parse(V);return!M||!Array.isArray(M.stack)||typeof M.index!="number"?{stack:[],index:-1}:M}catch{return{stack:[],index:-1}}},r=(V,M)=>{try{window.sessionStorage.setItem(ba,JSON.stringify({stack:V,index:M}))}catch{}},s=()=>{try{window.sessionStorage.removeItem(ba)}catch{}},i=V=>{try{const M=V??window.location.href,v=new URL(M instanceof URL?M.toString():M,window.location.href);return`${v.pathname}${v.search}${v.hash}`}catch{return null}},o=(V,M)=>{if(V.length<=Zh)return{stack:V,index:M};const v=V.length-Zh,g=V.slice(v),_=Math.max(0,M-v);return{stack:g,index:_}},c=V=>{document.readyState==="complete"||document.readyState==="interactive"?V():window.addEventListener("DOMContentLoaded",V,{once:!0})};let l=!1,h=!1,f=!1;const m=()=>{if(!l)return;const V=t(),M=i();if(M){if(V.stack.length===0){V.stack.push(M),V.index=0,r(V.stack,V.index);return}(V.index<0||V.index>=V.stack.length)&&(V.index=V.stack.length-1),V.stack[V.index]!==M&&(V.stack[V.index]=M,r(V.stack,V.index))}},I=(V,M)=>{if(!l||h)return;const v=i(V);if(!v)return;let{stack:g,index:_}=t();g.length===0?(g.push(v),_=g.length-1):M?((_<0||_>=g.length)&&(_=g.length-1),g[_]=v):_>=g.length-1?(g.push(v),_=g.length-1):(g=g.slice(0,_+1),g.push(v),_=g.length-1),{stack:g,index:_}=o(g,_),r(g,_)},S=()=>{if(!l||h)return;const V=t();if(V.stack.length===0){m();return}const M=V.index>=0&&V.index<V.stack.length?V.index:V.stack.length-1,v=i();if(V.stack.length===1&&v===V.stack[0])return;const g=V.stack[0];if(!g)return;h=!0;try{history.replaceState(history.state,document.title,g);for(let w=1;w<V.stack.length;w+=1)history.pushState(history.state,document.title,V.stack[w])}catch{h=!1;return}h=!1;const _=V.stack.length-1,E=M-_;E!==0?history.go(E):(history.replaceState(history.state,document.title,V.stack[M]),window.dispatchEvent(new PopStateEvent("popstate")))},D=()=>{!l||f||(f=!0,c(()=>{f=!1,S()}))};let N=null,P=null;const H=()=>{if(!l||h)return;const V=i();if(!V)return;const M=t(),v=M.stack.lastIndexOf(V);v>=0?M.index=v:(M.stack.push(V),M.index=M.stack.length-1);const g=o(M.stack,M.index);r(g.stack,g.index)},K=()=>{N&&P||(N=history.pushState,P=history.replaceState,history.pushState=function(M,v,g){const _=N==null?void 0:N.call(history,M,v,g);return I(g,!1),_},history.replaceState=function(M,v,g){const _=P==null?void 0:P.call(history,M,v,g);return I(g,!0),_},window.addEventListener("popstate",H))},q=()=>{N&&(history.pushState=N,N=null),P&&(history.replaceState=P,P=null),window.removeEventListener("popstate",H)},X=V=>{if(l===V){l&&(m(),D());return}l=V,l?(K(),m(),D()):(q(),s())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",V=>{var M;const v=V,g=(M=v==null?void 0:v.detail)===null||M===void 0?void 0:M.enabled;typeof g=="boolean"?(n.__capgoKeepUrlPathAfterReload=g,X(g)):(n.__capgoKeepUrlPathAfterReload=!0,X(!0))}),X(e())}}var ed;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",n[n.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",n[n.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(ed||(ed={}));var td;(function(n){n[n.UNKNOWN=0]="UNKNOWN",n[n.PENDING=1]="PENDING",n[n.DOWNLOADING=2]="DOWNLOADING",n[n.INSTALLING=3]="INSTALLING",n[n.INSTALLED=4]="INSTALLED",n[n.FAILED=5]="FAILED",n[n.CANCELED=6]="CANCELED",n[n.DOWNLOADED=11]="DOWNLOADED"})(td||(td={}));var nd;(function(n){n[n.OK=0]="OK",n[n.CANCELED=1]="CANCELED",n[n.FAILED=2]="FAILED",n[n.NOT_AVAILABLE=3]="NOT_AVAILABLE",n[n.NOT_ALLOWED=4]="NOT_ALLOWED",n[n.INFO_MISSING=5]="INFO_MISSING"})(nd||(nd={}));const Vs=Fo("CapacitorUpdater",{web:()=>nb(()=>import("./web-R-m3DGQi.js"),[]).then(n=>new n.CapacitorUpdaterWeb)}),pm="0.5.2",ib="https://raw.githubusercontent.com/cursing/techmate-mobile-releases/main/latest.json",mm=io.isNativePlatform(),rd=(n,e)=>{const t=String(n).split(".").map(Number),r=String(e).split(".").map(Number);for(let s=0;s<3;s++){const i=(t[s]||0)-(r[s]||0);if(i)return i}return 0},ye={state:"idle",latest:null,pct:0,err:"",needApk:!1,checkedAt:0};let gm=()=>{};function ob(n){gm=n}const Gt=n=>{Object.assign(ye,n),gm()};function ab(){mm&&(Vs.notifyAppReady().catch(()=>{}),Vs.addListener("download",n=>{ye.state==="downloading"&&Gt({pct:Math.round(n.percent||0)})}),sc(),document.addEventListener("visibilitychange",()=>{!document.hidden&&Date.now()-ye.checkedAt>30*6e4&&sc()}))}async function sc(n){if(!mm){n&&Gt({state:"none"});return}if(ye.state!=="downloading"){n&&Gt({state:"checking",err:""});try{const e=await fetch(ib+"?t="+Date.now(),{cache:"no-store"});if(!e.ok)throw new Error("HTTP "+e.status);const t=await e.json();if(ye.checkedAt=Date.now(),!t.version||rd(t.version,pm)<=0)return Gt({state:n?"none":"idle",latest:null});let r="0";try{r=(await Vs.getBuiltinVersion()).version||"0"}catch{}Gt({state:"available",latest:t,needApk:!!t.minNative&&rd(r,t.minNative)<0,err:""})}catch{Gt({state:n?"error":"idle",err:n?"Δεν μπόρεσα να ελέγξω για ενημέρωση. Έλεγξε τη σύνδεση.":""})}}}async function cb(){const n=ye.latest;if(!(!n||ye.state==="downloading")){if(ye.needApk){window.location.href=n.apk;return}Gt({state:"downloading",pct:0,err:""});try{const e=await Vs.download({url:n.zip,version:n.version,checksum:n.sha256||""});await Vs.set(e)}catch(e){Gt({state:"available",err:"Η λήψη απέτυχε: "+(e&&(e.message||e.code)||"άγνωστο σφάλμα")})}}}const lb=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),ic=n=>lb.format(Math.round((n||0)*100)/100),sd=n=>n<10?"0"+n:""+n,pt=()=>{const n=new Date;return n.getFullYear()+"-"+sd(n.getMonth()+1)+"-"+sd(n.getDate())},ub=n=>(n=x(n,24),[24,13,6,0].includes(n)?n:24),al=()=>{const n=ro();return n&&(L.st.roles&&L.st.roles.users||{})[n.uid]||null},$n=()=>{const n=al();return!!(n&&n.role==="team")},Aa=()=>{const n=al();return n&&n.empId||""},_m=()=>{const n=ro();if(!n)return null;const e=al();return{uid:n.uid,name:e?e.name||"Υπάλληλος":"Διαχειριστής"}},cl=n=>!$n()||!!(n&&n.by&&ro()&&n.by.uid===ro().uid),Ni={pending:"Σε αναμονή απάντησης",accepted:"Έγινε δεκτή, προς εγκατάσταση",done:"Ολοκληρώθηκε",rejected:"Απορρίφθηκε"},Sa=(n,e,t)=>nt("qlog",{id:sn(),qid:n.id||"",number:n.number||"",customer:n.customer&&n.customer.name||"",ts:Date.now(),type:e,text:t}),ym=n=>L.ldocs.find(e=>e.kind==="sale"&&(e.qid===n.id||!e.qid&&n.number&&e.number===n.number&&Te(e.party)===Te(n.customer&&n.customer.name)))||null,id=n=>!(n&&n.war&&n.war.on===!1),hb=n=>{const e=n&&n.war;return e&&e.m!=null&&e.m!==""?Math.max(0,Math.floor(x(e.m,0))):x(st().warrantyMonths,24)};function db(n,e){let t=0,r=0,s=0;return L.ldocs.forEach(i=>{i.kind==="purchase"&&i.items&&i.items.forEach(o=>{o.pid===n&&(t+=x(o.qty))})}),L.smoves.forEach(i=>{i.pid===n&&(t+=x(i.qty))}),L.quotes.forEach(i=>{if(i.id===e)return;const o=tt(i);(i.lines||[]).forEach(c=>{if(c.pid!==n||c.src!=="stock")return;const l=x(c.qty);o==="done"?i.noStock||(r+=l):o==="accepted"&&(s+=l)})}),J(t-r-s)}function fb(n,e){const t=[],r=ym(n);if(e==="pending"||e==="rejected"?r&&r.qid===n.id&&r.note==="Από προσφορά "+(n.number||"")&&Mo(r.id)===0&&t.push("Θα αφαιρεθεί το παραστατικό πώλησης που είχε δημιουργηθεί αυτόματα."):!r&&st()&&st().autoSale!==!1&&t.push("Θα δημιουργηθεί παραστατικό πώλησης "+ic(vm(n).gross)+" στα Λογιστικά."),e==="done"&&!n.install&&t.push("Θα καταχωρηθεί ως εγκατάσταση με σημερινή ημερομηνία."),(e==="accepted"||e==="done")&&n.gid){const s=L.quotes.filter(i=>i.gid===n.gid&&i.id!==n.id&&tt(i)==="pending").length;s&&t.push("Οι "+s+" άλλες εναλλακτικές θα μπουν ως «Απορρίφθηκε».")}return t}function vm(n){const e=n.vatMode==="off"?0:ub(st().vat),t=il(n),r=J(t*e/100);return{rate:e,net:t,vat:r,gross:J(t+r)}}function pb(n,e){const t=L.quotes.find(c=>c.id===n);if(!t||tt(t)===e)return{ok:!1};if(!st())return{ok:!1,msg:"Δεν έχουν φορτώσει οι ρυθμίσεις. Περίμενε λίγο ή έλεγξε τη σύνδεση."};const r=it(t);Sa(r,"status",Ni[tt(r)]+" → "+Ni[e]),e==="done"&&!r.install&&(r.install={date:pt(),months:id(r)?hb(r):0,serials:"",nw:!id(r)}),r.status=e,r.statusDate=pt();const s=[];e==="accepted"&&(r.lines||[]).forEach(c=>{if(c.pid&&c.src==="stock"&&x(c.qty)>db(c.pid,r.id)){const l=L.products.find(h=>h.id===c.pid);s.push(l?l.model:c.desc)}});const i=[],o=ym(r);if(e==="pending"||e==="rejected")o&&o.qid===r.id&&o.note==="Από προσφορά "+(r.number||"")&&Mo(o.id)===0&&(um("ldocs",o.id),i.push("Αφαιρέθηκε το αυτόματο παραστατικό πώλησης."));else if(!o&&st().autoSale!==!1){const c=vm(r),l={id:sn(),ts:Date.now(),kind:"sale",date:pt(),party:r.customer&&r.customer.name||"Πελάτης",number:r.number||"",cat:"",net:c.net,vat:c.vat,gross:c.gross,rate:c.rate,note:"Από προσφορά "+(r.number||""),items:[],qid:r.id};nt("ldocs",l),L.lpays.forEach(h=>{h.qid===r.id&&!h.docId&&so("lpays",h.id,{docId:l.id,party:l.party||h.party})}),Sa(r,"edit","Δημιουργήθηκε αυτόματα παραστατικό πώλησης ("+ic(c.gross)+")."),i.push("Δημιουργήθηκε παραστατικό πώλησης "+ic(c.gross)+" στα Λογιστικά.")}return r.gid&&(e==="accepted"||e==="done")&&L.quotes.filter(c=>c.gid===r.gid&&c.id!==r.id&&tt(c)==="pending").forEach(c=>{const l=it(c);l.status="rejected",l.statusDate=pt(),Sa(l,"status","Σε αναμονή → Απορρίφθηκε (έγινε δεκτή η εναλλακτική "+(r.number||"")+")"),nt("quotes",l)}),nt("quotes",r),s.length&&i.push("Δεν επαρκεί το απόθεμα για: "+s.join(", ")+"."),{ok:!0,msg:["Η κατάσταση άλλαξε: "+Ni[e]+"."].concat(i).join(" ")}}function mb(n,e){const t=String(e.name||"").trim();if(!t)return{msg:"Γράψε όνομα πελάτη."};const r=Te(t),s=vt(),i=n&&s.find(h=>h.k===n);if((!n||n!==r)&&s.some(h=>h.k===r))return{msg:"Υπάρχει ήδη πελάτης «"+t+"». Άνοιξε τον φάκελό του."};const o=n&&L.custs.find(h=>Te(h.name)===n),c=o?it(o):{id:sn(),ts:Date.now()},l=h=>String(e[h]||"").trim();return Object.assign(c,{name:t,phone:l("phone"),email:l("email"),afm:l("afm"),address:l("address"),notes:l("notes"),upd:Date.now()}),nt("custs",c),n&&n!==r&&i&&(i.quotes.concat(i.mins).forEach(h=>{const f=it(h);f.customer=Object.assign({},f.customer||{},{name:t}),nt("quotes",f)}),L.ldocs.forEach(h=>{h.kind==="sale"&&Te(h.party)===n&&so("ldocs",h.id,{party:t})}),L.lpays.forEach(h=>{h.dir==="in"&&Te(h.party)===n&&so("lpays",h.id,{party:t})})),{ok:!0,k:r}}function Im(n){if(n.done&&!n.doneAt){n.doneAt=Date.now();const e=_m();e&&(n.doneBy=e.name)}else n.done||(delete n.doneAt,delete n.doneBy)}function gb(n,e){const t=String(e.title||"").trim();if(!t)return{msg:"Γράψε τίτλο εργασίας."};const r=n&&L.tasks.find(h=>h.id===n),s=!r;if(n&&!r)return{msg:"Η εργασία δεν υπάρχει πια."};if(!s&&!cl(r))return{msg:"Μπορείς να αλλάξεις μόνο εργασίες που έγραψες εσύ."};if($n()&&!Aa())return{msg:"Ο λογαριασμός σου δεν είναι συνδεδεμένος με υπάλληλο. Ζήτα από τον διαχειριστή να το ορίσει."};const i=e.date||"",o=e.time||"";if(o&&!i)return{msg:"Για ώρα χρειάζεται και ημερομηνία."};const c=s?{id:sn(),ts:Date.now(),msId:"",msList:"",rem:""}:it(r);if(s){const h=_m();h&&(c.by=h)}!s&&(i!==c.date||o!==c.time)&&(c.rem="");let l=(e.emps||[]).slice();return $n()&&(l=(c.emps||[]).slice(),l.includes(Aa())||l.push(Aa())),Object.assign(c,{chk:c.chk||[],title:t,date:i,time:o,emps:l,cust:String(e.cust||"").trim(),addr:String(e.addr||"").trim(),notes:String(e.notes||"").trim(),done:!!e.done,remOff:c.remOff||"at",quoteId:c.quoteId||e.quoteId||"",upd:Date.now(),dirty:!0,del:!1}),Im(c),nt("tasks",c),{ok:!0}}function _b(n,e){const t=L.tasks.find(s=>s.id===n);if(!t)return;const r=it(t);r.done=!!e,r.upd=Date.now(),r.dirty=!0,Im(r),nt("tasks",r)}function yb(n){const e=L.tasks.find(t=>t.id===n);if(!e)return{ok:!1};if(!cl(e))return{msg:"Μπορείς να σβήσεις μόνο εργασίες που έγραψες εσύ."};if(e.msId){const t=it(e);t.del=!0,t.dirty=!0,t.upd=Date.now(),nt("tasks",t)}else um("tasks",e.id);return{ok:!0}}const Ae=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),vb=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),ne=n=>vb.format(Math.round((n||0)*100)/100),Em=n=>String(J(n)).replace(".",","),lr=n=>x(String(n).replace(",","."),NaN),Ns=n=>{if(!n)return"";const e=String(n).slice(0,10).split("-");return e[2]+"/"+e[1]+"/"+e[0]},od=n=>n<10?"0"+n:""+n,Xn=n=>n.getFullYear()+"-"+od(n.getMonth()+1)+"-"+od(n.getDate()),wm=()=>L.st.books||{},Ib=n=>(n=x(n,24),[24,13,6,0].includes(n)?n:24);let xs="month";try{xs=localStorage.getItem("tm_period")||"month"}catch{}const Eb=[["month","Μήνας"],["prevmonth","Προηγ. μήνας"],["quarter","Τρίμηνο"],["year","Έτος"],["all","Όλα"]];function Tm(){const n=new Date,e=n.getFullYear(),t=n.getMonth();switch(xs){case"month":return[Xn(new Date(e,t,1)),Xn(new Date(e,t+1,0))];case"prevmonth":return[Xn(new Date(e,t-1,1)),Xn(new Date(e,t,0))];case"quarter":{const r=Math.floor(t/3)*3;return[Xn(new Date(e,r,1)),Xn(new Date(e,r+3,0))]}case"year":return[e+"-01-01",e+"-12-31"];default:return["",""]}}const Tn=n=>{const e=Tm();return(!e[0]||n>=e[0])&&(!e[1]||n<=e[1])},wb=()=>{const n=Tm();return!n[0]&&!n[1]?"Όλες οι κινήσεις":Ns(n[0])+" έως "+Ns(n[1])};function bm(n){let e=0,t=0;return L.wdays.forEach(r=>{r.empId===n&&(e+=x(r.amount))}),L.wpays.forEach(r=>{r.empId===n&&(t+=x(r.amount))}),{earned:J(e),paid:J(t),bal:J(e-t)}}function $o(){const n={},e={},t=(s,i)=>{const o=Te(i)||"—";return s[o]||(s[o]={name:(i||"").trim()||"Χωρίς όνομα",inv:0,paid:0})};L.ldocs.forEach(s=>{t(s.kind==="sale"?e:n,s.party).inv+=x(s.gross)}),L.lpays.forEach(s=>{t(s.dir==="in"?e:n,s.party).paid+=x(s.amount)});const r=s=>Object.values(s).map(i=>(i.inv=J(i.inv),i.paid=J(i.paid),i.bal=J(i.inv-i.paid),i)).sort((i,o)=>o.bal-i.bal);return{sup:r(n),cus:r(e)}}function Tb(){const n={sNet:0,sVat:0,pNet:0,pVat:0,inBank:0,inCash:0,outBank:0,outCash:0,wages:0,cats:{}};L.ldocs.forEach(s=>{if(!(s.opening||!Tn(s.date)))if(s.kind==="sale")n.sNet+=x(s.net),n.sVat+=x(s.vat);else{n.pNet+=x(s.net),n.pVat+=x(s.vat);const i=s.cat||"Χωρίς κατηγορία";n.cats[i]=(n.cats[i]||0)+x(s.net)}}),L.lpays.forEach(s=>{Tn(s.date)&&(s.dir==="in"?s.method==="bank"?n.inBank+=x(s.amount):n.inCash+=x(s.amount):s.method==="bank"?n.outBank+=x(s.amount):n.outCash+=x(s.amount))}),L.wdays.forEach(s=>{Tn(s.date)&&(n.wages+=x(s.amount))}),L.wpays.forEach(s=>{Tn(s.date)&&(s.method==="bank"?n.outBank+=x(s.amount):n.outCash+=x(s.amount))}),Object.keys(n).forEach(s=>{typeof n[s]=="number"&&(n[s]=J(n[s]))}),n.vatDue=J(n.sVat-n.pVat),n.profit=J(n.sNet-n.pNet-n.wages);let e=x(wm().opening,0),t=0;L.lpays.forEach(s=>{const i=s.dir==="in"?x(s.amount):-x(s.amount);s.method==="bank"?e+=i:t+=i}),L.wpays.forEach(s=>{s.method==="bank"?e-=x(s.amount):t-=x(s.amount)}),n.bank=J(e),n.cash=J(t),n.rcvAll=J(n.inBank+n.inCash),n.nRcv=L.lpays.filter(s=>s.dir==="in"&&Tn(s.date)).length;const r=$o();return n.owe=0,n.due=0,n.nOwe=0,n.nDue=0,n.wOwe=0,n.nW=0,r.sup.forEach(s=>{s.bal>.004&&(n.owe+=s.bal,n.nOwe++)}),r.cus.forEach(s=>{s.bal>.004&&(n.due+=s.bal,n.nDue++)}),L.emps.forEach(s=>{const i=bm(s.id).bal;i>.004&&(n.wOwe+=i,n.nW++)}),n.owe=J(n.owe),n.due=J(n.due),n.wOwe=J(n.wOwe),n}function zs(n){const e=Mo(n.id),t=J(x(n.gross)-e);return x(n.gross)!==0&&t<=.004?{k:"paid",t:n.kind==="sale"?"Εισπράχθηκε":"Πληρώθηκε",rem:0}:e>0?{k:"part",t:"Μερικώς",rem:t}:{k:"open",t:n.kind==="sale"?"Δεν εισπράχθηκε":"Ανεξόφλητο",rem:t}}const bb=(n,e)=>{const t=e==="in"?"sale":"purchase",r=Te(n);return L.ldocs.filter(s=>s.kind===t&&(!r||Te(s.party)===r)&&zs(s).k!=="paid").sort((s,i)=>s.date<i.date?1:-1)},Am=[["sum","Σύνοψη"],["docs","Παραστατικά"],["pays","Πληρωμές"],["bal","Υπόλοιπα"]];let xi="all",ie=null;const Sm=()=>!!ie;function Ab(){ie=null}const _i=(n,e,t="")=>`<div class="kpi"><b class="${t}">${n}</b><span>${e}</span></div>`,Sb={paid:"p-ok",part:"p-w",open:"p-b"},Rb=(n,e)=>`<div class="chips">${Am.map(([t,r])=>`<a href="#/books/${t}" class="chip${t===n?" on":""}">${r}</a>`).join("")}</div>
  ${n==="bal"?"":`<div class="chips">${Eb.map(([t,r])=>`<button data-bper="${t}" class="${t===xs?"on":""}">${r}</button>`).join("")}</div><div class="plabel">${wb()}</div>`}${e?"":'<div class="upd">Φόρτωση…</div>'}`;function Pb(){const n=Tb(),e=Object.entries(n.cats).sort((t,r)=>r[1]-t[1]);return`<div class="kpis">${_i(ne(n.sNet),"Έσοδα (καθαρά)","ok")}${_i(ne(n.pNet),"Αγορές και έξοδα (καθαρά)","bad")}${_i(ne(n.wages),"Μεροκάματα")}${_i(ne(n.profit),"Κέρδος περιόδου",n.profit<0?"bad":"")}</div>
  ${n.sVat||n.pVat?`<div class="h">ΦΠΑ</div><div class="card"><div class="tot"><span>ΦΠΑ πωλήσεων</span><span>${ne(n.sVat)}</span></div><div class="tot"><span>ΦΠΑ αγορών</span><span>${ne(n.pVat)}</span></div>
    <div class="tot big"><span>${n.vatDue>=0?"ΦΠΑ προς απόδοση":"ΦΠΑ πιστωτικό"}</span><span>${ne(Math.abs(n.vatDue))}</span></div></div>`:""}
  <div class="h">Χρήματα</div><div class="card"><div class="tot"><span>Εισπράξεις περιόδου${n.nRcv?" ("+n.nRcv+")":""}</span><span>${ne(n.rcvAll)}</span></div>
    <div class="tot"><span>· τράπεζα ${ne(n.inBank)} · μετρητά ${ne(n.inCash)}</span><span></span></div>
    <div class="tot"><span>Πληρωμές περιόδου</span><span>${ne(J(n.outBank+n.outCash))}</span></div>
    <div class="tot big"><span>Τράπεζα σήμερα</span><span>${ne(n.bank)}</span></div><div class="tot big"><span>Μετρητά στο ταμείο</span><span>${ne(n.cash)}</span></div></div>
  <div class="h">Υπόλοιπα</div><div class="card">
    <a class="row" href="#/books/bal"><div class="av">👥</div><div class="t"><b>Πελάτες μου χρωστούν</b><span>${n.nDue} πελάτες</span></div><span class="amt">${ne(n.due)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">🏭</div><div class="t"><b>Χρωστάω σε προμηθευτές</b><span>${n.nOwe} προμηθευτές</span></div><span class="amt">${ne(n.owe)}</span></a>
    <a class="row" href="#/books/bal"><div class="av">👷</div><div class="t"><b>Μεροκάματα που χρωστάω</b><span>${n.nW} υπάλληλοι</span></div><span class="amt">${ne(n.wOwe)}</span></a></div>
  ${e.length?`<div class="h">Έξοδα ανά κατηγορία</div><div class="card">${e.map(([t,r])=>`<div class="tot"><span>${Ae(t)}</span><span>${ne(r)}</span></div>`).join("")}</div>`:""}`}function Cb(){const n=L.ldocs.filter(e=>Tn(e.date)&&(xi==="all"||e.kind===xi)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0));return`<div class="chips">${[["all","Όλα"],["sale","Πωλήσεις"],["purchase","Αγορές"]].map(([e,t])=>`<button data-bdk="${e}" class="${xi===e?"on":""}">${t}</button>`).join("")}</div>
  <div class="card">${n.map(e=>{const t=zs(e);return`<div class="row"><div class="av">${e.kind==="sale"?"📤":"📥"}</div>
    <div class="t"><b>${Ae(e.party)}</b><span>${Ns(e.date)}${e.number?" · "+Ae(e.number):""}${e.cat?" · "+Ae(e.cat):""}${e.opening?" · παλιό υπόλοιπο":""}</span>${e.note?`<span>${Ae(e.note)}</span>`:""}
    ${t.k!=="paid"?`<button class="lnk" data-bpay="${Ae(e.id)}">${e.kind==="sale"?"💶 Είσπραξη":"💶 Πληρωμή"} ${ne(t.rem)}</button>`:""}</div>
    <div class="r"><div class="amt">${ne(e.gross)}</div><span class="pill ${Sb[t.k]}">${t.t}</span></div></div>`}).join("")||'<div class="empty">Κανένα παραστατικό στην περίοδο</div>'}</div>`}function kb(){return`<div class="card">${L.lpays.filter(e=>Tn(e.date)).sort((e,t)=>e.date<t.date?1:e.date>t.date?-1:(t.ts||0)-(e.ts||0)).map(e=>`<div class="row"><div class="av">${e.dir==="in"?"⬇️":"⬆️"}</div>
    <div class="t"><b>${Ae(e.party)}</b><span>${Ns(e.date)} · ${e.method==="bank"?"τράπεζα":"μετρητά"}${e.note?" · "+Ae(e.note):""}</span></div>
    <div class="r"><div class="amt ${e.dir==="in"?"ok":"bad"}">${e.dir==="in"?"+":"−"}${ne(e.amount)}</div></div></div>`).join("")||'<div class="empty">Καμία κίνηση στην περίοδο</div>'}</div>`}function Db(){const n=$o(),e=(r,s,i)=>r.map(o=>`<div class="row"><div class="t"><b>${Ae(o.name)}</b><span>τιμολογημένα ${ne(o.inv)} · πληρωμένα ${ne(o.paid)}</span>
    ${o.bal>.004?`<button class="lnk" data-bnew="${s}" data-party="${Ae(o.name)}">${s==="in"?"💶 Νέα είσπραξη":"💶 Νέα πληρωμή"}</button>`:""}</div>
    <div class="r"><span class="pill ${o.bal>.004?"p-b":o.bal<-.004?"p-w":"p-ok"}">${o.bal>.004?ne(o.bal):o.bal<-.004?"πιστωτικό "+ne(-o.bal):"εξοφλημένο"}</span></div></div>`).join("")||`<div class="empty">${i}</div>`,t=L.emps.slice().sort((r,s)=>String(r.name).localeCompare(s.name,"el"));return`<div class="h">Πελάτες</div><div class="card">${e(n.cus,"in","Δεν υπάρχουν πελάτες με παραστατικά")}</div>
  <div class="h">Προμηθευτές</div><div class="card">${e(n.sup,"out","Δεν υπάρχουν προμηθευτές")}</div>
  ${t.length?`<div class="h">Υπάλληλοι</div><div class="card">${t.map(r=>{const s=bm(r.id);return`<div class="row"><div class="t"><b>${Ae(r.name)}</b><span>δεδουλευμένα ${ne(s.earned)} · πληρωμένα ${ne(s.paid)}</span></div>
    <div class="r"><span class="pill ${s.bal>.004?"p-b":s.bal<-.004?"p-w":"p-ok"}">${s.bal>.004?ne(s.bal):s.bal<-.004?"προπληρωμή "+ne(-s.bal):"τακτοποιημένο"}</span></div></div>`}).join("")}</div>`:""}`}const ut=(n,e,t="")=>`<label class="f">${e}<input class="in" data-bf="${n}" value="${Ae(ie.v[n]??"")}" ${t}></label>`,ys=(n,e)=>`<div class="seg">${e.map(([t,r])=>`<button data-bseg="${n}" data-v="${t}" class="${ie.v[n]===t?"on":""}">${r}</button>`).join("")}</div>`;function Vb(){const n=ie.v,e=bb(n.party,n.dir),t=$o();return n.docId&&!e.some(r=>r.id===n.docId)&&(n.docId=""),`<div class="card pad">${ys("dir",[["in","Είσπραξη από πελάτη"],["out","Πληρωμή σε προμηθευτή"]])}
    ${ut("date","Ημερομηνία",'type="date"')}${ut("party",n.dir==="in"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.dir==="in"?t.cus:t.sup).map(r=>`<option value="${Ae(r.name)}">`).join("")}</datalist>
    <label class="f">Παραστατικό<select class="in" data-bf="docId"><option value="">Χωρίς σύνδεση με παραστατικό</option>${e.map(r=>`<option value="${Ae(r.id)}" ${r.id===n.docId?"selected":""}>${Ns(r.date)} · ${Ae(r.party)}${r.number?" · "+Ae(r.number):""} · υπόλοιπο ${ne(zs(r).rem)}</option>`).join("")}</select></label>
    ${ut("amount","Ποσό €",'inputmode="decimal"')}${ys("method",[["bank","Τράπεζα"],["cash","Μετρητά"]])}${ut("note","Σημείωση")}</div>`}function ll(n){const e=lr(n.amount),t=x(n.rate,24);let r,s,i;return n.mode==="net"?(r=J(e),s=J(r*t/100),i=J(r+s)):(i=J(e),r=J(i/(1+t/100)),s=J(i-r)),{net:r,vat:s,gross:i,rate:t}}function Nb(){const n=ie.v,e=$o(),t=isNaN(lr(n.amount))?null:ll(n);return`<div class="card pad">${ys("kind",[["purchase","Αγορά / έξοδο"],["sale","Πώληση"]])}
    ${ut("date","Ημερομηνία",'type="date"')}${ut("party",n.kind==="sale"?"Πελάτης":"Προμηθευτής",'list="bpl" autocomplete="off"')}
    <datalist id="bpl">${(n.kind==="sale"?e.cus:e.sup).map(r=>`<option value="${Ae(r.name)}">`).join("")}</datalist>
    ${ut("number","Αριθμός παραστατικού")}
    ${n.kind==="purchase"?`${ut("cat","Κατηγορία εξόδου",'list="bcl" autocomplete="off"')}<datalist id="bcl">${(wm().costCats||[]).map(r=>`<option value="${Ae(r)}">`).join("")}</datalist>`:""}
    ${ut("amount","Ποσό €",'inputmode="decimal"')}${ys("mode",[["gross","Το ποσό είναι με ΦΠΑ"],["net","Το ποσό είναι χωρίς ΦΠΑ"]])}
    <div class="f">Συντελεστής ΦΠΑ</div>${ys("rate",[["24","24%"],["13","13%"],["6","6%"],["0","0%"]])}
    <div id="bprev" class="plabel">${t?`Καθαρό ${ne(t.net)} · ΦΠΑ ${ne(t.vat)} · Σύνολο ${ne(t.gross)}`:""}</div>${ut("note","Σημείωση")}</div>`}function xb(n,e){if(n==="newpay"||n==="newdoc"){const r=n==="newpay"?"pay":"doc";return(!ie||ie.kind!==r)&&(ie={kind:r,v:r==="pay"?{dir:"in",date:pt(),party:"",docId:"",amount:"",method:"bank",note:"",...oo||{}}:{kind:"purchase",date:pt(),party:"",number:"",cat:"",amount:"",mode:"gross",rate:String(Ib(st()&&st().vat)),note:""}}),oo=null,`<header class="top"><a class="ib" data-bact="cancel">←</a><h1>${r==="pay"?"Νέα κίνηση":"Νέο παραστατικό"}</h1></header><main class="body ed">${r==="pay"?Vb():Nb()}
      ${ie.msg?`<div class="err box">${Ae(ie.msg)}</div>`:""}</main><div class="bar"><button class="btn b2" data-bact="cancel">Άκυρο</button><button class="btn b1" data-bact="save">💾 Αποθήκευση</button></div>`}ie=null;const t=Am.some(([r])=>r===n)?n:"sum";return`<header class="top"><a class="ib" href="#/menu">←</a><h1>Λογιστικά</h1></header><main class="body">${Rb(t,e)}${{sum:Pb,docs:Cb,pays:kb,bal:Db}[t]()}</main>
    <div class="fab2"><a class="btn b2" href="#/books/newdoc">＋ Παραστατικό</a><a class="btn b1" href="#/books/newpay">＋ Είσπραξη / πληρωμή</a></div>`}let oo=null;function Ob(){const n=ie.v;if(!n.date)return"Βάλε ημερομηνία.";if(ie.kind==="pay"){let r=String(n.party||"").trim();const s=n.docId&&L.ldocs.find(i=>i.id===n.docId);return s&&(r=s.party),r?!String(n.amount).trim()||isNaN(lr(n.amount))?"Βάλε ποσό.":(nt("lpays",{dir:n.dir,date:n.date,party:r,docId:n.docId||"",amount:J(lr(n.amount)),method:n.method,note:String(n.note||"").trim(),id:sn(),ts:Date.now()}),""):"Βάλε "+(n.dir==="in"?"πελάτη":"προμηθευτή")+"."}const e=String(n.party||"").trim();if(!e)return"Βάλε "+(n.kind==="sale"?"πελάτη":"προμηθευτή")+".";if(!String(n.amount).trim()||isNaN(lr(n.amount)))return"Βάλε ποσό.";const t=ll(n);return nt("ldocs",{kind:n.kind,date:n.date,party:e,number:String(n.number||"").trim(),cat:n.kind==="purchase"?String(n.cat||"").trim():"",net:t.net,vat:t.vat,gross:t.gross,rate:t.rate,note:String(n.note||"").trim(),items:[],id:sn(),ts:Date.now()}),""}function Mb(n,e,t,r){const s=n.closest("[data-bper],[data-bdk],[data-bpay],[data-bnew],[data-bseg],[data-bact]");if(!s)return!1;const i=s.dataset;if(i.bper){xs=i.bper;try{localStorage.setItem("tm_period",xs)}catch{}}else if(i.bdk)xi=i.bdk;else if(i.bpay){const o=L.ldocs.find(c=>c.id===i.bpay);return o&&(oo={dir:o.kind==="sale"?"in":"out",party:o.party,docId:o.id,amount:Em(zs(o).rem)}),ie=null,e("#/books/newpay"),!0}else{if(i.bnew)return oo={dir:i.bnew,party:i.party},ie=null,e("#/books/newpay"),!0;if(i.bseg)ie.v[i.bseg]=i.v,i.bseg==="dir"&&(ie.v.docId="");else if(i.bact==="cancel"){const o=ie&&ie.kind;return ie=null,e(o==="doc"?"#/books/docs":"#/books/pays",!0),!0}else if(i.bact==="save"){const o=Ob();if(o)ie.msg=o;else{const c=ie.kind;return ie=null,r(c==="pay"?"Η κίνηση αποθηκεύτηκε.":"Το παραστατικό αποθηκεύτηκε."),e(c==="doc"?"#/books/docs":"#/books/pays",!0),!0}}}return t(),!0}function Lb(n,e){if(!ie||!n.dataset.bf)return!1;const t=n.dataset.bf;if(ie.v[t]=n.value,ie.msg="",t==="docId"){const r=L.ldocs.find(s=>s.id===n.value);r&&(ie.v.party=r.party,ie.v.amount=Em(zs(r).rem)),e()}else if(!(t==="party"&&ie.kind==="pay")){if(t==="amount"&&ie.kind==="doc"){const r=document.getElementById("bprev");if(r){const s=isNaN(lr(n.value))?null:ll(ie.v);r.textContent=s?`Καθαρό ${ne(s.net)} · ΦΠΑ ${ne(s.vat)} · Σύνολο ${ne(s.gross)}`:""}}}return!0}function Fb(n,e){ie&&ie.kind==="pay"&&n.dataset.bf==="party"&&e()}const Ee=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),$b=new Intl.NumberFormat("el-GR",{style:"currency",currency:"EUR"}),at=n=>$b.format(Math.round((n||0)*100)/100),mt=n=>String(J(n)).replace(".",","),Ub=n=>x(String(n).replace(",","."),0),Bb=()=>({war:{on:!0,m:null},id:null,number:null,date:null,ts:0,customer:{name:"",phone:"",email:"",afm:"",address:""},subject:"",notes:"",status:"pending",vatMode:"on",benefits:[],benShow:!0,planMarks:[],planOn:!0,gid:null,optName:"",validDays:null,payShow:!1,payIds:null,prepay:{type:"",val:0},lines:[]}),ao=n=>n===null||typeof n!="object"?JSON.stringify(n===void 0?null:n):Array.isArray(n)?"["+n.map(ao).join(",")+"]":"{"+Object.keys(n).sort().map(e=>JSON.stringify(e)+":"+ao(n[e])).join(",")+"}";let Q=null;const Rm=()=>!!Q;function qb(){Q=null}let Oi=null;function jb(n){Oi=n}function Gb(n){if(n==="new"){const r=Bb();return Oi&&(Object.assign(r.customer,Oi),Oi=null),Q={arg:n,q:r,base:null,pick:!1,pq:"",pcat:""}}const e=L.quotes.find(r=>r.id===n);if(!e)return null;const t=it(e);return t.customer=Object.assign({name:"",phone:"",email:"",afm:"",address:""},t.customer),t.lines=t.lines||[],Q={arg:n,q:t,base:ao(e),pick:!1,pq:"",pcat:""}}function zb(n,e){return`<div class="ln-ed" data-i="${e}">
    <div class="ln-top"><input class="in" data-l="desc" value="${Ee(n.desc)}" placeholder="Περιγραφή"><button class="x" data-act="del" aria-label="Διαγραφή γραμμής">✕</button></div>
    <div class="ln-bot">
      <div class="step"><button data-act="dec">−</button><input class="in" data-l="qty" inputmode="decimal" value="${Ee(mt(x(n.qty)))}"><button data-act="inc">＋</button></div>
      <label>Τιμή €<input class="in" data-l="price" inputmode="decimal" value="${Ee(mt(x(n.price)))}"></label>
      <label>Έκπτ. %<input class="in" data-l="disc" inputmode="decimal" value="${Ee(mt(x(n.disc)))}"></label>
      <div class="ln-sum" data-sum>${at(sl(n))}</div>
    </div></div>`}function Pm(){const n=hm(Q.q);return`<div class="tot"><span>Καθαρό</span><span>${at(n.sub)}</span></div>
  ${n.off?"":`<div class="tot"><span>ΦΠΑ ${mt(n.vp)}%</span><span>${at(n.vat)}</span></div>`}
  <div class="tot big"><span>Σύνολο${n.off?" (χωρίς ΦΠΑ)":""}</span><span>${at(n.total)}</span></div>`}function Kb(){const n=[...new Set(L.products.map(r=>r.cat).filter(Boolean))].sort((r,s)=>r.localeCompare(s,"el")),e=Te(Q.pq),t=L.products.filter(r=>(!Q.pcat||r.cat===Q.pcat)&&(!e||Te((r.model||"")+" "+(r.desc||"")+" "+(r.cat||"")).includes(e))).sort((r,s)=>((r.cat||"")+(r.model||"")).localeCompare((s.cat||"")+(s.model||""),"el")).slice(0,80);return`<div class="sheet"><div class="sheet-in">
    <div class="sheet-h"><b>Κατάλογος</b><button class="btn b1 sm" data-act="pick-close">Τέλος</button></div>
    <input class="search" id="pq" placeholder="🔍 Αναζήτηση προϊόντος" value="${Ee(Q.pq)}">
    <div class="chips"><button data-pcat="" class="${Q.pcat?"":"on"}">Όλα</button>${n.map(r=>`<button data-pcat="${Ee(r)}" class="${Q.pcat===r?"on":""}">${Ee(r)}</button>`).join("")}</div>
    <div class="sheet-list">${t.map(r=>{const s=Q.q.lines.find(o=>o.pid===r.id),i=fm(r.id,Q.q.id);return`<button class="prow${s?" has":""}" data-pid="${Ee(r.id)}"><div class="t"><b>${Ee(r.model)}</b><span>${Ee([r.cat,r.desc].filter(Boolean).join(" · "))}${i>=1?` · 📦 ${mt(i)} στο ράφι`:""}</span></div>
      <div class="r"><div class="amt">${at(dm(r))}</div>${s?`<span class="pill p-ok">×${mt(x(s.qty))}</span>`:'<span class="muted">＋ προσθήκη</span>'}</div></button>`}).join("")||`<div class="empty">${L.products.length?"Δεν βρέθηκε προϊόν":"Ο κατάλογος είναι άδειος"}</div>`}</div>
  </div></div>`}function Wb(n){if((!Q||Q.arg!==n)&&(Q=null,!Gb(n)))return null;const e=Q.q,t=e.customer,r=vt().map(s=>s.name).filter(s=>s&&s!=="(χωρίς όνομα)");return`<header class="top"><a class="ib" data-act="cancel">←</a><h1>${e.id?"Προσφορά #"+Ee(e.number||"—"):"Νέα προσφορά"}<span class="sm">${e.id?"Επεξεργασία":"Δεν έχει αποθηκευτεί ακόμα"}</span></h1></header>
  <main class="body ed">
    <div class="card pad">
      <label class="f">Πελάτης<input class="in" data-c="name" list="cl" value="${Ee(t.name)}" placeholder="Όνομα πελάτη" autocomplete="off"></label>
      <datalist id="cl">${r.map(s=>`<option value="${Ee(s)}">`).join("")}</datalist>
      <details><summary>Τηλέφωνο, email, ΑΦΜ, διεύθυνση</summary>
        <label class="f">Τηλέφωνο<input class="in" data-c="phone" inputmode="tel" value="${Ee(t.phone)}"></label>
        <label class="f">Email<input class="in" data-c="email" inputmode="email" value="${Ee(t.email)}"></label>
        <label class="f">ΑΦΜ<input class="in" data-c="afm" inputmode="numeric" value="${Ee(t.afm)}"></label>
        <label class="f">Διεύθυνση<input class="in" data-c="address" value="${Ee(t.address)}"></label>
      </details>
      <label class="f">Θέμα<input class="in" data-q="subject" value="${Ee(e.subject)}" placeholder="π.χ. Εγκατάσταση CCTV"></label>
    </div>
    <div class="h">Είδη (${e.lines.length})</div>
    <div class="card pad" id="lines">${e.lines.map(zb).join("")||'<div class="empty">Πρόσθεσε είδη από τον κατάλογο ή γράψε δική σου γραμμή.</div>'}</div>
    <div class="actions"><button class="btn b1" data-act="pick">📦 Κατάλογος</button><button class="btn b2" data-act="free">＋ Γραμμή</button><button class="btn b2" data-act="work">🛠️ Εργασία</button></div>
    <div class="card pad">
      <div class="seg"><button data-vat="on" class="${e.vatMode==="off"?"":"on"}">Με ΦΠΑ</button><button data-vat="off" class="${e.vatMode==="off"?"on":""}">Χωρίς ΦΠΑ</button></div>
      <div id="tots">${Pm()}</div>
    </div>
    <div class="card pad"><label class="f">Σημειώσεις<textarea class="in" data-q="notes" rows="3">${Ee(e.notes)}</textarea></label></div>
    ${Q.msg?`<div class="err box">${Ee(Q.msg)}</div>`:""}
  </main>
  <div class="bar"><button class="btn b2" data-act="cancel">Άκυρο</button><button class="btn b1" data-act="save">💾 ${Q.force?"Αποθήκευση (αντικατάσταση)":"Αποθήκευση"}</button></div>
  ${Q.pick?Kb():""}`}function Hb(n,e,t){const r=()=>{const s=n.querySelector("#tots");s&&(s.innerHTML=Pm())};n.oninput=s=>{const i=s.target,o=Q&&Q.q;if(o){if(i.dataset.c){if(o.customer[i.dataset.c]=i.value,i.dataset.c==="name"){const c=vt().find(l=>l.k===Te(i.value));if(c){let l=!1;if(["phone","email","afm","address"].forEach(h=>{!o.customer[h]&&c.info[h]&&(o.customer[h]=c.info[h],l=!0)}),l){e();const h=n.querySelector('[data-c="name"]');h.focus(),h.setSelectionRange(h.value.length,h.value.length)}}}}else if(i.dataset.q)o[i.dataset.q]=i.value;else if(i.dataset.l){const c=i.closest(".ln-ed"),l=o.lines[+c.dataset.i];if(!l)return;l[i.dataset.l]=i.dataset.l==="desc"?i.value:Ub(i.value),c.querySelector("[data-sum]").textContent=at(sl(l)),r()}else if(i.id==="pq"){Q.pq=i.value,e();const c=n.querySelector("#pq");c.focus(),c.setSelectionRange(c.value.length,c.value.length)}}},n.onclick=s=>{const i=Q&&Q.q;if(!i)return;const o=s.target.closest("[data-act],[data-vat],[data-pcat],[data-pid]");if(!o)return;const c=o.closest(".ln-ed"),l=c&&i.lines[+c.dataset.i],h=o.dataset.act;if(o.dataset.vat)i.vatMode=o.dataset.vat;else if(o.dataset.pcat!==void 0)Q.pcat=o.dataset.pcat;else if(o.dataset.pid)Qb(o.dataset.pid);else if(h==="inc")l.qty=J(x(l.qty)+1);else if(h==="dec")l.qty=Math.max(0,J(x(l.qty)-1));else if(h==="del")i.lines.splice(+c.dataset.i,1);else if(h==="free")i.lines.push({desc:"",qty:1,price:0,disc:0,showImg:!0});else if(h==="work")i.lines.push({desc:"Εργασία / εγκατάσταση",qty:1,price:0,disc:0,showImg:!0});else if(h==="pick")Q.pick=!0;else if(h==="pick-close")Q.pick=!1;else if(h==="cancel"){const f=i.id;return Q=null,t(f)}else if(h==="save"){const f=Xb();if(f)return Q=null,t(f)}if(Q.msg&&h!=="save"&&(Q.msg="",Q.force=!1),e(),h==="free"){const f=n.querySelectorAll('[data-l="desc"]');f[f.length-1].focus()}}}function Qb(n){const e=L.products.find(r=>r.id===n);if(!e)return;const t=Q.q.lines.find(r=>r.pid===n);t?t.qty=J(x(t.qty)+1):Q.q.lines.push({pid:n,desc:e.model+(e.desc?" - "+e.desc:""),qty:1,price:dm(e),disc:0,src:fm(n,Q.q.id)>=1?"stock":"supplier",showImg:!!(e.img&&e.imgPdf!==!1)})}function Jb(n,e){const t=[],r=(c,l,h)=>{String(l||"")!==String(h||"")&&t.push(c+": «"+(l||"—")+"» → «"+(h||"—")+"»")};r("Πελάτης",n.customer&&n.customer.name,e.customer&&e.customer.name),r("Θέμα",n.subject,e.subject),r("ΦΠΑ",n.vatMode==="off"?"χωρίς":"με",e.vatMode==="off"?"χωρίς":"με"),(n.notes||"")!==(e.notes||"")&&t.push("Άλλαξαν οι σημειώσεις");const s={},i={};if((n.lines||[]).forEach(c=>s[c.pid||c.desc]=c),(e.lines||[]).forEach(c=>i[c.pid||c.desc]=c),Object.keys(i).forEach(c=>{if(!s[c])t.push("Προστέθηκε: "+i[c].desc+" ×"+mt(x(i[c].qty)));else{const l=s[c],h=i[c];x(l.qty)!==x(h.qty)&&t.push(h.desc+": ποσότητα "+mt(x(l.qty))+" → "+mt(x(h.qty))),x(l.price)!==x(h.price)&&t.push(h.desc+": τιμή "+at(x(l.price))+" → "+at(x(h.price))),x(l.disc)!==x(h.disc)&&t.push(h.desc+": έκπτωση "+mt(x(h.disc))+"%")}}),Object.keys(s).forEach(c=>{i[c]||t.push("Αφαιρέθηκε: "+s[c].desc)}),!t.length)return"";const o=J(x(e.total)-x(n.total));return t.join("; ")+(o?" (σύνολο "+at(x(n.total))+" → "+at(x(e.total))+")":"")}const Yb=n=>(n=x(n,24),[24,13,6,0].includes(n)?n:24);function Xb(){const n=Q.q,e=st();if(n.lines=n.lines.filter(c=>String(c.desc||"").trim()).map(c=>({...c,desc:String(c.desc).trim(),qty:x(c.qty),price:x(c.price),disc:x(c.disc)})),!n.lines.length)return Q.msg="Η προσφορά δεν έχει γραμμές.",null;if(!e)return Q.msg="Δεν έχουν φορτώσει οι ρυθμίσεις (αρίθμηση, ΦΠΑ). Περίμενε λίγο ή έλεγξε τη σύνδεση.",null;const t=n.id?L.quotes.find(c=>c.id===n.id):null;if(n.id&&!t)return Q.msg="Η προσφορά δεν υπάρχει πια (ίσως διαγράφηκε από άλλη συσκευή).",null;if(t&&ao(t)!==Q.base&&!Q.force)return Q.force=!0,Q.msg="Η προσφορά άλλαξε από άλλη συσκευή αφού την άνοιξες. Αν αποθηκεύσεις, οι αλλαγές εκείνες θα αντικατασταθούν. Πάτα ξανά «Αποθήκευση» για να συνεχίσεις, ή «Άκυρο».",null;let r=0;if(!n.number){const c=Math.max(1,Math.floor(x(e.next,1)));n.number=new Date().getFullYear()+"-"+String(c).padStart(3,"0"),r=c+1}n.date||(n.date=new Date().toLocaleDateString("el-GR")),n.id||(n.id=sn(),n.ts=Date.now()),n.customer.name=String(n.customer.name||"").trim(),n.total=hm(n).total;const s=it(n);nt("quotes",s),r&&jT(r);const i=(c,l)=>nt("qlog",{id:sn(),qid:s.id,number:s.number||"",customer:s.customer.name||"",ts:Date.now(),type:c,text:l});if(!t)i("create","Νέα προσφορά, σύνολο "+at(s.total)+", "+s.lines.length+" γραμμές.");else{const c=Jb(t,s);c&&i("edit",c)}const o=L.ldocs.find(c=>c.kind==="sale"&&(c.qid===s.id||!c.qid&&s.number&&c.number===s.number&&Te(c.party)===Te(s.customer.name)));if(o){const c=s.vatMode==="off"?0:Yb(e.vat),l=il(s),h=J(l*c/100),f=J(l+h),m=s.customer.name||o.party;o.qid===s.id&&o.net===l&&o.vat===h&&o.gross===f&&o.rate===c&&o.party===m&&o.number===(s.number||"")||so("ldocs",o.id,{qid:s.id,net:l,vat:h,gross:f,rate:c,party:m,number:s.number||""})}return s.id}const en=document.getElementById("app"),Z=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),yi=n=>x(n).toLocaleString("el-GR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €",Rr=n=>Math.round(x(n)).toLocaleString("el-GR")+" €",Zb=n=>n?new Date(n).toLocaleDateString("el-GR",{day:"numeric",month:"short"}):"",Cm=n=>String(n||"?").split(/\s+/).filter(Boolean).slice(0,2).map(e=>e[0]).join("").toUpperCase(),eA={pending:"p-a",accepted:"p-ok",done:"p-ok",rejected:"p-b"};let bn=null,It=!1;const we={qf:"all",cq:"",stAsk:null};let z=null;const tA=[["home","🏠","Αρχική"],["quotes","📄","Προσφορές"],["custs","👥","Πελάτες"],["agenda","📅","Πρόγραμμα"],["menu","☰","Μενού"]],nA=n=>`<nav class="nav">${tA.filter(([e])=>!$n()||e==="agenda"||e==="menu").map(([e,t,r])=>`<a href="#/${e}" class="${e===n?"on":""}"><i>${t}</i>${r}</a>`).join("")}</nav>`,$e=(n,e,t="",r="")=>`<header class="top">${t}<h1>${Z(n)}${e?`<span class="sm">${Z(e)}</span>`:""}</h1>${r}</header>`,Un=n=>`<a class="ib" href="#/${n}">←</a>`,Je=(n,e,t,r="")=>`${n}<main class="body">${e}</main>${r}${t?nA(t):""}`;function rA(n=""){return`<div class="login"><img class="lico" src="/icon-192.png" alt=""><div class="logo">TechMate</div><p>Συνδέσου με τον ίδιο λογαριασμό που έχεις στο PWA.</p>
  <form id="lf"><label>Email<input name="e" type="email" autocomplete="username" required></label>
  <label>Κωδικός<input name="p" type="password" autocomplete="current-password" required></label>
  <label class="chk"><input type="checkbox" id="sp"> Εμφάνιση κωδικού</label>
  ${n?`<div class="err">${Z(n)}</div>`:""}<button class="btn b1">Σύνδεση</button></form></div>`}function sA(){return L.quotes.filter(n=>!Oo(n)&&tt(n)==="pending")}function km(){return ye.state==="downloading"?`<div class="upd">⬇️ Κατεβαίνει η έκδοση ${Z(ye.latest.version)}… ${ye.pct}%</div>`:ye.state!=="available"?"":`<div class="upd">⬇️ Νέα έκδοση ${Z(ye.latest.version)}${ye.latest.notes?": "+Z(ye.latest.notes):""}${ye.needApk?"<br>Χρειάζεται νέο αρχείο εγκατάστασης (APK).":""}${ye.err?`<br><span class="bad">${Z(ye.err)}</span>`:""}
    <button class="btn b1 sm" data-up="apply">${ye.needApk?"Λήψη APK":"Ενημέρωση τώρα"}</button></div>`}function iA(){const n={checking:"Έλεγχος…",none:"Έχεις την τελευταία έκδοση.",error:ye.err}[ye.state]||"";return`<div class="card pad ver"><div><b>TechMate ${Z(pm)}</b>${n?`<span>${Z(n)}</span>`:""}</div><button class="btn b2 sm" data-up="check">Έλεγχος ενημέρωσης</button></div>`}function ad(){const n=new Date,e=new Date(n.getFullYear(),n.getMonth(),1).getTime(),t=L.quotes.filter(c=>!Oo(c)&&["accepted","done"].includes(tt(c))&&(c.ts||0)>=e).reduce((c,l)=>c+x(l.total),0),r=L.ldocs.filter(c=>c.kind==="sale").reduce((c,l)=>c+cm(l),0),s=L.tasks.filter(c=>!c.del&&c.date===pt()).sort((c,l)=>(c.time||"").localeCompare(l.time||"")),i=n.getHours(),o=i<12?"Καλημέρα":i<18?"Καλησπέρα":"Καλό βράδυ";return Je($e("TechMate",`${o} · ${n.toLocaleDateString("el-GR",{weekday:"short",day:"numeric",month:"short"})}`,"",'<a class="ib" href="#/menu">👤</a>'),`${LT?'<div class="upd">🧪 Δοκιμαστικά δεδομένα (preview)</div>':""}${km()}
    <div class="qa"><a href="#/edit/new"><i>📝</i>Προσφορά</a><a href="#/soon/Φωτογραφίες"><i>📷</i>Φωτο</a><a href="#/soon/Barcode"><i>🔍</i>Barcode</a><a href="#/books/newdoc"><i>💶</i>Έξοδο</a></div>
    <div class="kpis">
      <a class="kpi" href="#/quotes"><b>${sA().length}</b><span>Σε αναμονή απάντησης</span></a>
      <div class="kpi"><b>${Rr(t)}</b><span>Δεκτές αυτόν τον μήνα</span></div>
      <a class="kpi" href="#/custs"><b>${vt().length}</b><span>Πελάτες</span></a>
      <div class="kpi"><b class="${r>0?"bad":""}">${Rr(r)}</b><span>Μου χρωστούν</span></div>
    </div>
    <div class="h">Σήμερα</div>
    <div class="card">${s.length?s.map(Dm).join(""):'<div class="empty">Τίποτα για σήμερα</div>'}</div>`,"home")}function Dm(n){const e=n.done?"var(--ok)":n.date&&n.date<pt()?"var(--bad)":"var(--acc)";return`<div class="ag${n.done?" dn":""}"><button class="tick${n.done?" on":""}" data-tg="${Z(n.id)}" aria-label="Ολοκληρώθηκε">${n.done?"✓":""}</button>
  <a class="agb" href="#/t/${encodeURIComponent(n.id)}"><div class="tm">${Z(n.time||"—")}</div><div class="ln" style="background:${e}"></div>
  <div class="t"><b>${Z(n.title)}</b><span>${Z([n.cust,n.addr].filter(Boolean).join(" · "))}</span></div></a></div>`}function Vm(n){const e=tt(n),t=n.customer&&n.customer.name||"";return`<a class="row" href="#/q/${encodeURIComponent(n.id)}"><div class="av">${Z(Cm(t))}</div>
  <div class="t"><b>${Z(n.subject||"(χωρίς θέμα)")}</b><span>#${Z(n.number||"—")} · ${Z(t)} · ${Zb(n.ts)}</span></div>
  <div class="r"><div class="amt">${Rr(n.total)}</div><span class="pill ${eA[e]||"p-a"}">${Vi[e]||e}</span></div></a>`}function oA(){const n=L.quotes.filter(r=>!Oo(r)).sort((r,s)=>(s.ts||0)-(r.ts||0)),e=[["all","Όλες"],["pending","Σε αναμονή"],["accepted","Δεκτές"],["done","Ολοκληρ."],["rejected","Απορρίφθ."]],t=we.qf==="all"?n:n.filter(r=>tt(r)===we.qf);return Je($e("Προσφορές",`${n.length} συνολικά`),`<div class="chips">${e.map(([r,s])=>`<button data-qf="${r}" class="${we.qf===r?"on":""}">${s}</button>`).join("")}</div>
    <div class="card">${t.length?t.map(Vm).join(""):`<div class="empty">${It?"Καμία προσφορά":"Φόρτωση…"}</div>`}</div>`,"quotes",'<a class="fab" href="#/edit/new">＋</a>')}function aA(n){const e=L.quotes.find(o=>o.id===n);if(!e)return Je($e("Προσφορά","",Un("quotes")),`<div class="empty">${It?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"quotes");const t=tt(e),r=e.customer||{},s=e.lines||[],i=s.reduce((o,c)=>o+x(c.qty)*x(c.price)*(1-x(c.disc)/100),0);return Je($e(`#${e.number||"—"}`,Vi[t],Un("quotes")),`<div class="card"><div class="fld"><label>Πελάτης</label><a class="v" href="#/c/${encodeURIComponent(Te(r.name)||"_none")}">${Z(r.name)} ›</a></div>
    <div class="fld" style="margin:0"><label>Θέμα</label><div class="v">${Z(e.subject)}</div></div></div>
    <div class="h">Κατάσταση</div>
    <div class="card pad"><div class="seg four">${Object.keys(Vi).map(o=>`<button data-st="${o}" class="${o===t?"on":""}">${Vi[o]}</button>`).join("")}</div>
    ${we.stAsk&&we.stAsk.id===e.id?`<div class="ask"><b>Αλλαγή σε «${Z(Ni[we.stAsk.st])}»;</b>${fb(e,we.stAsk.st).map(o=>`<div>• ${Z(o)}</div>`).join("")}
      <div class="actions"><button class="btn b2" data-stno>Άκυρο</button><button class="btn b1" data-stok>Ναι, αλλαγή</button></div></div>`:""}</div>
    <div class="h">Είδη (${s.length})</div>
    <div class="card">${s.map(o=>`<div class="item"><div class="t"><b>${Z(o.desc)}</b><span>${x(o.qty)} × ${yi(o.price)}${x(o.disc)?` · −${x(o.disc)}%`:""}</span></div><div class="amt">${yi(x(o.qty)*x(o.price)*(1-x(o.disc)/100))}</div></div>`).join("")||'<div class="empty">Χωρίς είδη</div>'}</div>
    <div class="card"><div class="tot"><span>Καθαρό</span><span>${yi(i)}</span></div>
    <div class="tot big"><span>Σύνολο${e.vatMode==="off"?" (χωρίς ΦΠΑ)":" με ΦΠΑ"}</span><span>${yi(e.total)}</span></div></div>`,null,`<div class="bar"><a class="btn b2" href="#/edit/${encodeURIComponent(e.id)}">✏️ Επεξεργασία</a><a class="btn b1" href="#/soon/Αποστολή PDF">📤 PDF</a></div>`)}function cA(){const n=Te(we.cq),e=vt().filter(t=>!n||Te(t.name).includes(n)).sort((t,r)=>(r.last||0)-(t.last||0));return Je($e("Πελάτες",`${e.length}`),`<input class="search" id="cq" placeholder="🔍 Αναζήτηση πελάτη" value="${Z(we.cq)}">
    <div class="card">${e.map(t=>`<a class="row" href="#/c/${encodeURIComponent(t.k)}"><div class="av">${Z(Cm(t.name))}</div>
      <div class="t"><b>${Z(t.name)}</b><span>${t.quotes.length} προσφορές${t.info.phone?" · "+Z(t.info.phone):""}</span></div>
      <div class="r">${t.owed>0?`<div class="amt bad">${Rr(t.owed)}</div><span class="muted">χρωστάει</span>`:""}</div></a>`).join("")||`<div class="empty">${It?"Κανένας πελάτης":"Φόρτωση…"}</div>`}</div>`,"custs",'<a class="fab" href="#/ce/new">＋</a>')}function lA(n){const e=vt().find(s=>s.k===n);if(!e)return Je($e("Πελάτης","",Un("custs")),`<div class="empty">${It?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,"custs");const t=e.info,r=t.phone.replace(/\s/g,"");return Je($e(e.name,[t.address,t.phone].filter(Boolean).join(" · "),Un("custs"),r?`<a class="ib" href="tel:${Z(r)}">📞</a>`:""),`<div class="kpis"><div class="kpi"><b>${Rr(e.won)}</b><span>Δεκτές προσφορές</span></div><div class="kpi"><b class="${e.owed>0?"bad":""}">${Rr(e.owed)}</b><span>Υπόλοιπο</span></div></div>
    <div class="actions">${r?`<a class="btn b2" href="viber://chat?number=${Z(r.startsWith("+")?r:"+30"+r)}">💬 Viber</a>`:""}
    ${t.address?`<a class="btn b2" href="https://maps.google.com/?q=${encodeURIComponent(t.address)}">🗺️ Οδηγίες</a>`:""}
    ${t.email?`<a class="btn b2" href="mailto:${Z(t.email)}">✉️ Email</a>`:""}</div>
    <div class="actions"><a class="btn b2" href="#/ce/${encodeURIComponent(e.k)}">✏️ Στοιχεία</a><button class="btn b2" data-newq="${Z(e.k)}">＋ Προσφορά</button><button class="btn b2" data-newt="${Z(e.k)}">＋ Εργασία</button></div>
    ${e.rec&&e.rec.notes?`<div class="card pad note">${Z(e.rec.notes)}</div>`:""}
    <div class="h">Προσφορές (${e.quotes.length})</div>
    <div class="card">${e.quotes.sort((s,i)=>(i.ts||0)-(s.ts||0)).map(Vm).join("")||'<div class="empty">Καμία</div>'}</div>
    ${e.mins.length?`<div class="h">Παλιές εγκαταστάσεις (${e.mins.length})</div>`:""}
    <div class="h">Φωτογραφίες δουλειάς</div><div class="card"><a class="empty" href="#/soon/Φωτογραφίες">📷 Έρχεται στο επόμενο βήμα</a></div>`,"custs")}function cd(){const n=pt(),e=L.tasks.filter(h=>!h.del),t=(h,f)=>((h.date||"")+(h.time||"")).localeCompare((f.date||"")+(f.time||"")),r=e.filter(h=>h.date&&h.date<n&&!h.done).sort(t),s=e.filter(h=>!h.date&&!h.done).sort((h,f)=>(f.ts||0)-(h.ts||0)),i={};e.filter(h=>h.date&&h.date>=n).sort(t).forEach(h=>(i[h.date]=i[h.date]||[]).push(h));const o=h=>h===n?"Σήμερα":new Date(h+"T12:00").toLocaleDateString("el-GR",{weekday:"long",day:"numeric",month:"long"}),c=(h,f)=>f.length?`<div class="h">${h}</div><div class="card">${f.map(Dm).join("")}</div>`:"",l=c("Εκκρεμούν από πριν",r)+Object.keys(i).map(h=>c(o(h),i[h])).join("")+c("Χωρίς ημερομηνία",s);return Je($e("Πρόγραμμα","Εργασίες"),l||`<div class="card"><div class="empty">${It?"Δεν υπάρχουν εργασίες":"Φόρτωση…"}</div></div>`,"agenda",'<a class="fab" href="#/t/new">＋</a>')}const ht=(n,e,t="")=>`<label class="f">${e}<input class="in" data-f="${n}" value="${Z(z.v[n]||"")}" ${t}></label>`,Nm=n=>`${z.msg?`<div class="err box">${Z(z.msg)}</div>`:""}${n?`<button class="btn wide del" data-fa="del">${z.ask?"Σίγουρα; Πάτα ξανά για διαγραφή":"🗑️ Διαγραφή"}</button>`:""}`,xm='<div class="bar"><button class="btn b2" data-fa="cancel">Άκυρο</button><button class="btn b1" data-fa="save">💾 Αποθήκευση</button></div>';function uA(n){if(!z||z.kind!=="cust"||z.arg!==n){const e=n!=="new"&&vt().find(t=>t.k===n);if(n!=="new"&&!e)return Je($e("Πελάτης","",Un("custs")),`<div class="empty">${It?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);z={kind:"cust",arg:n,v:e?{name:e.name,...e.info,notes:e.rec&&e.rec.notes||""}:{name:""}}}return`${$e(n==="new"?"Νέος πελάτης":"Στοιχεία πελάτη","",'<a class="ib" data-fa="cancel">←</a>')}<main class="body ed"><div class="card pad">
    ${ht("name","Όνομα",'autocomplete="off"')}${ht("phone","Τηλέφωνο",'inputmode="tel"')}${ht("email","Email",'inputmode="email"')}${ht("afm","ΑΦΜ",'inputmode="numeric"')}${ht("address","Διεύθυνση")}
    <label class="f">Σημειώσεις<textarea class="in" data-f="notes" rows="3">${Z(z.v.notes||"")}</textarea></label></div>
    ${n!=="new"&&Te(z.v.name)!==n?'<div class="upd">Η αλλαγή ονόματος θα περάσει και στις προσφορές, στα παραστατικά και στις εισπράξεις του πελάτη.</div>':""}${Nm(!1)}</main>${xm}`}function hA(n){if(!z||z.kind!=="task"||z.arg!==n){const r=n!=="new"&&L.tasks.find(s=>s.id===n);if(n!=="new"&&!r)return Je($e("Εργασία","",Un("agenda")),`<div class="empty">${It?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);z={kind:"task",arg:n,v:r?{title:r.title,date:r.date||"",time:r.time||"",cust:r.cust||"",addr:r.addr||"",notes:r.notes||"",done:!!r.done,emps:(r.emps||[]).slice()}:{title:"",date:pt(),time:"",emps:[],...we.taskPreset||{}}},we.taskPreset=null,z.ro=!!r&&!cl(r)}const e=z.v,t=vt().map(r=>r.name).filter(r=>r&&r!=="(χωρίς όνομα)");return`${$e(n==="new"?"Νέα εργασία":"Εργασία",z.ro?"Μόνο ο δημιουργός την αλλάζει":"",'<a class="ib" data-fa="cancel">←</a>')}<main class="body ed"><div class="card pad">
    ${ht("title","Τίτλος",'placeholder="π.χ. Εγκατάσταση καμερών"')}
    <div class="two">${ht("date","Ημερομηνία",'type="date"')}${ht("time","Ώρα",'type="time"')}</div>
    ${ht("cust","Πελάτης",'list="tcl" autocomplete="off"')}<datalist id="tcl">${t.map(r=>`<option value="${Z(r)}">`).join("")}</datalist>
    ${ht("addr","Διεύθυνση")}
    <label class="f">Σημειώσεις<textarea class="in" data-f="notes" rows="3">${Z(e.notes||"")}</textarea></label>
    ${!$n()&&L.emps.length?`<div class="f">Ποιοι θα πάνε</div><div class="chips wrap">${L.emps.map(r=>`<button data-emp="${Z(r.id)}" class="${e.emps.includes(r.id)?"on":""}">${Z(r.name)}</button>`).join("")}</div>`:""}
    <label class="chk2"><input type="checkbox" data-f="done" ${e.done?"checked":""}> Ολοκληρώθηκε</label></div>
    ${Nm(n!=="new"&&!z.ro)}</main>${z.ro?"":xm}`}function dA(n){if(n==="cancel"){const t=z.kind,r=z.arg;return z=null,location.replace(t==="task"?"#/agenda":r==="new"?"#/custs":"#/c/"+encodeURIComponent(r))}if(n==="del"){if(!z.ask)return z.ask=!0,Ze();const t=yb(z.arg);return t.msg?(z.msg=t.msg,z.ask=!1,Ze()):(z=null,Pr("Η εργασία διαγράφηκε."),location.replace("#/agenda"))}if(z.kind==="cust"){const t=mb(z.arg==="new"?"":z.arg,z.v);return t.ok?(z=null,location.replace("#/c/"+encodeURIComponent(t.k))):(z.msg=t.msg,Ze())}const e=gb(z.arg==="new"?"":z.arg,z.v);if(!e.ok)return z.msg=e.msg,Ze();z=null,location.replace("#/agenda")}const fA=[["📄","Προσφορές","Νέα · Κατάλογος · Αποθηκευμένες · Κατάσταση · Δεκτές & παραγγελίες · Ιστορικό αλλαγών · Διαγραμμένα","#/quotes"],["📒","Λογιστικά","Σύνοψη · Παραστατικά · Πληρωμές · Υπόλοιπα","#/books/sum"],["🛡️","Εγκαταστάσεις","Εγκαταστάσεις · Οδηγίες"],["👷","Μεροκάματα","Καταχώρηση · Πληρωμή υπαλλήλου · Υπόλοιπα"],["📦","Αποθήκη","Απόθεμα · Κινήσεις · Λίστα παραγγελίας · Εργαλεία που λείπουν"],["🌐","Ιστοσελίδα","Περιεχόμενο · Άρθρα · Μηνύματα"],["✅","Microsoft To Do","Λίστες και εργασίες"],["⚙️","Ρυθμίσεις","Εταιρεία & PDF · Τιμές/αρίθμηση · Τράπεζες · Χρήστες ομάδας · PIN · Ειδοποιήσεις · Backup"]];function pA(){return $n()?Je($e("Μενού",bn?bn.email:""),'<div class="card"><div class="empty">Ο λογαριασμός σου βλέπει το Πρόγραμμα. Τα μεροκάματα και τα εργαλεία που λείπουν έρχονται σύντομα.</div></div><button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>',"menu"):Je($e("Μενού",bn?bn.email:""),`<div class="card">${fA.map(([n,e,t,r])=>`<a class="mi" href="${r||"#/soon/"+e}"><div class="ic">${n}</div><div class="t"><b>${e}${r?"":' <span class="soon">σύντομα</span>'}</b><span>${t}</span></div></a>`).join("")}</div>
    ${km()}${iA()}<button class="btn b2 wide" id="out">🚪 Αποσύνδεση</button>`,"menu")}function mA(n){return Je($e(n,"",'<a class="ib" href="javascript:history.back()">←</a>'),`<div class="card"><div class="empty">🛠️ Το «${Z(n)}» φτιάχνεται στα επόμενα βήματα.<br>Μέχρι τότε γίνεται από το PWA, και φαίνεται αμέσως εδώ.</div></div>`,null)}function Ze(){if(!bn)return;const[n,e]=location.hash.replace(/^#\//,"").split("/").map(decodeURIComponent),t={home:ad,quotes:oA,q:()=>aA(e),custs:cA,c:()=>lA(e),agenda:cd,menu:pA,soon:()=>mA(e)};if(n==="edit")return Om(e);qb(),Object.assign(t,{ce:()=>uA(e),t:()=>hA(e),books:()=>xb(e,It)}),n!=="ce"&&n!=="t"&&(z=null),n!=="q"&&(we.stAsk=null),n!=="books"&&Ab();const r=scrollY,s=$n()&&!["agenda","t","menu"].includes(n)?cd:t[n]||ad;if(en.innerHTML=s(),n==="custs"){const o=document.getElementById("cq");o.oninput=()=>{we.cq=o.value,Ze();const c=document.getElementById("cq");c.focus(),c.setSelectionRange(c.value.length,c.value.length)}}const i=document.getElementById("out");i&&(i.onclick=()=>BT()),scrollTo(0,r)}const gA=(n,e)=>e?location.replace(n):location.hash=n;en.addEventListener("change",n=>Fb(n.target,Ze));en.addEventListener("click",n=>{if(Mb(n.target,gA,Ze,Pr))return;const e=n.target.closest("[data-up],[data-qf],[data-st],[data-stok],[data-stno],[data-tg],[data-fa],[data-emp],[data-newq],[data-newt]");if(!e)return;const t=e.dataset,r=decodeURIComponent(location.hash.split("/")[2]||"");if(t.up){t.up==="apply"?cb():sc(!0);return}if(t.qf)we.qf=t.qf;else if(t.st){const s=L.quotes.find(i=>i.id===r);we.stAsk=s&&tt(s)!==t.st?{id:r,st:t.st}:null}else if("stno"in t)we.stAsk=null;else if("stok"in t){const s=pb(we.stAsk.id,we.stAsk.st);we.stAsk=null,s.msg&&Pr(s.msg)}else if(t.tg){const s=L.tasks.find(i=>i.id===t.tg);s&&_b(s.id,!s.done);return}else{if(t.fa)return z&&dA(t.fa);if(t.emp){if(!z)return;const s=z.v.emps.indexOf(t.emp);s>=0?z.v.emps.splice(s,1):z.v.emps.push(t.emp)}else if(t.newq){const s=vt().find(i=>i.k===t.newq);s&&jb({name:s.name,...s.info}),location.hash="#/edit/new";return}else if(t.newt){const s=vt().find(i=>i.k===t.newt);s&&(we.taskPreset={cust:s.name,addr:s.info.address||""}),location.hash="#/t/new";return}}Ze()});en.addEventListener("input",n=>{const e=n.target;Lb(e,Ze)||z&&e.dataset.f&&(z.v[e.dataset.f]=e.type==="checkbox"?e.checked:e.value,z.msg&&(z.msg=""))});addEventListener("hashchange",()=>{scrollTo(0,0),Ze()});function Om(n){const e=scrollY,t=Wb(n);if(t===null){en.innerHTML=Je($e("Προσφορά","",Un("quotes")),`<div class="empty">${It?"Δεν βρέθηκε":"Φόρτωση…"}</div>`,null);return}en.innerHTML=t,Hb(en,()=>Om(n),r=>location.replace(r?"#/q/"+encodeURIComponent(r):"#/quotes")),scrollTo(0,e)}function Pr(n){let e=document.getElementById("toast");e||(e=document.createElement("div"),e.id="toast",document.body.appendChild(e)),e.textContent=n,e.className="show",clearTimeout(Pr.t),Pr.t=setTimeout(()=>e.className="",6e3)}qT(n=>Pr(n&&n.code==="permission-denied"?"Δεν έχεις δικαίωμα για αυτή την αλλαγή. Δεν αποθηκεύτηκε.":"Η αποθήκευση απέτυχε: "+(n&&(n.code||n.message)||"άγνωστο σφάλμα")));ob(()=>{bn&&!Rm()&&!z&&!Sm()&&Ze()});ab();MT(()=>{It=!0,!(Rm()||z||Sm())&&Ze()});FT(n=>{bn=n,n?Ze():Mm()});function Mm(n="",e=""){en.innerHTML=rA(n);const t=document.getElementById("lf");t.e.value=e,document.getElementById("sp").onchange=r=>{t.p.type=r.target.checked?"text":"password"},document.getElementById("lf").onsubmit=r=>{r.preventDefault();const s=r.target;UT(s.e.value.trim(),s.p.value).catch(i=>{const o=i&&i.code||"",l=["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(o)?"Λάθος email ή κωδικός.":o==="auth/network-request-failed"?"Δεν υπάρχει σύνδεση στο internet.":o==="auth/too-many-requests"?"Πολλές προσπάθειες. Δοκίμασε ξανά σε λίγα λεπτά.":"Η σύνδεση μπλοκαρίστηκε.";Mm(l+" ["+(o||i&&i.message||"άγνωστο")+"]",s.e.value)})}}export{ed as A,ol as W};
